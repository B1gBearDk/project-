#!/usr/bin/env python3
"""Diagrams only: the validator's CSV files -> SVG, DOT, Mermaid. Same arguments as before."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))

from otvalidate.cli import run_diagram  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run_diagram())
