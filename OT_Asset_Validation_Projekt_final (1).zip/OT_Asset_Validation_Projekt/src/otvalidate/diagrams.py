"""Turn evidence nodes into diagrams: SVG (primary), zone overview, zone details, DOT and Mermaid."""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import re
import shutil
import subprocess

from .ingest import InputError, clean_text
from .render_svg import Band, Card, Diagram, Edge, render_svg
from .report import export_csv
from .zones import FlowEdge, Node, zones_in_order

SUBTITLE = "Observerede dataflows fra passive logs. Viser kommunikation, ikke fysisk topologi. Arbejdsmateriale: kræver manuel verificering."
MAX_LABEL_SERVICES = 2
STROKES = {"KILDE": "solid", "KILDE_OG_DESTINATION": "solid", "KUN_DESTINATION": "dashed", "KUN_NAEVNT": "dotted", "IKKE_OBSERVERET": "silent"}
OBSERVATION_TEXT = {"KILDE": "set som kilde", "KILDE_OG_DESTINATION": "kilde og destination", "KUN_DESTINATION": "kun destination",
                    "KUN_NAEVNT": "kun nævnt i log", "IKKE_OBSERVERET": "ikke observeret"}
DEVIATION_TEXT = {"MAC_AFVIGER": "MAC afviger fra dok.", "FLERE_MAC": "Flere MAC på IP", "NAVN_KONFLIKT": "Flere dok. navne", "NAVN_PAA_FLERE_IP": "Navn på flere IP'er",
                  "DOK_UDEN_FOR_SCOPE": "Dok. men uden for scope", "IP_PAA_FLERE_SITES": "IP på flere sites", "KUN_OBS_UDEN_SITE": "Kun set uden site", "SIDST_SET_FOER_LOGSLUT": "Ikke set i slutperiode", "MULIG_BROADCAST": "Mulig broadcast"}
UNDOCUMENTED_TEXT = {"IKKE_I_REFERENCE_IN_SCOPE": "Ikke dokumenteret · i scope", "UDENFOR_SCOPE": "Ikke dokumenteret · uden for scope",
                     "IKKE_I_REFERENCE_SCOPE_UKENDT": "Ikke dokumenteret · scope ukendt", "AFLEDT_FRA_FLOW": "Kun set i flowtabel",
                     "DOKUMENTERET_ANDET_SITE": "Dokumenteret på andet site", "DOKUMENTERET_SITE_UAFKLARET": "Dokumenteret · site uafklaret"}
DETAIL_DIR = "zoner"
DETAIL_MANIFEST = "genererede_filer.txt"  # What a rerun may delete; other files in the folder are the user's.
DIAGRAM_FILES = ("01_diagram_asset_catalog.csv", "02_site_dataflow.dot", "02_site_dataflow.svg", "03_site_dataflow.png", "04_diagram_summary.txt",
                 "05_site_dataflow.mmd", "06_diagram_notes.txt", "07_zone_overview.svg")


def _evidence(node: Node) -> str:
    if node.status == "LOGISK_ADRESSE":
        return f"Logisk adresse: {node.address_type}"
    if node.documented:
        prefix = "Dok.-kandidat" if node.doc_kind == "KANDIDAT" else "Dokumenteret"
        return f"{prefix} · {OBSERVATION_TEXT.get(node.observation, 'ukendt')}"
    return UNDOCUMENTED_TEXT.get(node.status, node.status)


def _role_text(node: Node) -> str:
    if node.role == "Unknown" or not node.role:
        return "" if node.status in ("LOGISK_ADRESSE", "UDENFOR_SCOPE") else "rolle ukendt"
    short = {"Engineering Workstation": "Eng. WS", "Field Device": "Feltenhed"}.get(node.role, node.role)
    return f"{short}?" if node.role_source == "HYPOTESE" else short


def _deviation_text(node: Node) -> str:
    if not node.deviations:
        return ""
    text = DEVIATION_TEXT.get(node.deviations[0], node.deviations[0])
    return f"{text} +{len(node.deviations) - 1}" if len(node.deviations) > 1 else text


def node_card(node: Node) -> Card:
    tooltip = "\n".join(line for line in (
        node.label, node.ip, f"Status: {node.status}", f"Zone: {node.zone} ({node.zone_source})", f"Rolle: {node.role} ({node.role_source})",
        f"Verificeret: {node.verified}" if node.verified else "Ikke manuelt verificeret",
        node.review, f"Afvigelser: {', '.join(node.deviations)}" if node.deviations else "", f"MAC: {node.mac}" if node.mac else "",
        f"Dokumentation: {node.doc_source}" if node.doc_source else "Dokumentation: ingen", f"Logkilde: {node.log_source}" if node.log_source else "Logkilde: ingen", node.next_step) if line)
    fill = "logical" if node.status == "LOGISK_ADRESSE" else "documented" if node.documented else "undocumented"
    if node.status == "LOGISK_ADRESSE":
        title = (node.address_type or "Logisk adresse").capitalize()
    else:
        title = "Uden navn" if node.label == node.ip else node.label
    return Card(id=node.ip, title=title, mono=node.ip, role=_role_text(node), evidence=_evidence(node), fill=fill,
                stroke=STROKES.get(node.observation, "solid"), verified=f"Verificeret {node.verified}" if node.verified else "",
                deviation=_deviation_text(node), tooltip=tooltip, review=node.review)


def _count_text(zone: str, count: int) -> str:
    if zone == "Logiske adresser":
        return f"{count} {'adresse' if count == 1 else 'adresser'}"
    return f"{count} {'asset' if count == 1 else 'assets'}"


def _band_note(zone: str, nodes: list) -> str:
    sources = Counter(node.zone_source for node in nodes)
    lines = [_count_text(zone, len(nodes))]
    if sources["MANUEL"] or sources["MANUEL_ROLLE"]:
        lines.append(f"{sources['MANUEL'] + sources['MANUEL_ROLLE']} manuelt placeret")
    if sources["HYPOTESE"]:
        lines.append(f"{sources['HYPOTESE']} hypotese fra navn")
    if sources["SCOPE"]:
        lines.append("placeret ud fra scope")
    if sources["INGEN"]:
        lines.append(f"{sources['INGEN']} uden zonegrundlag")
    return "\n".join(lines)


def _service_text(service: tuple) -> str:
    proto, port, count = service
    return f"{proto or '?'}{'/' + port if port else ''} ×{count}"


def edge_label(edge: FlowEdge) -> str:
    text = ", ".join(_service_text(s) for s in edge.services[:MAX_LABEL_SERVICES])
    extra = len(edge.services) - MAX_LABEL_SERVICES
    return f"{text} +{extra}" if extra > 0 else text


def _edge_title(edge: FlowEdge) -> str:
    lines = [f"{edge.src} → {edge.dst} ({edge.count} observationer)"]
    lines += [_service_text(s) for s in edge.services]
    if edge.first:
        lines.append(f"Første: {edge.first}")
    if edge.last:
        lines.append(f"Seneste: {edge.last}")
    lines.append(f"Logkilde: {', '.join(sorted(edge.files)) or 'ukendt'}")
    if edge.site_unresolved:
        lines.append(f"{edge.site_unresolved} observationer uden site: kan høre til et andet site.")
    lines.append("Observeret trafik, ikke en fysisk forbindelse.")
    return "\n".join(lines)


def _common_notices(observed_any: bool, hidden: int, min_count: int, blockers: int = 0) -> list:
    notices = []
    if blockers:
        notices.append(f"Grundlaget er ufuldstændigt: {blockers} blokerende forhold. Se 06_begraensninger_og_advarsler.txt, før diagrammet bruges.")
    if not observed_any:
        notices.append("Ingen trafik observeret i inputlogs. Det siger intet om, hvorvidt enhederne findes. Tjek logfiler og sensordækning.")
    if hidden:
        notices.append(f"{hidden} flows med færre end {min_count} observationer er skjult. Se flowtabellen for alle flows.")
    return notices


def site_diagram(site: str, nodes: list, edges: list, meta: list, notices: list) -> Diagram:
    bands = []
    for zone in zones_in_order(nodes):
        members = [node for node in nodes if node.zone == zone]
        bands.append(Band(zone, _band_note(zone, members), [node_card(node) for node in members]))
    flows = [Edge(e.src, e.dst, edge_label(e), e.dashed, _edge_title(e)) for e in edges]
    return Diagram(f"{clean_text(site)}: OT-dataflow", SUBTITLE, meta, notices, bands, flows)


def zone_detail(site: str, zone: str, nodes: list, edges: list, meta: list) -> Diagram:
    """One zone with its direct communication partners. The other zones show partners only."""
    in_zone = {node.ip for node in nodes if node.zone == zone}
    touching = [edge for edge in edges if edge.src in in_zone or edge.dst in in_zone]
    keep = in_zone | {edge.src for edge in touching} | {edge.dst for edge in touching}
    diagram = site_diagram(site, [node for node in nodes if node.ip in keep], touching, meta, [f"Viser kun zonen {zone} og dens direkte modparter. Andre flows er udeladt."])
    diagram.title = f"{clean_text(site)}: zone {zone}"
    return diagram


def overview_diagram(site: str, nodes: list, edges: list, meta: list, notices: list) -> Diagram:
    """Zones as single cards with aggregated flows; the first view for a large site."""
    zone_of = {node.ip: node.zone for node in nodes}
    bands = []
    for zone in zones_in_order(nodes):
        members = [node for node in nodes if node.zone == zone]
        documented = sum(node.documented for node in members)
        silent = sum(node.observation == "IKKE_OBSERVERET" for node in members)
        verified = sum(bool(node.verified) for node in members)
        flagged = sum(bool(node.deviations) for node in members)
        card = Card(id=zone, title=_count_text(zone, len(members)), mono=f"{documented} dok. · {len(members) - documented} ikke dok.",
                    role="", evidence=f"{silent} ikke observeret · {verified} manuelt verificeret", deviation=f"{flagged} med afvigelse" if flagged else "",
                    stroke="solid", fill="documented")
        bands.append(Band(zone, _band_note(zone, members), [card]))
    grouped = defaultdict(lambda: {"pairs": 0, "count": 0, "services": Counter(), "dashed": False})
    for edge in edges:
        group = grouped[(zone_of[edge.src], zone_of[edge.dst])]
        group["pairs"] += 1
        group["count"] += edge.count
        group["dashed"] = group["dashed"] or edge.dashed
        for proto, port, count in edge.services:
            group["services"][f"{proto or '?'}{'/' + port if port else ''}"] += count
    flows = []
    for (src_zone, dst_zone), group in sorted(grouped.items()):
        top = [name for name, _ in sorted(group["services"].items(), key=lambda item: (-item[1], item[0]))[:2]]
        more = f" +{len(group['services']) - 2}" if len(group["services"]) > 2 else ""
        flows.append(Edge(src_zone, dst_zone, f"{group['pairs']} par ×{group['count']}: {', '.join(top)}{more}", group["dashed"],
                          f"{src_zone} → {dst_zone}: {group['pairs']} IP-par, {group['count']} observationer"))
    return Diagram(f"{clean_text(site)}: zoneoverblik", SUBTITLE, meta, notices, bands, flows, legend=False, max_cols=1, card_w=250)


def _dot_escape(value) -> str:
    return clean_text(value, 200).replace("\\", "\\\\").replace('"', '\\"')


def build_dot(site: str, nodes: list, edges: list, rankdir: str = "TB") -> str:
    """Editable Graphviz source. Invisible edges fix the zone order; real flows do not affect ranking."""
    lines = ["digraph OTDataflow {", f"  rankdir={rankdir if rankdir in ('TB', 'LR') else 'TB'};",
             '  graph [fontname="Arial", fontsize=18, labelloc="t", labeljust="l", newrank=true, nodesep=0.35, ranksep=0.8, compound=true];',
             '  node [fontname="Arial", fontsize=10, shape=box, style="filled", fillcolor="white", color="#111827"];',
             '  edge [fontname="Arial", fontsize=9, color="#111827", arrowsize=0.7];',
             f'  label="{_dot_escape(site)}: observerede dataflows, ikke fysisk topologi";']
    anchors = []
    for index, zone in enumerate(zones_in_order(nodes)):
        lines += [f"  subgraph cluster_{index} {{", f'    label="{_dot_escape(zone)}";', '    color="#d1d5db"; style="filled"; fillcolor="#f3f4f6";']
        members = [node for node in nodes if node.zone == zone]
        anchors.append(_node_id(members[0].ip))
        for node in members:
            card = node_card(node)
            style = {"solid": "filled", "dashed": "filled,dashed", "dotted": "filled,dotted", "silent": "filled,dotted"}[card.stroke]
            parts = [card.title, card.mono, card.role, card.verified, card.evidence, card.deviation and f"! {card.deviation}"]
            label = "\\n".join(_dot_escape(part) for part in parts if part)
            fill = "#e5e7eb" if card.fill == "undocumented" else "white"
            lines.append(f'    {_node_id(node.ip)} [label="{label}", style="{style}", fillcolor="{fill}"];')
        lines.append("  }")
    for upper, lower in zip(anchors, anchors[1:]):
        lines.append(f"  {upper} -> {lower} [style=invis];")
    for edge in edges:
        attributes = f'label="{_dot_escape(edge_label(edge))}", constraint=false'
        if edge.dashed:
            attributes += ", style=dashed"
        lines.append(f"  {_node_id(edge.src)} -> {_node_id(edge.dst)} [{attributes}];")
    lines.append("}")
    return "\n".join(lines) + "\n"


def _node_id(ip: str) -> str:
    return "n_" + re.sub(r"[^0-9A-Za-z]", "_", str(ip))


def _mermaid_escape(value) -> str:
    text = clean_text(value, 200).replace("#", "#35;")
    for char, entity in (("%", "#37;"), ('"', "#quot;"), ("<", "#lt;"), (">", "#gt;"), ("|", "#124;"), ("`", "#96;"), ("[", "#91;"), ("]", "#93;")):
        text = text.replace(char, entity)
    return text


def build_mermaid(site: str, nodes: list, edges: list) -> str:
    lines = ["flowchart TB", f"%% {_mermaid_escape(site)}: observerede dataflows, ikke fysisk topologi",
             f'note["{_mermaid_escape(site)}: observerede dataflows fra logs, ikke fysisk topologi"]',
             "classDef documented fill:#fff,stroke:#111827;", "classDef undocumented fill:#e5e7eb,stroke:#111827;",
             "classDef silent fill:#fff,stroke:#9ca3af,stroke-dasharray:2 4;", "classDef logical fill:#fff,stroke:#111827,stroke-dasharray:1 3;"]
    for index, zone in enumerate(zones_in_order(nodes)):
        lines.append(f'subgraph z{index}["{_mermaid_escape(zone)}"]')
        for node in (n for n in nodes if n.zone == zone):
            card = node_card(node)
            parts = [card.title, card.mono, card.role, card.verified, card.evidence, card.deviation and f"! {card.deviation}"]
            label = "<br/>".join(_mermaid_escape(part) for part in parts if part)
            css = "silent" if card.stroke == "silent" else card.fill
            lines.append(f'  {_node_id(node.ip)}["{label}"]:::{css}')
        lines.append("end")
    for edge in edges:
        arrow = "-.->" if edge.dashed else "-->"
        lines.append(f'{_node_id(edge.src)} {arrow}|"{_mermaid_escape(edge_label(edge))}"| {_node_id(edge.dst)}')
    return "\n".join(lines) + "\n"


def render_png(dot_path: Path, png_path: Path) -> tuple:
    """Optional PNG via a local Graphviz install. Returns (ok, message)."""
    dot = shutil.which("dot")
    if not dot:
        return False, "Graphviz (dot) er ikke installeret. SVG, DOT og Mermaid er skrevet; kun PNG mangler."
    if Path(dot).resolve().parent == Path.cwd().resolve():
        return False, "'dot' blev fundet i den aktuelle mappe og er ikke kørt. Kør fra en anden mappe eller installér Graphviz på PATH."
    try:
        subprocess.run([dot, "-Tpng", str(dot_path), "-o", str(png_path)], check=True, capture_output=True, timeout=120)
    except (OSError, subprocess.SubprocessError) as exc:
        png_path.unlink(missing_ok=True)
        return False, f"Graphviz kunne ikke lave PNG: {clean_text(exc, 200)}"
    return True, "PNG er lavet med Graphviz ud fra DOT-filen. Layoutet afviger fra SVG-filen, som er det primære diagram."


def safe_name(text: str) -> str:
    """A folder or file name that cannot leave the output directory."""
    name = re.sub(r"[^\w.-]+", "_", str(text)).strip("._")
    if name.upper() in {"CON", "PRN", "AUX", "NUL"} or re.fullmatch(r"(?i)(COM|LPT)\d", name):
        name = f"site_{name}"
    return name[:80] or "site"


def clean_previous_outputs(out: Path) -> None:
    """Remove only this tool's own files, so an old diagram can never pass for a new one."""
    for name in DIAGRAM_FILES:
        (out / name).unlink(missing_ok=True)
    details = out / DETAIL_DIR
    if details.is_symlink():
        raise InputError(f"{details} er et symbolsk link. Vælg en anden outputmappe.")
    manifest = details / DETAIL_MANIFEST
    if manifest.is_file():
        for name in manifest.read_text(encoding="utf-8").split("\n"):
            if re.fullmatch(r"\d\d_[\w.-]+\.svg", name):  # Plain file names only: the list is a file on disk.
                (details / name).unlink(missing_ok=True)
        manifest.unlink()
    if details.is_dir() and not any(details.iterdir()):
        details.rmdir()


def write_diagrams(out: Path, site: str, nodes: list, edges: list, *, hidden: int = 0, min_count: int = 1, meta=(), observed_any: bool = True,
                   rankdir: str = "TB", detail_threshold: int = 25, blockers: int = 0) -> dict:
    """Write all diagram files. Returns the rendered site SVG and summary facts for the report."""
    out.mkdir(parents=True, exist_ok=True)
    clean_previous_outputs(out)
    meta = list(meta)
    notices = _common_notices(observed_any, hidden, min_count, blockers)

    export_csv(out / "01_diagram_asset_catalog.csv",
               ("IP", "Label", "Rolle", "Rolle_kilde", "Zone", "Zone_kilde", "Status", "Observation", "Verificering", "Review_status", "Afvigelser", "I_scope", "Site", "MAC", "Foreslaaet_naeste_skridt"),
               [(n.ip, n.label, n.role, n.role_source, n.zone, n.zone_source, n.status, n.observation, n.verified or "IKKE_VERIFICERET", n.review_status or "IKKE_BEHANDLET", ", ".join(n.deviations),
                 n.in_scope, n.site, n.mac, n.next_step) for n in nodes])
    svg = render_svg(site_diagram(site, nodes, edges, meta, notices))
    (out / "02_site_dataflow.svg").write_text(svg, encoding="utf-8")
    (out / "07_zone_overview.svg").write_text(render_svg(overview_diagram(site, nodes, edges, meta, notices)), encoding="utf-8")
    dot_path = out / "02_site_dataflow.dot"
    dot_path.write_text(build_dot(site, nodes, edges, rankdir), encoding="utf-8")
    (out / "05_site_dataflow.mmd").write_text(build_mermaid(site, nodes, edges), encoding="utf-8")
    png_ok, png_message = render_png(dot_path, out / "03_site_dataflow.png")

    detail_files = []
    if len(nodes) > detail_threshold:
        details = out / DETAIL_DIR
        details.mkdir(exist_ok=True)
        for index, zone in enumerate(zones_in_order(nodes), 1):
            name = f"{index:02d}_{safe_name(zone)}.svg"
            (details / name).write_text(render_svg(zone_detail(site, zone, nodes, edges, meta)), encoding="utf-8")
            detail_files.append(name)
        (details / DETAIL_MANIFEST).write_text("\n".join(detail_files) + "\n", encoding="utf-8")

    zones = Counter(node.zone for node in nodes)
    sources = Counter(node.zone_source for node in nodes)
    summary = [f"Site: {clean_text(site)}", f"Adresser i diagrammet: {len(nodes)}", f"IP-par med observeret flow: {len(edges)}", f"Skjulte flows: {hidden}", "", "Pr. zone:"]
    summary += [f"- {zone}: {zones[zone]}" for zone in zones_in_order(nodes)]
    summary += ["", "Zonegrundlag:"] + [f"- {name}: {count}" for name, count in sorted(sources.items())]
    summary += ["", f"Manuelt verificeret: {sum(bool(n.verified) for n in nodes)} af {len(nodes)}"]
    (out / "04_diagram_summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")

    notes = ["Sådan læses filerne", "",
             "- 02_site_dataflow.svg: primært diagram. Åbn i browser, eller indsæt i Word/PowerPoint. Hold musen over kort og linjer for detaljer.",
             "- 07_zone_overview.svg: overblik pr. zone med samlede flows.",
             "- 02_site_dataflow.dot / 05_site_dataflow.mmd: redigerbare kilder (Graphviz / Mermaid).",
             "- 01_diagram_asset_catalog.csv: alle adresser med rolle, zone og hvad de bygger på.",
             f"- PNG: {png_message}", ""]
    if detail_files:
        notes += ["Zonevise detaljer i mappen zoner/: " + ", ".join(detail_files), ""]
    notes += ["Grundlag for zoner:", "- MANUEL: fra asset-map. MANUEL_ROLLE: zonen følger af en manuel rolle.", "- SCOPE/STATUS: følger af scope eller status.",
              "- HYPOTESE: gæt ud fra navnet. Ikke et faktum; ret det i asset-map.", "- INGEN: intet grundlag, vist under Ukendt.", "",
              "Diagrammet viser observeret kommunikation, ikke kabler, switches eller segmentering."]
    (out / "06_diagram_notes.txt").write_text("\n".join(notes) + "\n", encoding="utf-8")
    return {"svg": svg, "png_ok": png_ok, "png_message": png_message, "detail_files": detail_files}
