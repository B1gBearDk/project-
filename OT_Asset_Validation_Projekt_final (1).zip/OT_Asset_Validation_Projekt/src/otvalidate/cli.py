"""Command lines: full pipeline, validator only, diagram only. All three read and write local files only."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import sys
from typing import Callable

from . import __version__
from .diagrams import safe_name, write_diagrams
from .ingest import InputError, LogAggregator, load_reference, sha256_file
from .reconcile import Validation, parse_scopes, reconcile
from .report import read_table, write_html_report, write_validation
from .review import load_decisions
from .zones import aggregate_edges, build_nodes, load_asset_map


EXIT_INCOMPLETE = 3  # Reports are written, but the input has unresolved gaps a person must look at.


def _guarded(main: Callable[[list], int], argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="replace")  # Danish text must not crash a legacy console.
    try:
        return main(sys.argv[1:] if argv is None else argv)
    except (InputError, OSError, csv.Error, UnicodeError, OverflowError, RecursionError) as exc:
        print(f"FEJL: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


def _require_files(paths) -> None:
    for path in paths:
        if path and not path.is_file():
            raise InputError(f"Filen findes ikke: {path}")


def _stale_days(text: str) -> int:
    days = int(text)
    if not 0 <= days <= 36500:
        raise argparse.ArgumentTypeError("skal være mellem 0 og 36500")
    return days


def _add_validation_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--reference", nargs="+", required=True, type=Path, help="Dokumentation: CSV, TSV, TXT eller PDF")
    parser.add_argument("--logs", nargs="+", required=True, type=Path, help="Passive logeksporter: CSV, TSV, JSON, JSONL, LOG, TXT")
    parser.add_argument("--scope", action="append", default=[], help="Lokalt net som CIDR, fx 192.0.2.0/24. Kan gentages")
    parser.add_argument("--site", default="", help="Kun dette site fra referencens site-kolonne")
    parser.add_argument("--asset-map", type=Path, help="Manuel CSV: IP;Zone;Role;Label;Verified_by;Verified_date")
    parser.add_argument("--reference-site", action="append", default=[], metavar="FIL=SITE", help="Hvilket site en hel referencefil hører til. Eneste kilde til site for PDF og TXT. Kan gentages")
    parser.add_argument("--log-site-confirmed", action="store_true", help="Du bekræfter, at logrækker uden site hører til det valgte --site")
    parser.add_argument("--review-file", type=Path, help="Din egen CSV med reviewbeslutninger. Læses kun, ændres aldrig")
    parser.add_argument("--source-field", help="Kolonnenavn for kilde-IP, hvis autodetektion fejler")
    parser.add_argument("--dest-field", help="Kolonnenavn for destinations-IP")
    parser.add_argument("--time-field", help="Kolonnenavn for tidsstempel")
    parser.add_argument("--stale-days", type=_stale_days, default=7, help="Markér IP'er, der ikke er set de sidste N dage af logperioden (standard 7)")


def _file_sites(values: list, references: list) -> dict:
    """Map --reference-site onto the given reference files. The file must be exact: a site on the wrong document mixes waterworks."""
    sites = {}
    for value in values:
        name, separator, site = value.rpartition("=")
        if not separator or not name.strip() or not site.strip():
            raise InputError(f"--reference-site skal have formen FIL=SITE, ikke '{value}'.")
        given = Path(name.strip())
        bare = given.name == name.strip()
        matches = [path for path in references if (path.name == given.name if bare else path.resolve() == given.resolve())]
        if not matches:
            raise InputError(f"--reference-site: '{name.strip()}' er ikke en af filerne i --reference.")
        same_name = [path for path in references if path.name == matches[0].name]
        if len(same_name) > 1:
            raise InputError(f"--reference-site: flere referencefiler hedder '{matches[0].name}'. Omdøb dem, så de kan skelnes.")
        sites[matches[0].name] = site.strip()
    return sites


def _run_validation(args, site: str) -> tuple:
    _require_files([*args.reference, *args.logs, args.asset_map, args.review_file])
    if args.review_file and args.review_file.resolve().is_relative_to(args.out.resolve()):
        raise InputError("--review-file må ikke ligge i outputmappen, hvor filer bliver overskrevet. Gem den et andet sted.")
    scopes = parse_scopes(args.scope)
    reference = load_reference(args.reference, site=site, file_sites=_file_sites(args.reference_site, args.reference))
    logs = LogAggregator({"src": args.source_field, "dst": args.dest_field, "timestamp": args.time_field}, site=site, site_confirmed=args.log_site_confirmed)
    for path in args.logs:
        logs.add_file(path)
    multi_site = len(reference.sites) > 1
    asset_map, map_warnings = load_asset_map(args.asset_map, site=site, multi_site=multi_site, known_sites=reference.sites) if args.asset_map else ({}, [])
    decisions, review_warnings = load_decisions(args.review_file, site=site, multi_site=multi_site, known_sites=reference.sites) if args.review_file else ([], [])
    result = reconcile(reference, logs, scopes, asset_map=asset_map, stale_days=args.stale_days, decisions=decisions)
    result.warnings[:0] = map_warnings + review_warnings
    inputs = [("Reference", path) for path in args.reference] + [("Log", path) for path in args.logs]
    inputs += [("Asset-map", args.asset_map)] if args.asset_map else []
    inputs += [("Review", args.review_file)] if args.review_file else []
    result.inputs = [(role, path.name, sha256_file(path)) for role, path in inputs]
    result.summary_rows += [(f"Input ({role}): {name}", digest) for role, name, digest in result.inputs]
    return result, asset_map


def _meta(result: Validation) -> list:
    sources = ", ".join(f"{name} {digest[:12]}" for _, name, digest in result.inputs)
    return [f"Observationsperiode: {result.window_text}   Scope: {result.scope_text}   Værktøj: otvalidate {__version__}", f"Input (navn og SHA-256): {sources}"]


def _print_blockers(result: Validation) -> None:
    if result.blockers:
        print(f"  UFULDSTÆNDIGT GRUNDLAG: {len(result.blockers)} blokerende forhold (exit 3):")
        for line in result.blockers:
            print(f"    - {line}")


def _print_summary(out: Path, result: Validation, facts: dict) -> None:
    print(f"\nRapport: {(out / 'rapport.html').resolve()}")
    print(f"  Adresser: {len(result.asset_rows)}   Flows: {len(result.flow_rows)}   Til gennemgang: {len(result.review_rows)}")
    print(f"  Periode: {result.window_text}")
    _print_blockers(result)
    print(f"  PNG: {facts['png_message']}")
    print(f"  Advarsler: {out / 'validation' / '06_begraensninger_og_advarsler.txt'}")


def _run_one_site(args, site: str, site_label: str, out: Path) -> int:
    result, asset_map = _run_validation(args, site)
    write_validation(result, out / "validation")
    nodes = build_nodes(result.asset_rows, result.flow_rows, asset_map)
    edges, hidden = aggregate_edges(result.flow_rows, nodes, args.min_count)
    facts = write_diagrams(out / "diagram", site_label, nodes, edges, hidden=hidden, min_count=args.min_count, meta=_meta(result),
                           observed_any=result.observed_any, rankdir=args.layout, detail_threshold=args.detail_threshold, blockers=len(result.blockers))
    write_html_report(out / "rapport.html", site_label, result, nodes, facts["svg"], facts)
    _print_summary(out, result, facts)
    return EXIT_INCOMPLETE if result.blockers else 0


def pipeline_main(argv: list) -> int:
    parser = argparse.ArgumentParser(description="Offline OT-validering og dataflow. Læser kun lokale eksportfiler.")
    _add_validation_args(parser)
    parser.add_argument("--all-sites", action="store_true", help="Kør hvert site i referencen for sig, i hver sin mappe under --out")
    parser.add_argument("--site-name", default="", help="Navn i diagram og rapport (standard: --site)")
    parser.add_argument("--layout", choices=("TB", "LR"), default="TB", help="Retning i DOT-filen. SVG er altid zonebånd oppefra og ned")
    parser.add_argument("--min-count", type=int, default=1, help="Skjul flows med færre observationer i diagrammet. Antal skjulte vises i diagrammet")
    parser.add_argument("--detail-threshold", type=int, default=25, help="Lav zonevise detaljediagrammer, når der er flere adresser end dette")
    parser.add_argument("--out", type=Path, default=Path("output"), help="Rodmappe til output")
    args = parser.parse_args(argv)
    args.out = args.out.resolve()  # Short absolute path: `..` segments count against the Windows path limit.

    if args.all_sites:
        if args.site:
            raise InputError("Brug enten --site eller --all-sites.")
        if args.log_site_confirmed:
            raise InputError("--log-site-confirmed kan ikke bruges med --all-sites: den samme log kan ikke bekræftes for alle sites.")
        _require_files(args.reference)
        sites = sorted(load_reference(args.reference, file_sites=_file_sites(args.reference_site, args.reference)).sites)
        if not sites:
            raise InputError("--all-sites kræver en site-kolonne i referencen.")
        used, code = set(), 0
        for site in sites:
            name = safe_name(site)
            while name.casefold() in used:  # Windows folders ignore case.
                name += "_"
            used.add(name.casefold())
            print(f"\n=== {site}")
            code = max(code, _run_one_site(args, site, site, args.out / name))
        return code
    return _run_one_site(args, args.site, args.site_name or args.site or "OT Site", args.out)


def validator_main(argv: list) -> int:
    parser = argparse.ArgumentParser(description="Sammenhold dokumenterede IP'er med passive OT-logs. Kun lokale filer.")
    _add_validation_args(parser)
    parser.add_argument("--out", type=Path, default=Path("ot_validering_rapport"), help="Outputmappe")
    args = parser.parse_args(argv)
    args.out = args.out.resolve()  # Short absolute path: `..` segments count against the Windows path limit.
    result, _ = _run_validation(args, args.site)
    write_validation(result, args.out)
    print(f"Rapport skrevet til: {args.out.resolve()}")
    print(f"  Adresser: {len(result.asset_rows)}   Flows: {len(result.flow_rows)}   Til gennemgang: {len(result.review_rows)}")
    print("  Åbn 02_til_gennemgang.csv i Excel, og læs 06_begraensninger_og_advarsler.txt")
    _print_blockers(result)
    return EXIT_INCOMPLETE if result.blockers else 0


def diagram_main(argv: list) -> int:
    parser = argparse.ArgumentParser(description="Lav dataflow-diagrammer ud fra validatorens CSV-filer.")
    parser.add_argument("--assets", required=True, type=Path, help="01_alle_ip_adresser.csv")
    parser.add_argument("--flows", required=True, type=Path, help="03_kommunikationsflows.csv")
    parser.add_argument("--site-name", default="OT Site", help="Navn i diagrammet")
    parser.add_argument("--out", required=True, type=Path, help="Outputmappe")
    parser.add_argument("--asset-map", type=Path, help="Manuel CSV: IP;Zone;Role;Label;Verified_by;Verified_date")
    parser.add_argument("--layout", choices=("TB", "LR"), default="TB", help="Retning i DOT-filen")
    parser.add_argument("--min-count", type=int, default=1, help="Skjul flows med færre observationer")
    parser.add_argument("--detail-threshold", type=int, default=25, help="Grænse for zonevise detaljediagrammer")
    args = parser.parse_args(argv)
    args.out = args.out.resolve()  # Short absolute path: `..` segments count against the Windows path limit.
    _require_files([args.assets, args.flows, args.asset_map])
    asset_rows = read_table(args.assets, ("IP", "Status", "I_reference"))
    flow_rows = read_table(args.flows, ("Kilde_IP", "Destination_IP"))
    known_sites = {part for row in asset_rows for part in str(row.get("Dokumenteret_anlaeg") or "").split(", ") if part}
    asset_map, warnings = load_asset_map(args.asset_map, known_sites=known_sites) if args.asset_map else ({}, [])
    for warning in warnings:
        print(f"ADVARSEL: {warning}", file=sys.stderr)
    nodes = build_nodes(asset_rows, flow_rows, asset_map)
    edges, hidden = aggregate_edges(flow_rows, nodes, args.min_count)
    limits = args.assets.with_name("06_begraensninger_og_advarsler.txt")
    blockers = sum(line.startswith("- BLOKERENDE") for line in limits.read_text(encoding="utf-8").splitlines()) if limits.is_file() else 0
    meta = [f"Lavet alene ud fra {args.assets.name} og {args.flows.name}: inputkontrollen er ikke gentaget. Værktøj: otvalidate {__version__}"]
    facts = write_diagrams(args.out, args.site_name, nodes, edges, hidden=hidden, min_count=args.min_count, meta=meta, observed_any=any(row.get("Observation") not in (None, "", "IKKE_OBSERVERET") for row in asset_rows) or bool(flow_rows),
                           rankdir=args.layout, detail_threshold=args.detail_threshold, blockers=blockers)
    print(f"Diagrammer skrevet til: {args.out.resolve()}")
    print(f"  PNG: {facts['png_message']}")
    if blockers:
        print(f"  UFULDSTÆNDIGT GRUNDLAG: {blockers} blokerende forhold fra {limits.name} (exit 3).")
    return EXIT_INCOMPLETE if blockers else 0


def run_pipeline(argv=None) -> int:
    return _guarded(pipeline_main, argv)


def run_validator(argv=None) -> int:
    return _guarded(validator_main, argv)


def run_diagram(argv=None) -> int:
    return _guarded(diagram_main, argv)
