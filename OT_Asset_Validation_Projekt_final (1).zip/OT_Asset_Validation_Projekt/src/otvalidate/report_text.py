"""Spreadsheet formula protection, shared by everything that writes or reads back CSV."""
from __future__ import annotations

FORMULA_STARTERS = "=+-@＝＋－＠"


def csv_safe(value) -> str:
    """Stop spreadsheet formula injection from log and documentation text."""
    text = str(value if value is not None else "").replace("\x00", "")
    stripped = text.lstrip()
    if stripped[:1] and (stripped[0] in FORMULA_STARTERS or text[0] in "\t\r"):
        return "'" + text
    return text


def csv_unsafe(text: str) -> str:
    """Undo csv_safe when our own CSV is read back; a normal leading apostrophe is kept."""
    if text[:1] == "'" and text[1:].lstrip()[:1] in tuple(FORMULA_STARTERS):
        return text[1:]
    return text
