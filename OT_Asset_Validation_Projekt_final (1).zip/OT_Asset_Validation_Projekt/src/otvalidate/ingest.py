"""Read documentation and passive log exports into evidence. Input is treated as untrusted data."""
from __future__ import annotations

from collections import Counter
import codecs
import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import ipaddress
import json
from pathlib import Path
import re
from typing import Callable, Iterator, NamedTuple
import unicodedata

MAX_JSON_BYTES = 512 * 1024 * 1024  # A .json array is loaded whole; JSONL streams.
MAX_FLATTEN_DEPTH = 32
MAX_DETAILS_IN_WARNING = 10
MAX_TEXT_LINE = 8192  # Key=value matching is quadratic in the worst case, so free text is cut here.
MAX_PDF_BYTES = 256 * 1024 * 1024
MAX_PDF_PAGES = 5000
PDF_IMAGE_SHARE_BLOCKS = 0.25  # A larger picture than this on a text page may hold addresses we cannot read.
MIN_YEAR, MAX_YEAR = 1990, 2100  # Outside this range a timestamp is a data error, not an observation.

IP_PATTERN = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![0-9A-Za-z]|\.\d)")
# Looks like an address that went wrong: spaces, commas, a line break, or letters read as digits by OCR.
NEAR_MISS_PATTERN = re.compile(r"(?<![\d.,])(?:\d{1,3}(?:\s*\.\s*[\dOoIl]{1,3}){3}|\d{1,3}(?:,\d{1,3}){3})(?![\dA-Za-z]|[.,]\d)")
NETMASKS = {str(ipaddress.IPv4Network(f"0.0.0.0/{bits}").netmask) for bits in range(33)}
MESSAGE_FIELDS = {"message", "msg", "log", "raw", "eventoriginal"}


class InputError(ValueError):
    """An input problem the user can fix. Reported without a traceback."""


def normalize_name(name) -> str:
    """Ignore punctuation and case, so `source.ip` and `SourceIP` compare equal."""
    return re.sub(r"[^a-z0-9]+", "", str(name).lower())


# Most specific alias first: a column named `source` is often the log source, not an address.
ALIASES = {
    "src": ("srcip", "sourceip", "sourceipv4", "sourceaddress", "ipsrc", "srcaddr", "clientip", "originip",
            "initiatorip", "idorigh", "origh", "src", "source"),
    "dst": ("dstip", "destinationip", "destinationipv4", "destinationaddress", "destip", "destaddress", "ipdst",
            "dstaddr", "serverip", "targetip", "responderip", "idresph", "resph", "dst", "destination"),
    "single_ip": ("ip", "ipaddress", "ipaddr", "ipv4", "deviceip", "assetip", "hostip"),
    "timestamp": ("timestamp", "eventtimestamp", "eventtime", "observedat", "eventcreated", "datetime", "tstime",
                  "time", "ts", "date", "firstseen"),
    "protocol": ("protocol", "proto", "networkprotocol", "applicationprotocol", "appprotocol", "serviceprotocol", "service"),
    "port": ("dstport", "destinationport", "destport", "dport", "dpt", "serverport", "idrespp", "respp", "port"),
    "src_mac": ("srcmac", "sourcemac", "macsrc", "ethsrc", "macaddress", "mac"),
    "dst_mac": ("dstmac", "destinationmac", "macdst", "ethdst"),
    "device": ("devicename", "assetname", "hostname", "computername", "host", "name"),
    "site": ("site", "location", "plant", "facility", "vandvaerk", "anlaeg", "anlæg"),
}
ALIAS_RANK = {kind: {normalize_name(alias): rank for rank, alias in enumerate(names)} for kind, names in ALIASES.items()}
NESTED_SUFFIXES = {"src": ("sourceip", "srcip", "clientip"), "dst": ("destinationip", "destip", "dstip", "targetip")}


def clean_text(value, limit: int = 200) -> str:
    """Drop control and invisible format characters (incl. bidi overrides); flatten newlines; cap length."""
    text = re.sub(r"[\r\n\t]+", " ", str(value if value is not None else ""))
    if not text.isascii() or not text.isprintable():
        text = "".join(ch for ch in text if unicodedata.category(ch) not in ("Cc", "Cf", "Cs"))
    return text.strip()[:limit]


@lru_cache(maxsize=1 << 10)
def normalize_site(name) -> str:
    """Site names compare without regard to case, repeated spaces, NBSP or Unicode form."""
    return " ".join(unicodedata.normalize("NFKC", str(name)).split()).casefold()


class ExtractedIps(NamedTuple):
    valid: list
    invalid: list


def _is_network_declaration(token: str, following: str) -> bool:
    """True for 192.0.2.0/24. A host written as 192.0.2.10/24 or /32 is still a host."""
    prefix = re.match(r"/(\d{1,2})(?!\d)", following)
    if not prefix or int(prefix.group(1)) >= 32:
        return False
    try:
        interface = ipaddress.ip_interface(f"{token}/{prefix.group(1)}")
    except ValueError:
        return False
    return interface.ip == interface.network.network_address


def extract_ips(value, *, skip_cidr: bool = False, skip_netmasks: bool = False) -> ExtractedIps:
    """Find IPv4-shaped tokens. Invalid ones are returned, never silently dropped."""
    text = "" if value is None else str(value)
    valid, invalid = [], []
    for match in IP_PATTERN.finditer(text):
        token = match.group()
        # A subnet declaration such as 192.0.2.0/24 is not evidence of a host at .0.
        if skip_cidr and _is_network_declaration(token, text[match.end():]):
            continue
        if skip_netmasks and token in NETMASKS:
            continue
        try:
            ipaddress.IPv4Address(token)  # Rejects leading zeros: octal or decimal cannot be decided here.
        except ipaddress.AddressValueError:
            invalid.append(token)
            continue
        if token not in valid:
            valid.append(token)
    return ExtractedIps(valid, invalid)


def near_miss_ips(text: str) -> list:
    """Address-like strings that are not accepted as addresses. Reported to a person, never repaired."""
    exact = [match.span() for match in IP_PATTERN.finditer(text)]
    misses = []
    for match in NEAR_MISS_PATTERN.finditer(text):
        if not any(start < match.end() and match.start() < end for start, end in exact):
            misses.append(re.sub(r"\s+", " ", match.group()))
    return misses


@lru_cache(maxsize=1 << 16)
def _cell_ips(text: str) -> tuple:
    """Return (ips, invalid_count, ipv6_count) for a source/destination cell."""
    found = extract_ips(text)
    if found.valid or found.invalid:
        return tuple(found.valid), len(found.invalid), 0
    if ":" in text:
        try:
            ipaddress.IPv6Address(text.strip().strip("[]").split("%")[0])
            return (), 0, 1
        except ipaddress.AddressValueError:
            pass
    return (), 1, 0


_ISO_FRACTION = re.compile(r"(\d{2}:\d{2}:\d{2})[.,]\d+")
_ISO_COMPACT_OFFSET = re.compile(r"([+-]\d{2})(\d{2})$")
_DAY_FIRST_FORMATS = ("%d-%m-%Y %H:%M:%S", "%d/%m/%Y %H:%M:%S", "%d.%m.%Y %H:%M:%S", "%Y/%m/%d %H:%M:%S",
                      "%d-%m-%Y %H:%M", "%d/%m/%Y %H:%M", "%d.%m.%Y %H:%M", "%d-%m-%Y", "%d/%m/%Y", "%d.%m.%Y")


@lru_cache(maxsize=1 << 14)
def parse_time(value):
    """Return (iso, "UTC") or (iso, "NO_TZ"), or None. Naive times are never assumed to be UTC."""
    text = str(value).strip()
    if not text:
        return None
    try:
        if re.fullmatch(r"\d{10}(?:\.\d+)?", text):
            parsed = datetime.fromtimestamp(float(text), tz=timezone.utc)
        elif re.fullmatch(r"\d{13}", text):
            parsed = datetime.fromtimestamp(int(text) / 1000, tz=timezone.utc)
        else:
            parsed = _parse_calendar_time(text)
    except (ValueError, OverflowError, OSError):
        return None
    if parsed is None or not MIN_YEAR <= parsed.year <= MAX_YEAR:
        return None
    if parsed.tzinfo:
        return parsed.astimezone(timezone.utc).isoformat(timespec="seconds"), "UTC"
    return parsed.isoformat(timespec="seconds"), "NO_TZ"


def _parse_calendar_time(text: str):
    iso = _ISO_FRACTION.sub(r"\1", text)
    iso = re.sub(r"\s*(?:Z|UTC)$", "+00:00", iso)
    iso = _ISO_COMPACT_OFFSET.sub(r"\1:\2", iso) if "T" in iso or ":" in iso else iso
    try:
        return datetime.fromisoformat(iso)
    except ValueError:
        pass
    for fmt in _DAY_FIRST_FORMATS:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


@lru_cache(maxsize=1 << 12)
def normalize_mac(value):
    digits = re.sub(r"[^0-9A-Fa-f]", "", str(value))
    if len(digits) != 12 or not re.fullmatch(r"[\s0-9A-Fa-f:.\-]+", str(value)):
        return None
    digits = digits.upper()
    return ":".join(digits[i:i + 2] for i in range(0, 12, 2))


_IANA_PROTOCOLS = {"1": "ICMP", "6": "TCP", "17": "UDP"}


@lru_cache(maxsize=1 << 10)
def normalize_protocol(value) -> str:
    text = clean_text(value, 30).upper()
    return _IANA_PROTOCOLS.get(text, text)


@lru_cache(maxsize=1 << 14)
def normalize_port(value):
    """Return the port as text, "" when absent, None when present but invalid."""
    text = str(value).strip()
    if not text:
        return ""
    if re.fullmatch(r"\d{1,5}(?:\.0+)?", text) and int(text.split(".")[0]) <= 65535:
        return text.split(".")[0]
    return None


@lru_cache(maxsize=1 << 12)
def _clean_host(value) -> str:
    return clean_text(value, 100)


def _detect_encoding(path: Path) -> str:
    with path.open("rb") as stream:
        sample = stream.read(1024 * 1024)
    if sample.startswith(codecs.BOM_UTF8):
        return "utf-8-sig"
    if sample.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return "utf-16"
    try:
        codecs.getincrementaldecoder("utf-8")().decode(sample, final=False)
        return "utf-8"
    except UnicodeDecodeError:
        return "cp1252"  # Danish Excel "Save as CSV".


def open_text(path: Path, newline=None):
    return path.open("r", encoding=_detect_encoding(path), errors="replace", newline=newline)


def _pick_delimiter(header: str) -> str:
    return max(";,\t|", key=lambda delimiter: len(next(csv.reader([header], delimiter=delimiter))))


def csv_records(path: Path, on_bad: Callable = lambda *_: None) -> Iterator[tuple]:
    csv.field_size_limit(16 * 1024 * 1024)
    with open_text(path, newline="") as stream:
        header_line = ""
        for line in stream:
            if line.strip():
                header_line = line.strip("\r\n")
                break
        if not header_line:
            return
        stream.seek(0)
        line_no = 0
        try:
            delimiter = "\t" if path.suffix.lower() == ".tsv" else _pick_delimiter(header_line)
            reader = csv.reader(stream, delimiter=delimiter)
            header = None
            for row in reader:
                start, line_no = line_no + 1, reader.line_num
                if not any(cell.strip() for cell in row):
                    continue
                if header is None:
                    header = [cell.strip() for cell in row]
                    continue
                if line_no > start:
                    # Legal in CSV, but an unclosed quote looks the same and swallows the rows after it.
                    on_bad(start, f"felt over {line_no - start + 1} linjer; tjek for uafsluttet anførselstegn")
                yield line_no, dict(zip(header, row))
        except csv.Error as exc:
            raise InputError(f"{path.name}: CSV kan ikke læses efter linje {line_no}: {exc}") from exc


def _flatten(node, prefix: str = "", depth: int = 0, out=None) -> dict:
    out = {} if out is None else out
    for key, value in node.items():
        label = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, dict):
            if depth >= MAX_FLATTEN_DEPTH:
                raise RecursionError("for dybt indlejret")
            _flatten(value, label, depth + 1, out)
        elif isinstance(value, list):
            out[label] = ", ".join(str(v) for v in value if isinstance(v, (str, int, float)))
        elif value is not None:
            out[label] = value
    return out


def _flat_record(event, location, on_bad):
    if not isinstance(event, dict):
        on_bad(location, "ikke et JSON-objekt")
        return None
    try:
        return _flatten(event)
    except RecursionError:
        on_bad(location, "for dybt indlejret")
        return None


def json_records(path: Path, on_bad: Callable) -> Iterator[tuple]:
    if path.stat().st_size > MAX_JSON_BYTES:
        raise InputError(f"{path.name}: større end {MAX_JSON_BYTES // 1024 ** 2} MB. Eksportér som JSONL, som kan læses løbende.")
    try:
        with open_text(path) as stream:
            data = json.load(stream)
    except (ValueError, RecursionError) as exc:
        raise InputError(f"{path.name}: ugyldig JSON ({clean_text(exc)})") from exc
    if isinstance(data, dict):
        data = next((data[k] for k in ("events", "records", "results", "data", "logs") if isinstance(data.get(k), list)), [data])
    if not isinstance(data, list):
        raise InputError(f"{path.name}: JSON skal indeholde objekter eller en liste af objekter.")
    for index, event in enumerate(data, 1):
        record = _flat_record(event, index, on_bad)
        if record is not None:
            yield index, record


def jsonl_records(path: Path, on_bad: Callable) -> Iterator[tuple]:
    with open_text(path) as stream:
        for line_no, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except (ValueError, RecursionError) as exc:
                on_bad(line_no, type(exc).__name__)
                continue
            record = _flat_record(event, line_no, on_bad)
            if record is not None:
                yield line_no, record


_KEY_VALUE = re.compile(r'''([A-Za-z_][\w.\-]*)=("[^"]*"|'[^']*'|[^\s,;]+)''')
_ARROW = re.compile(r"((?:\d{1,3}\.){3}\d{1,3})(?::\d+)?\s*(?:->|→)\s*((?:\d{1,3}\.){3}\d{1,3})(?::(\d+))?")
_LEADING_ISO = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:\s?(?:Z|UTC|[+-]\d{2}:?\d{2}))?")


def text_records(path: Path, on_bad: Callable = lambda *_: None) -> Iterator[tuple]:
    """Plain log lines. Direction is only taken from explicit key=value or `a -> b` notation."""
    with open_text(path) as stream:
        for line_no, line in enumerate(stream, 1):
            if not line.strip():
                continue
            if len(line) > MAX_TEXT_LINE:
                on_bad(line_no, f"afkortet til {MAX_TEXT_LINE} tegn")
                line = line[:MAX_TEXT_LINE]
            record = {"message": line}
            for key, value in _KEY_VALUE.findall(line):
                record[key] = value.strip("\"'")
            arrow = _ARROW.search(line)
            if arrow:
                record["src_ip"], record["dst_ip"] = arrow.group(1), arrow.group(2)
                if arrow.group(3):
                    record["dst_port"] = arrow.group(3)
            stamp = _LEADING_ISO.search(line)
            if stamp:
                record.setdefault("timestamp", stamp.group())
            yield line_no, record


def read_records(path: Path, on_bad: Callable = lambda *_: None) -> Iterator[tuple]:
    """Yield (location, flat record). Bad records go to on_bad(location, reason)."""
    suffix = path.suffix.lower()
    if suffix in (".csv", ".tsv"):
        return csv_records(path, on_bad)
    if suffix == ".json":
        return json_records(path, on_bad)
    if suffix in (".jsonl", ".ndjson"):
        return jsonl_records(path, on_bad)
    if suffix in (".txt", ".log"):
        return text_records(path, on_bad)
    raise InputError(f"Ukendt logformat '{suffix}' ({path.name}). Understøttet: CSV, TSV, JSON, JSONL, LOG, TXT.")


FIELD_KINDS = ("src", "dst", "single_ip", "timestamp", "protocol", "port", "src_mac", "dst_mac", "device")


def find_field(keys, kind: str):
    """Best column for a kind, by alias specificity. Nested names such as event.source.ip are accepted."""
    ranks = ALIAS_RANK[kind]
    best, best_rank = None, len(ranks)
    for key in keys:
        rank = ranks.get(normalize_name(key), best_rank)
        if rank < best_rank:
            best, best_rank = key, rank
    if best is None:
        for suffix in NESTED_SUFFIXES.get(kind, ()):
            for key in keys:
                if normalize_name(key).endswith(suffix):
                    return key
    return best


def detect_fields(keys, overrides: dict) -> dict:
    fields = {}
    for kind in FIELD_KINDS:
        wanted = overrides.get(kind)
        if wanted:
            normalized = normalize_name(wanted)
            fields[kind] = next((key for key in keys if normalize_name(key) == normalized), None)
        else:
            fields[kind] = find_field(keys, kind)
    return fields


@dataclass
class Documented:
    where: set = field(default_factory=set)
    devices: set = field(default_factory=set)
    sites: set = field(default_factory=set)
    macs: set = field(default_factory=set)
    kinds: set = field(default_factory=set)  # STRUKTURERET (inventory table) or KANDIDAT (free text: PDF/TXT)


@dataclass
class Reference:
    known: dict = field(default_factory=dict)
    other_site: dict = field(default_factory=dict)
    sites: set = field(default_factory=set)
    warnings: list = field(default_factory=list)
    blockers: list = field(default_factory=list)  # The result cannot be trusted as complete until these are resolved.
    site_filter: str = ""
    unresolved: dict = field(default_factory=dict)  # Documented, but no source says which site they belong to.
    ip_sites: dict = field(default_factory=dict)
    pdf_pages: list = field(default_factory=list)
    file_sites: dict = field(default_factory=dict)
    site_keys: set = field(default_factory=set)

    def add_site(self, name: str) -> None:
        key = normalize_site(name)
        if key not in self.site_keys:  # Keep one spelling per site, so variants give one folder.
            self.site_keys.add(key)
            self.sites.add(name)


@dataclass
class PdfPage:
    file: str
    page: int
    chars: int
    ips: int
    image_share: float
    drawings: int
    verdict: str  # OK | TOM | LILLE_BILLEDE | INGEN_TEKST | BILLEDE_MED_TEKST | SKJULT_TEKST | UDEN_SIKKER_AFLAESNING
    details: str = ""


def _limited_warning(prefix: str, details: list) -> str:
    shown = "; ".join(details[:MAX_DETAILS_IN_WARNING])
    extra = f" (+{len(details) - MAX_DETAILS_IN_WARNING} flere)" if len(details) > MAX_DETAILS_IN_WARNING else ""
    return f"{prefix}: {shown}{extra}"


def _document(ref: Reference, ip: str, row_site: str, site_key: str):
    """Where a documented address belongs under the site filter. None means another site."""
    if row_site:
        ref.add_site(row_site)
        ref.ip_sites.setdefault(ip, set()).add(normalize_site(row_site))
        if site_key and normalize_site(row_site) != site_key:
            ref.other_site.setdefault(ip, set()).add(row_site)
            return None
    elif site_key:
        return ref.unresolved.setdefault(ip, Documented())
    doc = ref.known.setdefault(ip, Documented())
    if row_site:
        doc.sites.add(row_site)
    return doc


def _load_reference_table(path: Path, ref: Reference, site: str) -> None:
    site_key = normalize_site(site)
    file_site = ref.file_sites.get(path.name, "")
    invalid, cidrs, odd_rows, bad_macs, conflicts, no_ip = [], [], [], [], [], []
    fields = None
    for line_no, record in csv_records(path, lambda location, reason: odd_rows.append(f"linje {location}: {reason}")):
        if fields is None:
            keys = tuple(record)
            ip_key = find_field(keys, "single_ip") or find_field(keys, "src")
            if not ip_key:
                raise InputError(f"Reference '{path.name}' mangler IP-kolonne (fx ip, device_ip). Kolonner: {', '.join(keys)}")
            fields = (ip_key, find_field(keys, "device"), find_field(keys, "site"), find_field(keys, "src_mac"))
        ip_key, device_key, site_col, mac_key = fields
        cell = record.get(ip_key) or ""
        found = extract_ips(cell, skip_cidr=True, skip_netmasks=True)
        invalid += [f"{token} (linje {line_no})" for token in found.invalid]
        misses = near_miss_ips(cell)
        invalid += [f"{token} (linje {line_no})" for token in misses]
        if cell.strip() and not misses and not found.invalid and not extract_ips(cell).valid:
            invalid.append(f"{clean_text(cell, 40)} (linje {line_no})")
        if not cell.strip() and any((value or "").strip() for value in record.values()):
            no_ip.append(f"linje {line_no}")
        if len(extract_ips(cell, skip_netmasks=True).valid) > len(found.valid):
            cidrs.append(f"{clean_text(cell, 40)} (linje {line_no})")
        column_site = clean_text(record.get(site_col), 120) if site_col else ""
        if column_site and file_site and normalize_site(column_site) != normalize_site(file_site):
            conflicts.append(f"linje {line_no}: {column_site}")
        row_site = column_site or file_site
        if row_site:
            ref.add_site(row_site)
        for ip in found.valid:
            doc = _document(ref, ip, row_site, site_key)
            if doc is None:
                continue
            doc.where.add(f"{path.name}:linje {line_no}")
            doc.kinds.add("STRUKTURERET")
            if device_key and clean_text(record.get(device_key)):
                doc.devices.add(clean_text(record.get(device_key), 120))
            if mac_key and record.get(mac_key):
                mac = normalize_mac(record[mac_key])
                if mac:
                    doc.macs.add(mac)
                else:
                    bad_macs.append(f"{clean_text(record[mac_key], 40)} (linje {line_no})")
    if invalid:
        ref.blockers.append(_limited_warning(f"{path.name}: IP-værdier der ikke kan læses, er IKKE brugt. Ret dokumentationen", invalid))
    if conflicts:
        ref.blockers.append(_limited_warning(f"{path.name}: rækkens site afviger fra --reference-site '{file_site}'; rækkens site er brugt", conflicts))
    if no_ip:
        ref.warnings.append(_limited_warning(f"{path.name}: rækker uden IP-adresse er ikke med i afstemningen", no_ip))
    if cidrs:
        ref.warnings.append(_limited_warning(f"{path.name}: subnet i IP-kolonnen er ikke behandlet som assets", cidrs))
    if odd_rows:
        ref.warnings.append(_limited_warning(f"{path.name}: tjek rækker", odd_rows))
    if bad_macs:
        ref.warnings.append(_limited_warning(f"{path.name}: ugyldige MAC-adresser ignoreret", bad_macs))


def _add_candidates(ref: Reference, text: str, location: str, file_site: str, site_key: str, problems: list) -> int:
    found = extract_ips(text, skip_cidr=True, skip_netmasks=True)
    problems += [f"ugyldig {token} ({location})" for token in found.invalid]
    problems += [f"uklar '{token}' ({location})" for token in near_miss_ips(text)]
    for ip in found.valid:
        doc = _document(ref, ip, file_site, site_key)
        if doc is not None:
            doc.where.add(location)
            doc.kinds.add("KANDIDAT")
    return len(found.valid)


def _read_pdf_page(page, path: Path, index: int, ref: Reference, file_site: str, site_key: str, problems: list) -> PdfPage:
    text = page.get_text("text")
    area = abs(page.rect) or 1
    image_share = min(1.0, sum(abs(page.rect & info["bbox"]) for info in page.get_image_info()) / area)
    drawings = len(page.get_drawings())
    hidden = sum(1 for span in page.get_texttrace() if span["type"] == 3) if text.strip() else 0
    page_problems = []
    ips = _add_candidates(ref, text, f"{path.name}:side {index}", file_site, site_key, page_problems)
    problems += page_problems
    if not text.strip():
        verdict = "INGEN_TEKST" if image_share or drawings else "TOM"
    elif hidden:
        verdict = "SKJULT_TEKST"  # An OCR layer or invisible text: what is read may differ from what is shown.
    elif image_share >= PDF_IMAGE_SHARE_BLOCKS:
        verdict = "BILLEDE_MED_TEKST"
    elif page_problems:
        verdict = "UDEN_SIKKER_AFLAESNING"
    elif image_share:
        verdict = "LILLE_BILLEDE"  # Usually a logo, but its content is not read either.
    else:
        verdict = "OK"
    return PdfPage(path.name, index, len(text.strip()), ips, round(image_share, 2), drawings, verdict, "; ".join(page_problems)[:300])


def _load_reference_pdf(path: Path, ref: Reference, site_key: str) -> None:
    if path.stat().st_size > MAX_PDF_BYTES:
        raise InputError(f"{path.name}: større end {MAX_PDF_BYTES // 1024 ** 2} MB. Eksportér listen som CSV.")
    try:
        import pymupdf  # Optional: only used to read text from local PDFs.
    except ImportError as exc:
        raise InputError("PDF-understøttelse kræver PyMuPDF (pip install -r requirements.txt). Eksportér ellers listen som CSV.") from exc
    pymupdf.TOOLS.mupdf_display_errors(False)
    pymupdf.TOOLS.mupdf_display_warnings(False)
    pymupdf.TOOLS.reset_mupdf_warnings()
    try:
        doc = pymupdf.open(str(path))
    except Exception as exc:  # PyMuPDF raises library-specific types for damaged files.
        raise InputError(f"{path.name}: PDF kan ikke åbnes ({clean_text(exc)})") from exc
    file_site = ref.file_sites.get(path.name, "")
    try:
        if doc.needs_pass:
            raise InputError(f"{path.name}: PDF er adgangskodebeskyttet og kan ikke læses. Eksportér en åben version.")
        if doc.page_count == 0:
            raise InputError(f"{path.name}: PDF har ingen sider.")
        if doc.page_count > MAX_PDF_PAGES:
            raise InputError(f"{path.name}: {doc.page_count} sider overstiger grænsen på {MAX_PDF_PAGES} sider. Del dokumentet op.")
        problems, pages = [], []
        for index in range(doc.page_count):
            try:
                pages.append(_read_pdf_page(doc[index], path, index + 1, ref, file_site, site_key, problems))
            except Exception as exc:  # A damaged page must not take the rest of the file with it.
                pages.append(PdfPage(path.name, index + 1, 0, 0, 0, 0, "INGEN_TEKST", f"Siden kunne ikke læses: {clean_text(exc, 100)}"))
        repaired = doc.is_repaired
    finally:
        doc.close()
    ref.pdf_pages += pages
    name = path.name
    if repaired:
        ref.blockers.append(f"{name}: filen er beskadiget og blev repareret ved indlæsning. Sider eller rækker kan mangle uden at det kan ses. Skaf en intakt kopi.")
    for verdict, text in (("INGEN_TEKST", "ingen læsbar tekst (scannet eller tegnet som grafik): adresser på disse sider er IKKE læst"),
                          ("BILLEDE_MED_TEKST", "store billeder ud over teksten: adresser i billederne er IKKE læst"),
                          ("SKJULT_TEKST", "skjult tekst eller OCR-lag: de læste adresser er ikke nødvendigvis dem, der ses på siden")):
        affected = [str(page.page) for page in pages if page.verdict == verdict]
        if affected:
            ref.blockers.append(f"{name}, side {', '.join(affected)}: {text}.")
    if problems:
        ref.blockers.append(_limited_warning(f"{name}: tekst der ligner adresser, men ikke er accepteret. Ret kilden, eller tjek manuelt", problems))
    small = [str(page.page) for page in pages if page.verdict == "LILLE_BILLEDE"]
    if small:
        ref.warnings.append(f"{name}, side {', '.join(small)}: små billeder er ikke læst. Tjek at de ikke indeholder adresser.")
    count = sum(page.ips for page in pages)
    if count:
        ref.warnings.append(f"PDF {name}: {count} IP-forekomster er KANDIDATER (kan være gateway, DNS, eksempel osv.). Se 07_pdf_udtraek.csv.")
    else:
        ref.warnings.append(f"Ingen IPv4-adresser fundet i PDF'en: {name}")


def load_reference(paths, site: str = "", file_sites: dict | None = None) -> Reference:
    """file_sites assigns a site to a whole file, which is the only source of site for PDF and TXT."""
    site_key = normalize_site(site or "")
    ref = Reference(site_filter=site or "", file_sites=dict(file_sites or {}))
    unknown = sorted(set(ref.file_sites) - {path.name for path in paths})
    if unknown:
        raise InputError(f"--reference-site nævner filer, der ikke er angivet som reference: {', '.join(unknown)}")
    for name in ref.file_sites.values():
        ref.add_site(name)
    for path in paths:
        suffix = path.suffix.lower()
        if suffix in (".csv", ".tsv"):
            _load_reference_table(path, ref, site or "")
        elif suffix == ".pdf":
            _load_reference_pdf(path, ref, site_key)
        elif suffix == ".txt":
            problems = []
            with open_text(path) as stream:
                for line_no, line in enumerate(stream, 1):
                    _add_candidates(ref, line, f"{path.name}:linje {line_no}", ref.file_sites.get(path.name, ""), site_key, problems)
            if problems:
                ref.blockers.append(_limited_warning(f"{path.name}: tekst der ligner adresser, men ikke er accepteret. Ret kilden, eller tjek manuelt", problems))
        else:
            raise InputError(f"Reference skal være PDF, TXT, CSV eller TSV: {path.name}")
    if site and site_key not in ref.site_keys:
        raise InputError(f"Site '{site}' findes ikke i referencen. Fundne sites: {', '.join(sorted(ref.sites)) or '(ingen)'}. PDF og TXT har intet site; angiv det med --reference-site FIL=SITE.")
    unread = [f"{page.file} side {page.page}" for page in ref.pdf_pages if page.verdict == "INGEN_TEKST"]
    if not ref.known and not ref.unresolved and not ref.other_site:
        detail = f" Ulæselige PDF-sider ({len(unread)}): {', '.join(unread[:10])}. Scannede sider kræver godkendt OCR uden for værktøjet." if unread else ""
        raise InputError(f"Ingen dokumenterede IPv4-adresser fundet i referencefilerne.{detail}")
    for ip in (*ref.known, *ref.unresolved):
        if ip in ref.known:
            ref.other_site.pop(ip, None)
    for ip in list(ref.unresolved):
        if ip in ref.known:
            del ref.unresolved[ip]
    if ref.unresolved:
        ref.blockers.append(_limited_warning(f"Dokumenterede adresser uden site er IKKE regnet til '{site}'. Angiv site i kilden eller med --reference-site", sorted(ref.unresolved)))
    if not site_key and ref.sites:
        blank = sorted(ip for ip, doc in ref.known.items() if not doc.sites)
        if blank:
            ref.blockers.append(_limited_warning("Nogle kilder angiver site, men disse adresser har intet og kan høre til et hvilket som helst site. Angiv site i kilden eller med --reference-site", blank))
    return ref


@dataclass
class Observed:
    src: int = 0
    dst: int = 0
    mentioned: int = 0
    first: dict = field(default_factory=dict)
    last: dict = field(default_factory=dict)
    macs: set = field(default_factory=set)
    hosts: set = field(default_factory=set)
    files: set = field(default_factory=set)
    site_unresolved: int = 0


@dataclass
class FlowStat:
    count: int = 0
    first: dict = field(default_factory=dict)
    last: dict = field(default_factory=dict)
    files: set = field(default_factory=set)
    site_unresolved: int = 0


@dataclass
class FileInfo:
    name: str
    sha256: str
    skipped: bool = False
    rows: int = 0
    rows_with_ip: int = 0
    rows_without_direction: int = 0
    bad_records: int = 0
    invalid_ip_values: int = 0
    ipv6_values: int = 0
    multi_ip_values: int = 0
    bad_ports: int = 0
    rows_other_site: int = 0
    rows_site_unresolved: int = 0
    other_site_values: set = field(default_factory=set)
    ts_ok: int = 0
    ts_bad: int = 0
    ts_missing: int = 0
    first: dict = field(default_factory=dict)
    last: dict = field(default_factory=dict)
    field_maps: list = field(default_factory=list)


def note_time(first: dict, last: dict, iso: str, kind: str) -> None:
    if iso < first.get(kind, "￿"):
        first[kind] = iso
    if iso > last.get(kind, ""):
        last[kind] = iso


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class LogAggregator:
    """Streams log files. Memory grows with unique IPs and flows, not with the number of rows."""

    def __init__(self, overrides: dict | None = None, site: str = "", site_confirmed: bool = False):
        self.overrides = {kind: name for kind, name in (overrides or {}).items() if name}
        self.site_key = normalize_site(site or "")
        self.site_confirmed = site_confirmed
        self.log_sites: set = set()
        self.blockers: list = []
        self.stats: dict = {}
        self.flows: dict = {}
        self.files: list = []
        self.days: Counter = Counter()
        self.warnings: list = []
        self.total_rows = 0

    def add_file(self, path: Path) -> None:
        info = FileInfo(path.name, sha256_file(path))
        earlier = next((f for f in self.files if f.sha256 == info.sha256), None)
        self.files.append(info)
        if earlier:
            info.skipped = True
            self.warnings.append(f"{path.name} er identisk med {earlier.name} og er sprunget over, så trafik ikke tælles dobbelt.")
            return

        bad_samples = []

        def on_bad(location, reason):
            info.bad_records += 1
            if len(bad_samples) < MAX_DETAILS_IN_WARNING:
                bad_samples.append(f"linje {location} ({reason})")

        fixed_schema = path.suffix.lower() in (".csv", ".tsv")
        schemas, last_keys, fields = {}, None, {}
        seen_kinds, has_ip_field = set(), False
        for _, record in read_records(path, on_bad):
            info.rows += 1
            keys = tuple(record)
            if keys != last_keys:
                last_keys = keys
                fields = schemas.get(keys)
                if fields is None:
                    if len(schemas) > 4096:
                        schemas.clear()
                    fields = schemas[keys] = detect_fields(keys, self.overrides)
                    fields["site"] = find_field(keys, "site")
                    self._note_schema(info, fields, keys, fixed_schema, path)
                    seen_kinds.update(kind for kind, key in fields.items() if key)
                    has_ip_field = has_ip_field or bool(fields["src"] or fields["dst"] or fields["single_ip"]
                                                        or any(normalize_name(k) in MESSAGE_FIELDS for k in keys))
            self._add_record(info, record, fields, path.name)

        missing = [name for kind, name in self.overrides.items() if kind not in seen_kinds and info.rows]
        if missing:
            raise InputError(f"{path.name}: det angivne felt '{missing[0]}' findes ikke i filen.")
        if info.rows and not has_ip_field:
            raise InputError(f"{path.name}: ingen IP-felter genkendt. Brug --source-field/--dest-field. Felter: {', '.join(clean_text(k, 40) for k in last_keys)}")
        self.total_rows += info.rows
        self._file_warnings(info, seen_kinds, bad_samples)

    def _note_schema(self, info, fields, keys, fixed_schema, path) -> None:
        if fixed_schema:
            for kind, name in self.overrides.items():
                if not fields.get(kind):
                    raise InputError(f"{path.name}: det angivne felt '{name}' findes ikke. Kolonner: {', '.join(clean_text(k, 40) for k in keys)}")
        mapped = tuple(clean_text(fields[kind], 60) if fields[kind] else "" for kind in FIELD_KINDS)
        if any(mapped) and mapped not in info.field_maps and len(info.field_maps) < 20:
            info.field_maps.append(mapped)

    def _cell(self, info, record, key) -> tuple:
        value = record.get(key) if key else None
        if value is None or value == "":
            return ()
        ips, invalid, ipv6 = _cell_ips(str(value))
        info.invalid_ip_values += invalid
        info.ipv6_values += ipv6
        if len(ips) > 1:
            info.multi_ip_values += 1
        return ips

    def _add_record(self, info, record, fields, filename) -> None:
        site_field = fields["site"]
        row_site = _clean_host(record[site_field]) if site_field and record.get(site_field) else ""
        unresolved = False
        if self.site_key:
            if not row_site:
                info.rows_site_unresolved += 1
                unresolved = not self.site_confirmed
            elif normalize_site(row_site) != self.site_key:
                info.rows_other_site += 1
                if len(info.other_site_values) < 5:
                    info.other_site_values.add(row_site)
                return
        elif row_site and len(self.log_sites) < 50:
            self.log_sites.add(row_site)
        src_ips = self._cell(info, record, fields["src"])
        dst_ips = self._cell(info, record, fields["dst"])
        other_ips = self._cell(info, record, fields["single_ip"])

        stamp = None
        time_key = fields["timestamp"]
        raw_time = record.get(time_key) if time_key else None
        if raw_time is None or raw_time == "":
            info.ts_missing += 1
        else:
            stamp = parse_time(str(raw_time))
            if stamp:
                info.ts_ok += 1
                note_time(info.first, info.last, *stamp)
                self.days[stamp[0][:10]] += 1
            else:
                info.ts_bad += 1

        if not (src_ips or dst_ips or other_ips):
            for key, value in record.items():
                if normalize_name(key) in MESSAGE_FIELDS:
                    other_ips = tuple(extract_ips(value).valid)
                    if other_ips:
                        break
        if not (src_ips or dst_ips or other_ips):
            return
        info.rows_with_ip += 1
        if other_ips and not src_ips and not dst_ips:
            info.rows_without_direction += 1

        host = _clean_host(record[fields["device"]]) if fields["device"] and record.get(fields["device"]) else ""
        src_mac = _mac_text(record, fields["src_mac"])
        dst_mac = _mac_text(record, fields["dst_mac"])
        for ip in src_ips:
            self._note(ip, "src", stamp, filename, src_mac, host, unresolved)
        for ip in dst_ips:
            self._note(ip, "dst", stamp, filename, dst_mac, "", unresolved)
        for ip in other_ips:
            if ip not in src_ips and ip not in dst_ips:
                self._note(ip, "mentioned", stamp, filename, "", host, unresolved)

        if src_ips and dst_ips:
            proto = normalize_protocol(record[fields["protocol"]]) if fields["protocol"] and record.get(fields["protocol"]) else ""
            port = normalize_port(record[fields["port"]]) if fields["port"] and record.get(fields["port"]) not in (None, "") else ""
            if port is None:
                info.bad_ports += 1
                port = ""
            for src in src_ips:
                for dst in dst_ips:
                    key = (src, dst, proto, port)
                    flow = self.flows.get(key)
                    if flow is None:
                        flow = self.flows[key] = FlowStat()
                    flow.count += 1
                    flow.files.add(filename)
                    flow.site_unresolved += unresolved
                    if stamp:
                        note_time(flow.first, flow.last, *stamp)

    def _note(self, ip, role, stamp, filename, mac, host, unresolved=False) -> None:
        entry = self.stats.get(ip)
        if entry is None:
            entry = self.stats[ip] = Observed()
        setattr(entry, role, getattr(entry, role) + 1)
        entry.site_unresolved += unresolved
        entry.files.add(filename)
        if mac and len(entry.macs) < 10:
            entry.macs.add(mac)
        if host and len(entry.hosts) < 10:
            entry.hosts.add(host)
        if stamp:
            note_time(entry.first, entry.last, *stamp)

    def _file_warnings(self, info, seen_kinds, bad_samples) -> None:
        name, warn = info.name, self.warnings.append
        if info.rows == 0 and not info.bad_records:
            warn(f"Logfilen {name} er tom.")
        if info.bad_records:
            warn(_limited_warning(f"{name}: {info.bad_records} poster er sprunget over, afkortet eller kan være læst forkert", bad_samples))
        if info.rows_other_site:
            values = ", ".join(sorted(info.other_site_values))
            warn(f"{name}: {info.rows_other_site} rækker hører til et andet site ifølge loggens site-kolonne ({values}) og er ikke talt med.")
            if info.rows_other_site == info.rows:
                self.blockers.append(f"{name}: alle {info.rows} rækker blev sorteret fra af site-kolonnen (værdier: {values}). Filen har intet bidraget. Er kolonnen virkelig et site?")
        if info.rows_site_unresolved:
            if self.site_confirmed:
                warn(f"{name}: {info.rows_site_unresolved} logrækker uden site er talt med, fordi brugeren har bekræftet, at loggen hører til sitet.")
            else:
                self.blockers.append(f"{name}: {info.rows_site_unresolved} logrækker har intet site og er talt med på ren IP-match. Bekræft med --log-site-confirmed, hvis loggen kun dækker dette site.")
        if info.rows > info.rows_other_site and not info.rows_with_ip:
            warn(f"{name}: ingen IP-adresser fundet i {info.rows} poster. Filen har ikke bidraget med observationer; tjek om det er den rigtige eksport.")
        if info.rows and "src" in seen_kinds and "dst" not in seen_kinds:
            warn(f"{name}: ingen destinations-kolonne fundet. Der kan ikke dannes flows fra filen.")
        elif info.rows and "dst" in seen_kinds and "src" not in seen_kinds:
            warn(f"{name}: ingen kilde-kolonne fundet. Der kan ikke dannes flows fra filen.")
        if info.rows_without_direction:
            warn(f"{name}: {info.rows_without_direction} poster nævner IP'er uden kilde/destination. Retningen er ukendt og er ikke gættet.")
        if info.invalid_ip_values:
            warn(f"{name}: {info.invalid_ip_values} værdier i IP-felter er ikke gyldige IPv4-adresser og er ignoreret.")
        if info.ipv6_values:
            warn(f"{name}: {info.ipv6_values} IPv6-værdier er ikke analyseret. Værktøjet understøtter kun IPv4, så IPv6-trafik mangler i resultatet.")
        if info.multi_ip_values:
            warn(f"{name}: {info.multi_ip_values} felter indeholder flere IP'er. Hvert par er talt som et flow, så antal kan være for højt.")
        if info.bad_ports:
            warn(f"{name}: {info.bad_ports} ugyldige portværdier er vist uden port.")
        if info.ts_bad:
            warn(f"{name}: {info.ts_bad} tidsstempler kunne ikke tolkes. Brug --time-field, hvis feltet er forkert.")
        if info.rows_with_ip and not info.ts_ok:
            warn(f"{name}: ingen brugbare tidsstempler. Observationsperioden for filen er ukendt.")
        for other in self.files:
            if other is not info and _windows_overlap(info, other):
                warn(f"{name} og {other.name} overlapper i tid. Samme trafik kan være talt flere gange, hvis to sensorer ser den.")


def _mac_text(record, key) -> str:
    if not key or not record.get(key):
        return ""
    return normalize_mac(record[key]) or ""  # Placeholders such as "unknown" are not evidence.


def _windows_overlap(a: FileInfo, b: FileInfo) -> bool:
    return any(kind in b.first and a.first[kind] <= b.last[kind] and b.first[kind] <= a.last[kind] for kind in a.first)
