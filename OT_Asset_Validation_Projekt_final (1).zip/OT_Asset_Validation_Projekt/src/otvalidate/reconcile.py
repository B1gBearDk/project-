"""Compare documentation with observations. Documentation, observation and verification stay separate."""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
import ipaddress

from .ingest import FIELD_KINDS, InputError, LogAggregator, Observed, Reference, normalize_site
from .review import REVIEW_COLUMNS, apply_decisions, evidence_id

MAC_SHARED_BY_IPS = 3  # The same MAC on this many IPs looks like a routed hop, not a device identity.

ACTIONS = {
    "DOKUMENTERET_KILDE_OBSERVERET": "Bekræft fysisk enhed/identitet; trafikkilde er ikke endeligt bevis",
    "DOKUMENTERET_KUN_DESTINATION": "Bekræft enhed; destination alene dokumenterer ikke aktiv enhed",
    "DOKUMENTERET_KUN_NAEVNT": "Bekræft kilde/destination og identitet fra mere strukturerede logs",
    "DOKUMENTERET_IKKE_OBSERVERET": "Tjek sensordækning, observationsperiode og evt. driftspersonale",
    "DOKUMENTERET_SITE_UAFKLARET": "Afklar hvilket site adressen hører til; den er ikke regnet til dette site",
    "DOKUMENTERET_ANDET_SITE": "Dokumenteret på et andet site; vurder om trafikken mellem sites er forventet",
    "IKKE_I_REFERENCE_IN_SCOPE": "Undersøg, om IP'en er udokumenteret asset, DHCP, NAT eller fejlkilde",
    "UDENFOR_SCOPE": "Ikke automatisk en lokal OT-afvigelse; vurder om relevant",
    "IKKE_I_REFERENCE_SCOPE_UKENDT": "Fastlæg scope, før IP'en kaldes udokumenteret OT-asset",
    "LOGISK_ADRESSE": "Ikke et asset; adressen viser hvor pakker er sendt hen",
}
DEVIATION_ACTIONS = {
    "MAC_AFVIGER": "Sammenlign MAC med enhed/switchport; kan også skyldes routing eller udskiftet enhed",
    "FLERE_MAC": "Flere MAC på samme IP: tjek IP-konflikt, redundans, NAT eller udskiftning",
    "NAVN_KONFLIKT": "Dokumentationen har flere navne for samme IP; afklar hvilket der gælder",
    "NAVN_PAA_FLERE_IP": "Samme navn på flere IP'er; bekræft at det er én enhed med flere adresser",
    "DOK_UDEN_FOR_SCOPE": "Dokumenteret IP uden for scope: ret scope eller dokumentation",
    "SIDST_SET_FOER_LOGSLUT": "Har ikke været set i slutningen af perioden; tjek om enheden er flyttet eller slukket",
    "IP_PAA_FLERE_SITES": "Samme IP er dokumenteret på flere sites; observationer kan ikke henføres ud fra IP alene",
    "KUN_OBS_UDEN_SITE": "Kun set i logrækker uden site; trafikken kan høre til et andet site",
    "MULIG_BROADCAST": "Slutter på .255 i et bredt scope; kan være subnet-broadcast. Tjek det faktiske subnet",
}
PRIORITY_1_DEVIATIONS = {"MAC_AFVIGER", "FLERE_MAC", "NAVN_KONFLIKT", "DOK_UDEN_FOR_SCOPE", "IP_PAA_FLERE_SITES"}
PRIORITY_2_STATUSES = {"DOKUMENTERET_KUN_DESTINATION", "DOKUMENTERET_KUN_NAEVNT", "DOKUMENTERET_IKKE_OBSERVERET"}

ASSET_HEADERS = ("IP", "Status", "I_reference", "I_scope", "Observation", "Dokumentationstype", "Verificering", "Afvigelser", "Prioritet",
                 "Adressetype", "Antal_som_kilde", "Antal_som_destination", "Antal_kun_naevnt", "Foerste_observation", "Seneste_observation",
                 "Dokumenteret_enhed", "Dokumenteret_anlaeg", "Dokumenteret_MAC", "Observeret_MAC", "Observeret_hostname",
                 "Reference_kilde", "Log_kilde", "Foreslaaet_naeste_skridt", "Evidens_ID", *REVIEW_COLUMNS)
FLOW_HEADERS = ("Kilde_IP", "Destination_IP", "Protokol", "Destination_port", "Antal_observationer", "Foerste_observation", "Seneste_observation",
                "Kilde_i_reference", "Destination_i_reference", "Kilde_i_scope", "Destination_i_scope", "Log_kilde", "Antal_uden_site")
FIELD_HEADERS = ("Fil", "Kilde_IP_felt", "Destination_IP_felt", "Generelt_IP_felt", "Tid_felt", "Protokol_felt", "Port_felt",
                 "Kilde_MAC_felt", "Destination_MAC_felt", "Enhedsnavn_felt")
FIXED_LIMITS = (
    "IP-match er IKKE bevis for fysisk asset, fysisk placering, enhedstype, sikkerhed eller godkendt trafik.",
    "Et observeret flow er ikke en dokumenteret fysisk forbindelse. Manglende observation er ikke bevis for manglende enhed.",
    "Resultatet afhænger af sensorens placering og periode. Trafik, sensoren ikke ser (fx lokalt på en switch), mangler.",
    "NAT, DHCP, virtuelle enheder og flere IP'er pr. enhed kan få én IP til at dække flere enheder eller omvendt.",
    "Dokumentation i PDF/TXT er KANDIDATER: den kan indeholde gateways, eksempler og forældede adresser.",
    "Kun lokale filer er læst. Ingen netværkskald, scanning eller eksterne API'er.",
)


def parse_scopes(values) -> list:
    networks = []
    for value in values:
        for item in str(value).split(","):
            item = item.strip()
            if not item:
                continue
            try:
                network = ipaddress.ip_network(item, strict=False)
            except ValueError as exc:
                raise InputError(f"Ugyldigt scope '{item}': {exc}") from exc
            if network.version != 4:
                raise InputError(f"Kun IPv4-scope understøttes: {item}")
            networks.append(network)
    return networks


def logical_address_type(ip: str, scopes) -> str:
    """Name the kind of non-host address, or "" for an ordinary address."""
    address = ipaddress.IPv4Address(ip)
    if address.is_unspecified:
        return "ubestemt (0.0.0.0)"
    if str(address) == "255.255.255.255":
        return "broadcast"
    if address.is_multicast:
        return "multicast"
    if address.is_loopback:
        return "loopback"
    if address.is_reserved:
        return "reserveret"
    for net in scopes:
        if net.prefixlen <= 30:
            if address == net.broadcast_address:
                return "subnet-broadcast"
            if address == net.network_address:
                return "netværksadresse"
    return ""


def _timeline(values: dict) -> str:
    # Times without zone are shown separately: they are never treated as UTC.
    return " | ".join(f"{value}{' (uden tidszone)' if kind == 'NO_TZ' else ''}" for kind, value in sorted(values.items()))


def _join(items, max_items: int = 5) -> str:
    parts = sorted(str(item) for item in items)
    if len(parts) > max_items:
        return ", ".join(parts[:max_items]) + f" ... (+{len(parts) - max_items})"
    return ", ".join(parts)


def _observation(stat: Observed) -> str:
    if stat.src and stat.dst:
        return "KILDE_OG_DESTINATION"
    if stat.src:
        return "KILDE"
    if stat.dst:
        return "KUN_DESTINATION"
    return "KUN_NAEVNT" if stat.mentioned else "IKKE_OBSERVERET"


def _status(doc, stat: Observed, scoped, other_site: bool, logical: str, unresolved: bool = False) -> str:
    if unresolved:
        return "DOKUMENTERET_SITE_UAFKLARET"
    if doc:
        if stat.src:
            return "DOKUMENTERET_KILDE_OBSERVERET"
        if stat.dst:
            return "DOKUMENTERET_KUN_DESTINATION"
        return "DOKUMENTERET_KUN_NAEVNT" if stat.mentioned else "DOKUMENTERET_IKKE_OBSERVERET"
    if logical:
        return "LOGISK_ADRESSE"
    if other_site:
        return "DOKUMENTERET_ANDET_SITE"
    if scoped is True:
        return "IKKE_I_REFERENCE_IN_SCOPE"
    return "UDENFOR_SCOPE" if scoped is False else "IKKE_I_REFERENCE_SCOPE_UKENDT"


def _priority(status: str, deviations: list):
    if PRIORITY_1_DEVIATIONS.intersection(deviations) or status == "DOKUMENTERET_SITE_UAFKLARET" or (status == "IKKE_I_REFERENCE_IN_SCOPE" and "MULIG_BROADCAST" not in deviations):
        return 1
    if status in PRIORITY_2_STATUSES or "SIDST_SET_FOER_LOGSLUT" in deviations or "KUN_OBS_UDEN_SITE" in deviations:
        return 2
    if status == "IKKE_I_REFERENCE_SCOPE_UKENDT" or deviations:
        return 3
    return ""


def _window(logs: LogAggregator) -> tuple:
    first, last = {}, {}
    for info in logs.files:
        for kind, value in info.first.items():
            first[kind] = min(first.get(kind, value), value)
        for kind, value in info.last.items():
            last[kind] = max(last.get(kind, value), value)
    return first, last


def _day_gaps(logs: LogAggregator) -> list:
    if len(logs.days) < 2:
        return []
    days = sorted(date.fromisoformat(day) for day in logs.days)
    present = set(days)
    return [(days[0] + timedelta(n)).isoformat() for n in range((days[-1] - days[0]).days) if days[0] + timedelta(n) not in present]


def _is_stale(stat: Observed, last: dict, stale_days: int) -> bool:
    """Stale only when old in every time kind seen: UTC and zone-free times are not comparable."""
    shared = [kind for kind in stat.last if kind in last]
    return bool(shared) and all(datetime.fromisoformat(stat.last[kind]) < datetime.fromisoformat(last[kind]) - timedelta(days=stale_days) for kind in shared)


@dataclass
class Validation:
    asset_rows: list = field(default_factory=list)
    review_rows: list = field(default_factory=list)
    flow_rows: list = field(default_factory=list)
    field_rows: list = field(default_factory=list)
    summary_rows: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    blockers: list = field(default_factory=list)
    pdf_pages: list = field(default_factory=list)
    review_log: list = field(default_factory=list)
    inputs: list = field(default_factory=list)  # (role, file name, sha256)
    site: str = ""
    window_text: str = "ukendt"
    scope_text: str = "IKKE_DEFINERET"
    observed_any: bool = False
    files: list = field(default_factory=list)


def reconcile(ref: Reference, logs: LogAggregator, scopes, asset_map=None, stale_days: int = 7, decisions=None) -> Validation:
    asset_map = asset_map or {}
    result = Validation(warnings=list(ref.warnings) + list(logs.warnings), files=logs.files, blockers=list(ref.blockers) + list(logs.blockers),
                        pdf_pages=list(ref.pdf_pages), site=ref.site_filter)
    first, last = _window(logs)

    ips_by_mac = defaultdict(set)
    for ip, stat in logs.stats.items():
        for mac in stat.macs:
            ips_by_mac[mac].add(ip)
    shared_macs = {mac for mac, ips in ips_by_mac.items() if len(ips) >= MAC_SHARED_BY_IPS}
    ips_by_name = defaultdict(set)
    for ip, doc in ref.known.items():
        for name in doc.devices:
            ips_by_name[name].add(ip)

    def in_scope(ip):
        return any(ipaddress.IPv4Address(ip) in net for net in scopes) if scopes else None

    def scope_text(ip):
        scoped = in_scope(ip)
        return "IKKE_OPLYST" if scoped is None else "JA" if scoped else "NEJ"

    counts = Counter()
    relevant = set(ref.known) | set(ref.unresolved) | set(logs.stats)
    empty = Observed()
    for ip in sorted(relevant, key=lambda value: int(ipaddress.IPv4Address(value))):
        doc = ref.known.get(ip)
        unresolved_doc = None if doc else ref.unresolved.get(ip)
        shown_doc = doc or unresolved_doc
        stat = logs.stats.get(ip, empty)
        scoped = in_scope(ip)
        logical = "" if shown_doc else logical_address_type(ip, scopes)
        status = _status(doc, stat, scoped, ip in ref.other_site, logical, unresolved_doc is not None)
        counts[status] += 1

        deviations = []
        macs = stat.macs - shared_macs
        if doc and doc.macs and macs - doc.macs:
            deviations.append("MAC_AFVIGER")
        if len(macs) > 1:
            deviations.append("FLERE_MAC")
        if doc and len(doc.devices) > 1:
            deviations.append("NAVN_KONFLIKT")
        if doc and any(len(ips_by_name[name]) > 1 for name in doc.devices):
            deviations.append("NAVN_PAA_FLERE_IP")
        if doc and scoped is False:
            deviations.append("DOK_UDEN_FOR_SCOPE")
        if doc and len(ref.ip_sites.get(ip, ())) > 1:
            deviations.append("IP_PAA_FLERE_SITES")
        if not logical and _is_stale(stat, last, stale_days):
            deviations.append("SIDST_SET_FOER_LOGSLUT")
        if stat.site_unresolved and stat.site_unresolved == stat.src + stat.dst + stat.mentioned:
            deviations.append("KUN_OBS_UDEN_SITE")
        if status == "IKKE_I_REFERENCE_IN_SCOPE" and ip.endswith(".255"):
            deviations.append("MULIG_BROADCAST")

        entry = asset_map.get(ip)
        verified = f"MANUELT_VERIFICERET {entry.verified}" if entry and entry.verified else "IKKE_VERIFICERET"
        priority = _priority(status, deviations)
        actions = [ACTIONS[status]] + [DEVIATION_ACTIONS[code] for code in deviations]
        row = {
            "IP": ip, "Status": status, "I_reference": "JA" if doc else "UAFKLARET" if unresolved_doc else "NEJ", "I_scope": scope_text(ip),
            "Observation": _observation(stat), "Dokumentationstype": _join(shown_doc.kinds) if shown_doc else "",
            "Verificering": verified, "Afvigelser": ", ".join(deviations), "Prioritet": priority, "Adressetype": logical or "vært",
            "Antal_som_kilde": stat.src, "Antal_som_destination": stat.dst, "Antal_kun_naevnt": stat.mentioned,
            "Foerste_observation": _timeline(stat.first), "Seneste_observation": _timeline(stat.last),
            "Dokumenteret_enhed": _join(shown_doc.devices) if shown_doc else "", "Dokumenteret_anlaeg": _join(doc.sites) if doc else _join(ref.other_site.get(ip, ())),
            "Dokumenteret_MAC": _join(shown_doc.macs) if shown_doc else "", "Observeret_MAC": _join(stat.macs), "Observeret_hostname": _join(stat.hosts),
            "Reference_kilde": _join(shown_doc.where) if shown_doc else "", "Log_kilde": _join(stat.files), "Foreslaaet_naeste_skridt": "; ".join(actions),
            "Evidens_ID": evidence_id(ref.site_filter, ip, status, shown_doc.devices if shown_doc else (), shown_doc.kinds if shown_doc else (), shown_doc.macs if shown_doc else (), stat.macs, stat.hosts, deviations),
        }
        result.asset_rows.append(row)
    result.review_log, review_warnings = apply_decisions(result.asset_rows, decisions or [])
    result.warnings.extend(review_warnings)
    settled = {"GODKENDT", "AFVIST"}  # They remain in the full table and the review log.
    # A reopened decision goes first in the queue. The full table keeps its evidence as it was.
    queue = [{**row, "Prioritet": 1} if row["Review_status"] == "FORAELDET" else row for row in result.asset_rows
             if (row["Prioritet"] != "" or row["Review_status"] == "FORAELDET") and row["Review_status"] not in settled]
    result.review_rows = sorted(queue, key=lambda row: (row["Prioritet"], row["Review_status"] != "FORAELDET"))  # Stable: IP order within.

    ordered_flows = sorted(logs.flows.items(), key=lambda item: (-item[1].count, int(ipaddress.IPv4Address(item[0][0])), int(ipaddress.IPv4Address(item[0][1])), item[0][2], item[0][3]))
    for (src, dst, proto, port), flow in ordered_flows:
        result.flow_rows.append({
            "Kilde_IP": src, "Destination_IP": dst, "Protokol": proto, "Destination_port": port, "Antal_observationer": flow.count,
            "Foerste_observation": _timeline(flow.first), "Seneste_observation": _timeline(flow.last),
            "Kilde_i_reference": "JA" if src in ref.known else "NEJ", "Destination_i_reference": "JA" if dst in ref.known else "NEJ",
            "Kilde_i_scope": scope_text(src), "Destination_i_scope": scope_text(dst), "Log_kilde": _join(flow.files), "Antal_uden_site": flow.site_unresolved})

    for info in logs.files:
        for mapped in info.field_maps:
            result.field_rows.append({"Fil": info.name, **{header: value or "(ikke fundet)" for header, value in zip(FIELD_HEADERS[1:], mapped)}})
    assert len(FIELD_HEADERS) == len(FIELD_KINDS) + 1

    result.scope_text = ", ".join(map(str, scopes)) if scopes else "IKKE_DEFINERET"
    result.window_text = " | ".join(f"{first[kind]} til {last[kind]}{' (uden tidszone)' if kind == 'NO_TZ' else ''}" for kind in sorted(first)) or "ukendt"
    result.observed_any = bool(logs.stats)
    _finish_warnings(result, ref, logs, scopes, asset_map, shared_macs, relevant)
    result.summary_rows = [
        ("Datakvalitet", f"UFULDSTAENDIG: {len(result.blockers)} blokerende forhold" if result.blockers else "Ingen blokerende forhold fundet (ikke det samme som fuldstaendigt)"),
        ("Site-filter", ref.site_filter or "(intet)"), ("Observationsperiode", result.window_text), ("Defineret scope", result.scope_text),
        ("Dokumenterede unikke IP'er", len(ref.known)), ("Unikke observerede IP'er", len(logs.stats)), ("Antal logposter", logs.total_rows),
        ("Logposter uden identificerbare IPv4", sum(f.rows - f.rows_with_ip for f in logs.files)),
        ("Logposter hvor IP-retning er ukendt", sum(f.rows_without_direction for f in logs.files)),
        ("Logposter med genkendeligt tidsstempel", sum(f.ts_ok for f in logs.files)),
        ("Logposter der ikke kunne læses", sum(f.bad_records for f in logs.files)),
        ("Logposter uden site-oplysning", sum(f.rows_site_unresolved for f in logs.files)),
        ("Logposter fra andet site (ikke talt med)", sum(f.rows_other_site for f in logs.files)),
        ("Dokumenterede adresser uden site", len(ref.unresolved)),
        ("Unikke flows med kendt retning", len(logs.flows)), ("Antal IP'er til gennemgang", len(result.review_rows)),
        *sorted(counts.items()),
        *[(f"Logfil: {f.name} (rækker)", "sprunget over: identisk fil" if f.skipped else f.rows) for f in logs.files],
        *[(f"Logfil: {f.name} (sha256)", f.sha256) for f in logs.files]]
    return result


def _finish_warnings(result, ref, logs, scopes, asset_map, shared_macs, relevant) -> None:
    warn = result.warnings.append
    if not scopes:
        warn("Intet --scope: IP'er uden for dokumentationen kan være eksterne eller fra andre sites. De er IKKE kaldt udokumenterede assets.")
    if not ref.site_filter and len(ref.sites) > 1:
        result.blockers.append(f"Referencen dækker flere sites ({', '.join(sorted(ref.sites))}), men der er ikke valgt ét, så de er blandet i dette resultat. Brug --site eller --all-sites.")
    foreign = sorted(name for name in logs.log_sites if normalize_site(name) not in ref.site_keys)
    if not ref.site_filter and foreign and (ref.site_keys or len(foreign) > 1):
        result.blockers.append(f"Logfilerne nævner sites, der ikke er valgt eller dokumenteret ({_join(foreign)}), og de rækker er talt med. Brug --site eller --all-sites.")
    if not logs.stats:
        warn("Ingen logposter med IP-adresser blev læst. Alle dokumenterede assets står som ikke observeret, men det siger intet om, hvorvidt de findes.")
    gaps = _day_gaps(logs)
    if gaps:
        shown = ", ".join(gaps[:5]) + (f" (+{len(gaps) - 5} flere)" if len(gaps) > 5 else "")
        warn(f"Dage uden logposter inden for perioden ({len(gaps)}): {shown}. Tjek om eksporten eller sensoren har huller.")
    if any("NO_TZ" in info.first for info in logs.files):
        warn("Nogle tidsstempler mangler tidszone. De er markeret 'uden tidszone' og antages IKKE at være UTC.")
    for mac in sorted(shared_macs):
        warn(f"MAC {mac} ses på mindst {MAC_SHARED_BY_IPS} IP'er og ligner en router/gateway. Den bruges ikke til MAC-sammenligning, og sensoren ser muligvis routet trafik.")
    unused = sorted(ip for ip in asset_map if ip not in relevant)
    if unused:
        warn(f"Asset-map indeholder IP'er uden dokumentation eller observation, som ikke vises: {_join(unused)}")
    result.warnings.extend(FIXED_LIMITS)
