"""Deterministic hierarchical SVG: fixed zone bands, a card grid and orthogonal flow routes.

Vertical position is decided by the zone order alone, never by traffic direction, so the drawing
cannot suggest a topology. Routes run in channels between rows and gutters between columns, and each
route gets its own track, so lines never pass behind a card and labels never overlap each other.
A label slides along its route to avoid crossing lines, but in a dense diagram it can still cover one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from html import escape

MARGIN = 24
RAIL = 132  # Zone-name column.
GUTTER_MIN = 22
GUTTER_TRACK = 9
CHANNEL_TRACK = 18
CHANNEL_MIN = 24
CHANNEL_EDGE = 14
LABEL_CHAR_PX = 5.7
LABEL_PAD_PX = 10
TOP_PORTS = (0.06, 0.46)  # Top and bottom ports use separate halves, so stubs in a column never coincide.
BOTTOM_PORTS = (0.54, 0.94)
MIN_WIDTH = 1000

INK = "#111827"
MUTED = "#4b5563"
SILENT = "#9ca3af"
AMBER = "#92400e"
TEAL = "#0d5f59"
BAND_A = "#f3f4f6"
BAND_B = "#fafafa"
RAIL_FILL = "#e5e7eb"


@dataclass
class Card:
    id: str
    title: str
    mono: str
    role: str
    evidence: str
    fill: str = "documented"  # documented | undocumented | logical
    stroke: str = "solid"  # solid | dashed | dotted | silent
    verified: str = ""
    deviation: str = ""
    tooltip: str = ""
    review: str = ""


@dataclass
class Band:
    name: str
    note: str
    cards: list


@dataclass
class Edge:
    src: str
    dst: str
    label: str
    dashed: bool = False
    title: str = ""


@dataclass
class Diagram:
    title: str
    subtitle: str
    meta: list
    notices: list
    bands: list
    edges: list
    legend: bool = True
    max_cols: int = 6
    card_w: int = 190


@dataclass
class Route:
    edge: Edge
    points: list
    label_box: tuple = None
    label_center: tuple = None


@dataclass
class Layout:
    width: int = 0
    height: int = 0
    header_h: int = 0
    content_bottom: int = 0
    card_w: int = 190
    card_h: int = 54
    bands: dict = field(default_factory=dict)
    cards: dict = field(default_factory=dict)
    routes: list = field(default_factory=list)


def _place_cards(diagram: Diagram, cols: int, neighbours: dict) -> dict:
    """Grid position per card. Barycentre sweeps pull connected cards towards each other."""
    row_offset, offsets = 0, {}
    for band in diagram.bands:
        offsets[band.name] = row_offset
        row_offset += max(1, (len(band.cards) + cols - 1) // cols)
    position = {}
    bands = diagram.bands
    for sweep in range(4):
        for band in (bands if sweep % 2 == 0 else list(reversed(bands))):
            members = {card.id for card in band.cards}
            desired = {}
            for card in band.cards:
                targets = [position[n][1] for n in neighbours.get(card.id, ()) if n in position and n not in members]
                desired[card.id] = sum(targets) / len(targets) if targets else None
            ranked = sorted(enumerate(band.cards), key=lambda item: (desired[item[1].id] is None, desired[item[1].id] or 0, item[0]))
            ordered = [card for _, card in ranked]
            for chunk_index in range(0, len(ordered), cols):
                chunk = ordered[chunk_index:chunk_index + cols]
                slots, previous = [], -1
                for card in chunk:
                    wish = desired[card.id]
                    previous = max(previous + 1, round(wish) if wish is not None else previous + 1)
                    slots.append(previous)
                slots[-1] = min(slots[-1], cols - 1)
                for i in range(len(slots) - 2, -1, -1):
                    slots[i] = min(slots[i], slots[i + 1] - 1)
                for card, slot in zip(chunk, slots):
                    position[card.id] = (offsets[band.name] + chunk_index // cols, slot)
    return position


def _first_fit(items: list, gap: float = 0) -> dict:
    """Interval partitioning: item key -> track index. items are (start, end, key)."""
    ends, tracks = [], {}
    for start, end, key in sorted(items, key=lambda item: (item[0], item[1], item[2])):
        for index, track_end in enumerate(ends):
            if start > track_end + gap:
                ends[index] = end
                tracks[key] = index
                break
        else:
            tracks[key] = len(ends)
            ends.append(end)
    return tracks


def _label_width(text: str) -> float:
    return len(text) * LABEL_CHAR_PX + LABEL_PAD_PX


def header_height(diagram: Diagram) -> int:
    return MARGIN + 52 + 16 * len(diagram.meta) + 24 * len(diagram.notices)


def compute_layout(diagram: Diagram) -> Layout:
    layout = Layout(card_w=diagram.card_w, header_h=header_height(diagram))
    cards = {card.id: card for band in diagram.bands for card in band.cards}
    if not cards:
        layout.width, layout.height, layout.content_bottom = MIN_WIDTH, layout.header_h + 60, layout.header_h
        return layout
    extra_lines = max((bool(c.verified) + bool(c.deviation) + bool(c.review) for c in cards.values()), default=0)
    layout.card_h = 54 + 13 * extra_lines
    edges = [edge for edge in diagram.edges if edge.src in cards and edge.dst in cards]

    cols = max(1, min(diagram.max_cols, max(len(band.cards) for band in diagram.bands)))
    neighbours = {}
    for edge in edges:
        neighbours.setdefault(edge.src, []).append(edge.dst)
        neighbours.setdefault(edge.dst, []).append(edge.src)
    position = _place_cards(diagram, cols, neighbours)
    rows = 1 + max(row for row, _ in position.values())

    # Sides and channels. Channel c lies above row c; channel `rows` lies below the last row.
    plans, port_lists = [], {}
    for index, edge in enumerate(edges):
        ra, ca = position[edge.src]
        rb, cb = position[edge.dst]
        if ra < rb:
            plan = {"a_side": "bottom", "b_side": "top", "ch_a": ra + 1, "ch_b": rb}
        elif ra > rb:
            plan = {"a_side": "top", "b_side": "bottom", "ch_a": ra, "ch_b": rb + 1}
        else:
            plan = {"a_side": "bottom", "b_side": "bottom", "ch_a": ra + 1, "ch_b": ra + 1}
        plans.append(plan)
        port_lists.setdefault((edge.src, plan["a_side"]), []).append((cb, index, 0))
        port_lists.setdefault((edge.dst, plan["b_side"]), []).append((ca, index, 1))

    ports = {}
    for (card_id, side), entries in port_lists.items():
        low, high = TOP_PORTS if side == "top" else BOTTOM_PORTS
        for slot, (_, index, end) in enumerate(sorted(entries)):
            ports[(index, end)] = low + (high - low) * (slot + 1) / (len(entries) + 1)

    # Vertical routes between non-adjacent rows go through a gutter.
    gutter_items = {g: [] for g in range(cols + 1)}
    gutter_of = {}
    for index, (edge, plan) in enumerate(zip(edges, plans)):
        if plan["ch_a"] == plan["ch_b"]:
            continue
        ax = position[edge.src][1] + ports[(index, 0)]
        bx = position[edge.dst][1] + ports[(index, 1)]
        candidates = {position[edge.src][1], position[edge.src][1] + 1, position[edge.dst][1], position[edge.dst][1] + 1}
        best = min(sorted(candidates), key=lambda g: (abs(ax - g) + abs(bx - g), len(gutter_items[g]), g))
        gutter_of[index] = best
        low, high = sorted((plan["ch_a"], plan["ch_b"]))
        gutter_items[best].append((low, high, index))
    gutter_track, gutter_tracks_n = {}, {}
    for gutter, items in gutter_items.items():
        tracks = _first_fit(items)
        gutter_track.update(tracks)
        gutter_tracks_n[gutter] = 1 + max(tracks.values()) if tracks else 0

    # Real x coordinates can now be fixed; horizontal tracks are then assigned in pixels.
    x = MARGIN + RAIL
    gutter_x, col_x = {}, {}
    for gutter in range(cols + 1):
        gutter_x[gutter] = x
        x += max(GUTTER_MIN, GUTTER_TRACK * (gutter_tracks_n[gutter] + 1))
        if gutter < cols:
            col_x[gutter] = x
            x += diagram.card_w
    content_right = x
    layout.width = max(int(content_right + MARGIN), MIN_WIDTH)
    right_limit = layout.width - MARGIN

    def port_x(index, end):
        card_id = edges[index].src if end == 0 else edges[index].dst
        return col_x[position[card_id][1]] + ports[(index, end)] * diagram.card_w

    channel_items = {c: [] for c in range(rows + 1)}
    label_centers = {}
    for index, (edge, plan) in enumerate(zip(edges, plans)):
        ax, bx = port_x(index, 0), port_x(index, 1)
        if index in gutter_of:
            vx = gutter_x[gutter_of[index]] + GUTTER_TRACK * (gutter_track[index] + 1)
            segments = [(plan["ch_a"], ax, vx, False, "a"), (plan["ch_b"], vx, bx, True, "b")]
            plan["vx"] = vx
        else:
            segments = [(plan["ch_b"], ax, bx, True, "b")]
        for channel, x0, x1, carries_label, part in segments:
            low, high = min(x0, x1), max(x0, x1)
            if carries_label and edge.label:
                width = _label_width(edge.label)
                center = (x0 + x1) / 2
                center = max(MARGIN + RAIL + width / 2, min(right_limit - width / 2, center))
                label_centers[index] = (center, width)
                low, high = min(low, center - width / 2), max(high, center + width / 2)
            channel_items[channel].append((low, high, (index, part)))

    channel_tracks, channel_height = {}, {}
    for channel, items in channel_items.items():
        tracks = _first_fit(items, gap=8)
        channel_tracks.update(tracks)
        needed = CHANNEL_TRACK * (max(tracks.values()) + 2) if tracks else 0
        floor = CHANNEL_EDGE if channel in (0, rows) else CHANNEL_MIN
        channel_height[channel] = max(floor, needed)

    y = layout.header_h
    channel_top, row_y = {}, {}
    for row in range(rows):
        channel_top[row] = y
        y += channel_height[row]
        row_y[row] = y
        y += layout.card_h
    channel_top[rows] = y
    y += channel_height[rows]
    layout.content_bottom = y

    band_rows = {}
    for band in diagram.bands:
        band_rows[band.name] = sorted({position[card.id][0] for card in band.cards}) if band.cards else []
    for band_index, band in enumerate(diagram.bands):
        used = band_rows[band.name]
        if not used:
            continue
        top_channel, bottom_channel = used[0], used[-1] + 1
        top = channel_top[top_channel] + (channel_height[top_channel] / 2 if band_index else 0)
        bottom = channel_top[bottom_channel] + (channel_height[bottom_channel] / 2 if band_index < len(diagram.bands) - 1 else channel_height[bottom_channel])
        layout.bands[band.name] = (MARGIN, top, layout.width - MARGIN, bottom)

    for card_id, (row, col) in position.items():
        layout.cards[card_id] = (col_x[col], row_y[row], col_x[col] + diagram.card_w, row_y[row] + layout.card_h)

    for index, (edge, plan) in enumerate(zip(edges, plans)):
        ax, bx = port_x(index, 0), port_x(index, 1)
        a_box, b_box = layout.cards[edge.src], layout.cards[edge.dst]
        a_y = a_box[3] if plan["a_side"] == "bottom" else a_box[1]
        b_y = b_box[3] if plan["b_side"] == "bottom" else b_box[1]
        points = [(ax, a_y)]
        if index in gutter_of:
            ty_a = channel_top[plan["ch_a"]] + CHANNEL_TRACK * (channel_tracks[(index, "a")] + 1)
            ty_b = channel_top[plan["ch_b"]] + CHANNEL_TRACK * (channel_tracks[(index, "b")] + 1)
            points += [(ax, ty_a), (plan["vx"], ty_a), (plan["vx"], ty_b), (bx, ty_b)]
        else:
            ty_b = channel_top[plan["ch_b"]] + CHANNEL_TRACK * (channel_tracks[(index, "b")] + 1)
            points += [(ax, ty_b), (bx, ty_b)]
        points.append((bx, b_y))
        route = Route(edge, points)
        if index in label_centers:
            center, width = label_centers[index]
            route.label_center = (center, ty_b)
            route.label_box = (center - width / 2, ty_b - 7, center + width / 2, ty_b + 7)
        layout.routes.append(route)
    _slide_labels(layout.routes)
    return layout


def _slide_labels(routes: list) -> None:
    """Move each label along its own last segment to the spot crossed by the fewest other lines.

    The label stays inside the track interval reserved for it, so labels still cannot overlap.
    """
    verticals = [(a[0], min(a[1], b[1]), max(a[1], b[1]), id(route)) for route in routes for a, b in zip(route.points, route.points[1:]) if a[0] == b[0]]
    for route in routes:
        if not route.label_box:
            continue
        x0, y0, x1, y1 = route.label_box
        half = (x1 - x0) / 2
        original = x0 + half
        seg_a, seg_b = route.points[-3][0], route.points[-2][0]
        low, high = min(seg_a, seg_b), max(seg_a, seg_b)
        if high - low > 2 * half:  # Long enough to slide with the label fully on the segment.
            low, high = low + half, high - half
        else:
            low = high = original
        steps = int((high - low) // 6) + 1
        candidates = sorted((low + step * (high - low) / max(steps - 1, 1) for step in range(steps)), key=lambda x: (abs(x - original), x))

        def crossings(center):
            return sum(1 for vx, top, bottom, owner in verticals if owner != id(route) and center - half - 1 < vx < center + half + 1 and top < y1 and bottom > y0)

        best = min(candidates, key=crossings)
        route.label_center = (best, route.label_center[1])
        route.label_box = (best - half, y0, best + half, y1)


def _esc(value) -> str:
    return escape(str(value), quote=True)


def _fit(text: str, max_chars: int) -> str:
    text = str(text)
    return text if len(text) <= max_chars else text[:max_chars - 1] + "…"


def _text(x, y, value, cls, anchor="start") -> str:
    return f'<text x="{x:.1f}" y="{y:.1f}" class="{cls}" text-anchor="{anchor}">{_esc(value)}</text>'


def _path(points, radius: float = 4) -> str:
    parts = [f"M{points[0][0]:.1f} {points[0][1]:.1f}"]
    for i in range(1, len(points) - 1):
        (x0, y0), (x1, y1), (x2, y2) = points[i - 1], points[i], points[i + 1]
        r = min(radius, (abs(x1 - x0) + abs(y1 - y0)) / 2, (abs(x2 - x1) + abs(y2 - y1)) / 2)
        bx = x1 - r * ((x1 > x0) - (x1 < x0))
        by = y1 - r * ((y1 > y0) - (y1 < y0))
        ax = x1 + r * ((x2 > x1) - (x2 < x1))
        ay = y1 + r * ((y2 > y1) - (y2 < y1))
        parts.append(f"L{bx:.1f} {by:.1f}Q{x1:.1f} {y1:.1f} {ax:.1f} {ay:.1f}")
    parts.append(f"L{points[-1][0]:.1f} {points[-1][1]:.1f}")
    return "".join(parts)


STYLE = f"""
text{{font-family:'Segoe UI',Helvetica,Arial,sans-serif;fill:{INK}}}
.title{{font-size:21px;font-weight:600}}
.subtitle{{font-size:12.5px;fill:{MUTED}}}
.meta{{font-size:11.5px;fill:{MUTED}}}
.notice{{font-size:12px;font-weight:600;fill:{AMBER}}}
.zone{{font-size:12.5px;font-weight:600}}
.zone-note{{font-size:10.5px;fill:{MUTED}}}
.ct{{font-size:12px;font-weight:600}}
.ip{{font-size:11px;font-family:Consolas,'DejaVu Sans Mono',monospace}}
.role{{font-size:11px;fill:{MUTED}}}
.ev{{font-size:10px;fill:{MUTED}}}
.ok{{font-size:10px;font-weight:600;fill:{TEAL}}}
.dev{{font-size:10px;font-weight:600;fill:{AMBER}}}
.rev{{font-size:10px;font-weight:600;fill:{INK}}}
.silent .ct,.silent .ip{{fill:{MUTED}}}
.flow{{fill:none;stroke:{INK};stroke-width:1.1;marker-end:url(#arrow)}}
.flow.undoc{{stroke-dasharray:5 3}}
.edge:hover .flow{{stroke-width:2.4}}
.fl{{font-size:10px;font-family:Consolas,'DejaVu Sans Mono',monospace}}
.lg{{font-size:10.5px}}
.lgh{{font-size:11.5px;font-weight:600}}
.lgn{{font-size:10.5px;fill:{MUTED}}}
.s-solid{{stroke:{INK};stroke-width:1.8}}
.s-dashed{{stroke:{INK};stroke-width:1.4;stroke-dasharray:6 3}}
.s-dotted{{stroke:{INK};stroke-width:1.5;stroke-dasharray:1.5 3;stroke-linecap:round}}
.s-silent{{stroke:{SILENT};stroke-width:1;stroke-dasharray:2 4}}
.f-documented{{fill:#fff}}
.f-undocumented{{fill:url(#hatch)}}
.f-logical{{fill:#fff}}
"""

DEFS = (f'<defs><pattern id="hatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
        f'<rect width="7" height="7" fill="#fff"/><line x1="0" y1="0" x2="0" y2="7" stroke="#e5e7eb" stroke-width="2"/></pattern>'
        f'<marker id="arrow" viewBox="0 0 8 8" refX="7.5" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
        f'<path d="M0 0.8L8 4L0 7.2z" fill="{INK}"/></marker></defs>')


def _shape(x, y, w, h, fill: str, stroke: str) -> str:
    radius = min(h / 2, 16) if fill == "logical" else 3
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w}" height="{h}" rx="{radius:.1f}" class="f-{fill} s-{stroke}"/>'


def _render_card(card: Card, box: tuple, width: int, height: int) -> list:
    x, y = box[0], box[1]
    out = [f'<g class="card{" silent" if card.stroke == "silent" else ""}"><title>{_esc(card.tooltip or card.title)}</title>', _shape(x, y, width, height, card.fill, card.stroke)]
    if card.verified:
        out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="5" height="{height}" fill="{TEAL}"/>')
    pad = 14 if card.fill == "logical" else 11 if card.verified else 9
    chars = int((width - pad - 8) / 7.8)  # Worst case: wide capitals in semibold.
    out.append(_text(x + pad, y + 17, _fit(card.title, chars), "ct"))
    out.append(_text(x + pad, y + 32, card.mono, "ip"))
    if card.role:
        out.append(_text(x + width - 8, y + 32, _fit(card.role, 12), "role", "end"))
    out.append(_text(x + pad, y + 46, _fit(card.evidence, int((width - pad - 6) / 4.9)), "ev"))
    line_y = y + 59
    if card.verified:
        out.append(_text(x + pad, line_y, _fit(f"✓ {card.verified}", int((width - pad - 6) / 5.2)), "ok"))
        line_y += 13
    if card.review:
        out.append(_text(x + pad, line_y, _fit(card.review, int((width - pad - 6) / 5.2)), "rev"))
        line_y += 13
    if card.deviation:
        out.append(f'<path d="M{x + width - 13:.1f} {y:.1f}h13v13z" fill="{AMBER}"/>')
        out.append(_text(x + pad, line_y, _fit(f"! {card.deviation}", int((width - pad - 6) / 5.2)), "dev"))
    out.append("</g>")
    return out


def _render_legend(top: float, width: int) -> list:
    out = [_text(MARGIN, top + 12, "Tegnforklaring", "lgh")]
    items = [
        ("card", "documented", "solid", "Dokumenteret, set som kilde"),
        ("card", "documented", "dashed", "Set kun som destination"),
        ("card", "documented", "dotted", "Kun nævnt i log, retning ukendt"),
        ("card", "documented", "silent", "Ikke observeret (ikke = fraværende)"),
        ("card", "undocumented", "solid", "Skravering: ikke i dokumentationen"),
        ("card", "logical", "solid", "Logisk adresse, ikke et asset"),
        ("verified", "", "", "Manuelt verificeret (kun fra asset-map)"),
        ("deviation", "", "", "Afvigelse: kræver gennemgang"),
        ("text", "PLC?", "", "? = rolle/zone er hypotese fra navn"),
        ("line", "", "", "Observeret flow, pil = kilde til destination"),
        ("dashed-line", "", "", "Flow med udokumenteret endepunkt eller uden site"),
    ]
    columns = 4
    cell = (width - 2 * MARGIN) / columns
    for index, (kind, fill, stroke, text) in enumerate(items):
        x = MARGIN + (index % columns) * cell
        y = top + 22 + (index // columns) * 26
        if kind == "card":
            out.append(_shape(x, y, 34, 18, fill, stroke))
        elif kind == "verified":
            out.append(_shape(x, y, 34, 18, "documented", "solid"))
            out.append(f'<rect x="{x:.1f}" y="{y}" width="5" height="18" fill="{TEAL}"/>')
            out.append(_text(x + 20, y + 13, "✓", "ok", "middle"))
        elif kind == "deviation":
            out.append(_shape(x, y, 34, 18, "documented", "solid"))
            out.append(f'<path d="M{x + 22:.1f} {y}h12v12z" fill="{AMBER}"/>')
        elif kind == "text":
            out.append(_text(x + 17, y + 13, fill, "role", "middle"))
        else:
            cls = "flow undoc" if kind == "dashed-line" else "flow"
            out.append(f'<path d="M{x:.1f} {y + 9}H{x + 32:.1f}" class="{cls}"/>')
        out.append(_text(x + 40, y + 13, text, "lg"))
    rows = (len(items) + columns - 1) // columns
    note_y = top + 22 + rows * 26 + 8
    out.append(_text(MARGIN, note_y, "Bånd er en gruppering, ikke netværkssegmenter. Linjer er observeret trafik, ikke kabler. Ingen linje betyder kun, at intet er observeret. ×N er antal logposter, ikke pakker eller sessioner.", "lgn"))
    out.append(_text(MARGIN, note_y + 14, "Review: en persons vurdering, ikke fysisk verificering. ✓ Verificeret kommer kun fra asset-map med person og dato.", "lgn"))
    return out


LEGEND_HEIGHT = 22 + 3 * 26 + 8 + 30


def render_svg(diagram: Diagram) -> str:
    layout = compute_layout(diagram)
    height = layout.content_bottom + (LEGEND_HEIGHT + 16 if diagram.legend else 0) + MARGIN
    if not layout.cards:
        height = max(height, layout.header_h + 60)
    width = layout.width
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height:.0f}" viewBox="0 0 {width} {height:.0f}" role="img" aria-label="{_esc(diagram.title)}">',
           f"<title>{_esc(diagram.title)}</title>", f"<style>{STYLE}</style>", DEFS,
           f'<rect width="{width}" height="{height:.0f}" fill="#fff"/>',
           _text(MARGIN, MARGIN + 18, _fit(diagram.title, int((width - 2 * MARGIN) / 13)), "title"),
           _text(MARGIN, MARGIN + 38, _fit(diagram.subtitle, int((width - 2 * MARGIN) / 6.4)), "subtitle")]
    y = MARGIN + 54
    for line in diagram.meta:
        out.append(_text(MARGIN, y, _fit(line, int((width - 2 * MARGIN) / 6.1)), "meta"))
        y += 16
    for line in diagram.notices:
        out.append(f'<rect x="{MARGIN}" y="{y - 12}" width="{width - 2 * MARGIN}" height="20" fill="#fef3c7" stroke="{AMBER}" stroke-width="0.8"/>')
        out.append(_text(MARGIN + 8, y + 2, _fit(line, int((width - 2 * MARGIN - 16) / 6.6)), "notice"))
        y += 24

    if not layout.cards:
        out.append(_text(MARGIN, y + 30, "Ingen assets at vise.", "subtitle"))
        out.append("</svg>")
        return "\n".join(out)

    for index, band in enumerate(diagram.bands):
        if band.name not in layout.bands:
            continue
        x0, y0, x1, y1 = layout.bands[band.name]
        out.append(f'<rect x="{x0}" y="{y0:.1f}" width="{x1 - x0}" height="{y1 - y0:.1f}" fill="{BAND_A if index % 2 == 0 else BAND_B}" stroke="#d1d5db" stroke-width="0.7"/>')
        out.append(f'<rect x="{x0}" y="{y0:.1f}" width="{RAIL}" height="{y1 - y0:.1f}" fill="{RAIL_FILL}" stroke="#d1d5db" stroke-width="0.7"/>')
        out.append(_text(x0 + 10, y0 + 22, _fit(band.name, 19), "zone"))
        for line_index, line in enumerate(str(band.note).split("\n")):
            if line:
                out.append(_text(x0 + 10, y0 + 37 + 13 * line_index, _fit(line, 22), "zone-note"))

    for route in layout.routes:
        cls = "flow undoc" if route.edge.dashed else "flow"
        out.append(f'<g class="edge"><title>{_esc(route.edge.title or route.edge.label)}</title><path d="{_path(route.points)}" class="{cls}"/></g>')
    for band in diagram.bands:
        for card in band.cards:
            out.extend(_render_card(card, layout.cards[card.id], layout.card_w, layout.card_h))
    for route in layout.routes:
        if route.label_box:
            x0, y0, x1, y1 = route.label_box
            out.append(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{x1 - x0:.1f}" height="{y1 - y0:.1f}" fill="#fff" stroke="#d1d5db" stroke-width="0.5" rx="2"/>')
            out.append(_text(route.label_center[0], route.label_center[1] + 3.5, route.edge.label, "fl", "middle"))

    if diagram.legend:
        out.extend(_render_legend(layout.content_bottom + 16, width))
    out.append("</svg>")
    return "\n".join(out)
