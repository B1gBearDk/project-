"""Zone and role assignment. Manual mapping wins; name-based inference is only ever a marked hypothesis."""
from __future__ import annotations

from dataclasses import dataclass, field
import ipaddress
import re

from .ingest import InputError, clean_text, csv_records, extract_ips, normalize_name, normalize_site, parse_time

ZONE_ORDER = ("Eksternt", "Andet site", "Perimeter", "Netværk", "Supervision", "HMI", "Control", "Field", "Ukendt", "Site uafklaret", "Logiske adresser")
ZONE_ALIASES = {
    "eksternt": "Eksternt", "ekstern": "Eksternt", "external": "Eksternt", "perimeter": "Perimeter", "dmzperimeter": "Perimeter",
    "netvaerk": "Netværk", "netværk": "Netværk", "network": "Netværk", "supervision": "Supervision", "hmi": "HMI",
    "control": "Control", "kontrol": "Control", "styring": "Control", "field": "Field", "felt": "Field", "ukendt": "Ukendt", "unknown": "Ukendt",
}
ROLE_TOKENS = (
    ("Firewall", {"firewall", "fw"}), ("Router", {"router", "gw", "gateway"}), ("Switch", {"switch", "sw"}),
    ("SCADA", {"scada", "wincc", "ifix", "citect"}), ("Historian", {"historian", "hist"}),
    ("Engineering Workstation", {"engineering", "ews", "engws", "workstation"}), ("HMI", {"hmi"}), ("PLC", {"plc"}), ("RTU", {"rtu"}),
    ("Server", {"server", "srv"}),
    ("Field Device", {"sensor", "pump", "pumpe", "valve", "ventil", "meter", "maaler", "måler", "analyzer", "instrument", "foeler", "føler", "vfd"}),
)
ROLE_ZONE = {"Firewall": "Perimeter", "Router": "Perimeter", "Switch": "Netværk", "SCADA": "Supervision", "Historian": "Supervision",
             "Server": "Supervision", "Engineering Workstation": "Supervision", "HMI": "HMI", "PLC": "Control", "RTU": "Control", "Field Device": "Field"}


def infer_role(name: str) -> str:
    """Whole-token match on a documented name, so `Pumpestation` or `news-feed` give no false role."""
    tokens = set(re.findall(r"[a-zæøå]+", (name or "").lower()))
    for role, hints in ROLE_TOKENS:
        if tokens & hints:
            return role
    return "Unknown"


@dataclass
class MapEntry:
    zone: str = ""
    role: str = ""
    label: str = ""
    verified: str = ""  # "<who> <date>" only when both are given in the map.


def _pick(record: dict, *names):
    for key, value in record.items():
        if normalize_name(key) in names:
            return clean_text(value, 120)
    return ""


def load_asset_map(path, site: str = "", multi_site: bool = False, known_sites=()) -> tuple:
    """Return ({ip: MapEntry}, warnings). Only this file can make an asset manually verified.

    Facts about one waterworks must not reach another: with several sites, a row needs a Site column.
    """
    site_key = normalize_site(site)
    known = {normalize_site(name) for name in known_sites}
    if path.suffix.lower() not in (".csv", ".tsv"):
        raise InputError(f"Asset-map skal være CSV eller TSV: {path.name}")
    mapping, warnings = {}, []
    for line_no, record in csv_records(path):
        if not any(normalize_name(key) in ("ip", "ipaddress") for key in record):
            raise InputError(f"Asset-map '{path.name}' mangler kolonnen IP. Kolonner: {', '.join(clean_text(k, 40) for k in record)}")
        raw_ip = _pick(record, "ip", "ipaddress")
        found = extract_ips(raw_ip).valid
        if len(found) != 1 or found[0] != raw_ip:
            warnings.append(f"{path.name}, linje {line_no}: '{raw_ip}' er ikke én gyldig IPv4-adresse og er ignoreret.")
            continue
        ip = found[0]
        row_site = _pick(record, "site")
        if site_key and row_site and normalize_site(row_site) != site_key:
            continue
        if not site_key and row_site and normalize_site(row_site) not in known:
            warnings.append(f"{path.name}, linje {line_no}: {ip} er angivet for sitet '{row_site}', som ikke er det, der analyseres. Rækken er ikke brugt.")
            continue
        if site_key and multi_site and not row_site:
            warnings.append(f"{path.name}, linje {line_no}: {ip} har intet site, og referencen dækker flere sites. Rækken er ikke brugt.")
            continue
        if ip in mapping:
            warnings.append(f"{path.name}, linje {line_no}: {ip} står flere gange; sidste linje gælder.")
        zone = _pick(record, "zone")
        canonical = ZONE_ALIASES.get(normalize_name(zone), ZONE_ALIASES.get(zone.lower(), zone))
        if zone and canonical not in ZONE_ORDER:
            warnings.append(f"{path.name}, linje {line_no}: zonen '{zone}' er ikke en standardzone og vises som egen zone. Tjek stavning.")
        who = _pick(record, "verifiedby", "verificeretaf")
        when = _pick(record, "verifieddate", "verificeretdato", "verificeretden")
        verified = f"{who} {when}" if who and when and parse_time(when) else ""
        if (who or when) and not verified:
            warnings.append(f"{path.name}, linje {line_no}: {ip} regnes ikke som verificeret; både person og en gyldig dato kræves.")
        mapping[ip] = MapEntry(canonical, _pick(record, "role", "rolle"), _pick(record, "label", "navn"), verified)
    return mapping, warnings


@dataclass
class Node:
    ip: str
    label: str
    role: str
    role_source: str  # MANUEL | HYPOTESE | INGEN
    zone: str
    zone_source: str  # MANUEL | SCOPE | STATUS | HYPOTESE | INGEN
    status: str
    observation: str
    documented: bool
    doc_kind: str = ""
    verified: str = ""
    deviations: list = field(default_factory=list)
    address_type: str = ""
    next_step: str = ""
    in_scope: str = ""
    site: str = ""
    mac: str = ""
    doc_source: str = ""
    log_source: str = ""
    review: str = ""
    review_status: str = ""


def _assign_zone(entry, status: str, role: str, role_source: str) -> tuple:
    if status == "DOKUMENTERET_SITE_UAFKLARET":
        return "Site uafklaret", "STATUS"  # Not even a manual zone may place it on this site before the site is settled.
    if entry and entry.zone:
        return entry.zone, "MANUEL"
    if status == "LOGISK_ADRESSE":
        return "Logiske adresser", "STATUS"
    if status == "UDENFOR_SCOPE":
        return "Eksternt", "SCOPE"
    if status == "DOKUMENTERET_ANDET_SITE":
        return "Andet site", "STATUS"
    if role in ROLE_ZONE:
        return ROLE_ZONE[role], "MANUEL_ROLLE" if role_source == "MANUEL" else "HYPOTESE"
    return "Ukendt", "INGEN"


def build_nodes(asset_rows, flow_rows, asset_map) -> list:
    nodes = {}
    for row in asset_rows:
        ip = row.get("IP")
        if not ip:
            continue
        entry = asset_map.get(ip)
        status = row.get("Status", "")
        documented_name = clean_text(row.get("Dokumenteret_enhed") or "", 120)
        label = (entry.label if entry and entry.label else "") or documented_name or clean_text(row.get("Observeret_hostname") or "", 120) or ip
        if entry and entry.role:
            role, role_source = entry.role, "MANUEL"
        else:
            # Only documented names: a log's name column can be anything, and external addresses say nothing about this site.
            role = infer_role(documented_name) if status not in ("LOGISK_ADRESSE", "UDENFOR_SCOPE") else "Unknown"
            role_source = "HYPOTESE" if role != "Unknown" else "INGEN"
        zone, zone_source = _assign_zone(entry, status, role, role_source)
        verified = entry.verified if entry and entry.verified else ""
        if not verified and str(row.get("Verificering", "")).startswith("MANUELT_VERIFICERET"):
            verified = str(row["Verificering"]).replace("MANUELT_VERIFICERET", "").strip()
        nodes[ip] = Node(ip, label, role, role_source, zone, zone_source, status, row.get("Observation", ""), str(row.get("I_reference")) == "JA",
                         row.get("Dokumentationstype", ""), verified, [c for c in str(row.get("Afvigelser") or "").split(", ") if c],
                         row.get("Adressetype", ""), row.get("Foreslaaet_naeste_skridt", ""), row.get("I_scope", ""),
                         row.get("Dokumenteret_anlaeg", ""), row.get("Observeret_MAC") or row.get("Dokumenteret_MAC") or "",
                         row.get("Reference_kilde", ""), row.get("Log_kilde", ""), _review_text(row), row.get("Review_status", ""))
    sources = {flow.get("Kilde_IP") for flow in flow_rows}
    for flow in flow_rows:  # Only relevant when the flow table comes from another run than the asset table.
        for ip in (flow.get("Kilde_IP"), flow.get("Destination_IP")):
            if ip and ip not in nodes:
                nodes[ip] = Node(ip, ip, "Unknown", "INGEN", "Ukendt", "INGEN", "AFLEDT_FRA_FLOW", "KILDE" if ip in sources else "KUN_DESTINATION", False)
    return sorted(nodes.values(), key=lambda node: _ip_key(node.ip))


def _review_text(row: dict) -> str:
    words = {"GODKENDT": "godkendt", "AFVIST": "afvist", "UNDERSOEGES": "undersøges", "FORAELDET": "forældet, evidens ændret"}
    status = words.get(row.get("Review_status", ""))
    return f"Review: {status} {row.get('Review_af', '')}".strip() if status else ""


def _ip_key(ip: str) -> int:
    try:
        return int(ipaddress.IPv4Address(ip))
    except ValueError:
        return -1


def zones_in_order(nodes) -> list:
    """Standard zones in fixed order, with custom zones before `Ukendt`."""
    present = {node.zone for node in nodes}
    custom = sorted(present - set(ZONE_ORDER))
    insert_at = ZONE_ORDER.index("Ukendt")
    order = list(ZONE_ORDER[:insert_at]) + custom + list(ZONE_ORDER[insert_at:])
    return [zone for zone in order if zone in present]


@dataclass
class FlowEdge:
    src: str
    dst: str
    services: list  # [(protocol, port, count)], largest first
    count: int
    first: str = ""
    last: str = ""
    dashed: bool = False  # At least one endpoint is not documented for this site.
    files: set = field(default_factory=set)
    site_unresolved: int = 0


def _merge_timelines(current: str, new: str, pick) -> str:
    """Merge "utc | naive (uden tidszone)" texts per time kind; the kinds are not comparable."""
    merged = {}
    for part in (*current.split(" | "), *new.split(" | ")):
        if part:
            kind = part.endswith("(uden tidszone)")
            merged[kind] = pick(merged.get(kind, part), part)
    return " | ".join(merged[kind] for kind in sorted(merged))


def aggregate_edges(flow_rows, nodes, min_count: int = 1) -> tuple:
    """Group flows per directed IP pair. Returns (edges, number of hidden flows)."""
    known = {node.ip: node for node in nodes}
    pairs, hidden = {}, 0
    for row in flow_rows:
        src, dst = row.get("Kilde_IP"), row.get("Destination_IP")
        if src not in known or dst not in known:
            continue
        try:
            count = int(row.get("Antal_observationer") or 0)
        except ValueError:
            count = 0
        if count < min_count:
            hidden += 1
            continue
        edge = pairs.get((src, dst))
        if edge is None:
            edge = pairs[(src, dst)] = FlowEdge(src, dst, [], 0, dashed=not (known[src].documented and known[dst].documented))
        edge.services.append((clean_text(row.get("Protokol"), 30), clean_text(row.get("Destination_port"), 10), count))
        edge.count += count
        edge.files.update(part for part in str(row.get("Log_kilde") or "").split(", ") if part)
        edge.site_unresolved += int(row.get("Antal_uden_site") or 0)
        edge.dashed = edge.dashed or edge.site_unresolved > 0
        for attr, column, pick in (("first", "Foerste_observation", min), ("last", "Seneste_observation", max)):
            setattr(edge, attr, _merge_timelines(getattr(edge, attr), str(row.get(column) or ""), pick))
    edges = sorted(pairs.values(), key=lambda e: (_ip_key(e.src), _ip_key(e.dst)))
    for edge in edges:
        edge.services.sort(key=lambda s: (-s[2], s[0], s[1]))
    return edges, hidden
