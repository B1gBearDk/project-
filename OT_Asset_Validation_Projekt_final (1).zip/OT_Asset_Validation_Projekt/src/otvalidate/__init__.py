"""Offline reconciliation of documented OT assets against exported passive logs."""
__version__ = "2.1.0"
