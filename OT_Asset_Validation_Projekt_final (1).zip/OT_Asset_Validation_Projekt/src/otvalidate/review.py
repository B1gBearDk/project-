"""Human review as a separate overlay. Decisions live in the reviewer's own file and never alter evidence.

Each decision is tied to an evidence ID. When the evidence behind an asset changes, the decision no
longer applies and the asset returns to the queue, so old approvals cannot cover new facts.
Approval means "a person accepts this match". It is not physical verification, which only the asset map records.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib

from .ingest import InputError, clean_text, csv_records, extract_ips, normalize_name, normalize_site, parse_time
from .report_text import csv_unsafe

DECISIONS = {"godkendt": "GODKENDT", "godkend": "GODKENDT", "approve": "GODKENDT", "approved": "GODKENDT",
             "afvist": "AFVIST", "afvis": "AFVIST", "reject": "AFVIST", "rejected": "AFVIST",
             "undersoeg": "UNDERSOEG", "undersøg": "UNDERSOEG", "undersoeges": "UNDERSOEG", "investigate": "UNDERSOEG"}
STATUS_OF = {"GODKENDT": "GODKENDT", "AFVIST": "AFVIST", "UNDERSOEG": "UNDERSOEGES"}
TEMPLATE_HEADERS = ("Site", "IP", "Evidens_ID", "Status", "Afvigelser", "Prioritet", "Beslutning", "Beslutter", "Dato", "Begrundelse")
LOG_HEADERS = ("Linje", "Site", "IP", "Evidens_ID", "Beslutning", "Beslutter", "Dato", "Begrundelse", "Udfald")
REQUIRED_COLUMNS = ("IP", "Evidens_ID", "Beslutning", "Beslutter", "Dato", "Begrundelse")
REVIEW_COLUMNS = ("Review_status", "Review_af", "Review_dato", "Review_begrundelse")


@dataclass
class Decision:
    line: int
    site: str
    ip: str
    evidence_id: str
    decision: str
    by: str
    date: str
    reason: str
    sort_date: str = ""


def evidence_id(site: str, ip: str, status: str, doc_names, doc_kinds, doc_macs, observed_macs, observed_hosts, deviations) -> str:
    """Fingerprint of the facts a reviewer judged. Traffic counts are left out: more of the same is not new evidence."""
    parts = [normalize_site(site), ip, status, *("|".join(sorted(group)) for group in (doc_names, doc_kinds, doc_macs, observed_macs, observed_hosts, deviations))]
    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()[:16]


def _pick(record: dict, *names) -> str:
    for key, value in record.items():
        if normalize_name(key) in names:
            return clean_text(csv_unsafe(value or ""), 500)
    return ""


def load_decisions(path, site: str = "", multi_site: bool = False, known_sites=()) -> tuple:
    """Return (valid decisions, warnings). A decision that cannot be trusted is refused and reported."""
    if path.suffix.lower() not in (".csv", ".tsv"):
        raise InputError(f"Review-filen skal være CSV eller TSV: {path.name}")
    decisions, warnings = [], []
    site_key = normalize_site(site)
    known = {normalize_site(name) for name in known_sites}
    checked_header = False
    for line_no, record in csv_records(path):
        if not checked_header:
            names = {normalize_name(key) for key in record}
            missing = [column for column in REQUIRED_COLUMNS if normalize_name(column) not in names]
            if missing:
                raise InputError(f"Review-filen '{path.name}' mangler kolonnerne: {', '.join(missing)}.")
            checked_header = True
        where = f"{path.name}, linje {line_no}"
        raw = _pick(record, "beslutning", "decision")
        if not raw:
            continue  # An unfilled row from the template.
        ip = _pick(record, "ip")
        row_site = _pick(record, "site")
        if row_site and known and normalize_site(row_site) not in known:
            warnings.append(f"{where}: sitet '{row_site}' findes ikke i referencen. Beslutningen er ikke brugt. Tjek stavning.")
            continue
        if site_key and row_site and normalize_site(row_site) != site_key:
            continue
        decision = DECISIONS.get(raw.casefold())
        by, date, reason = _pick(record, "beslutter", "reviewer", "besluttetaf"), _pick(record, "dato", "date"), _pick(record, "begrundelse", "reason")
        stamp = parse_time(date) if date else None
        found = extract_ips(ip).valid
        if len(found) != 1 or found[0] != ip:
            warnings.append(f"{where}: '{ip}' er ikke én gyldig IPv4-adresse. Beslutningen er afvist.")
        elif decision is None:
            warnings.append(f"{where}: ukendt beslutning '{raw}'. Brug GODKENDT, AFVIST eller UNDERSOEG.")
        elif not by:
            warnings.append(f"{where}: {ip} mangler beslutter. Beslutningen er afvist.")
        elif not stamp:
            warnings.append(f"{where}: {ip} mangler en gyldig dato. Beslutningen er afvist.")
        elif not reason:
            warnings.append(f"{where}: {ip} mangler begrundelse. Beslutningen er afvist.")
        elif site_key and multi_site and not row_site:
            warnings.append(f"{where}: {ip} har intet site, og referencen dækker flere sites. Beslutningen er afvist.")
        else:
            decisions.append(Decision(line_no, row_site, ip, _pick(record, "evidensid"), decision, by, date, reason, stamp[0]))
    return decisions, warnings


def apply_decisions(asset_rows: list, decisions: list) -> tuple:
    """Add review columns to the rows. Returns (log rows, warnings). Evidence columns are not touched."""
    rows_by_ip = {row["IP"]: row for row in asset_rows}
    for row in asset_rows:
        row.update({"Review_status": "IKKE_BEHANDLET", "Review_af": "", "Review_dato": "", "Review_begrundelse": ""})
    latest = {}
    for decision in sorted(decisions, key=lambda d: (d.sort_date, d.line)):
        latest[decision.ip] = decision

    log, warnings = [], []
    for decision in decisions:
        row = rows_by_ip.get(decision.ip)
        if row is None:
            outcome = "UKENDT_IP"
            warnings.append(f"Review: {decision.ip} (linje {decision.line}) findes ikke i denne kørsel. Beslutningen er ikke brugt.")
        elif latest[decision.ip] is not decision:
            outcome = "ERSTATTET"
        elif decision.evidence_id != row["Evidens_ID"]:
            outcome = "FORAELDET"
            warnings.append(f"Review: evidensen for {decision.ip} er ændret siden beslutningen (linje {decision.line}). Den er genåbnet.")
            row.update({"Review_status": "FORAELDET", "Review_af": decision.by, "Review_dato": decision.date, "Review_begrundelse": decision.reason})
        else:
            outcome = "AKTUEL"
            row.update({"Review_status": STATUS_OF[decision.decision], "Review_af": decision.by, "Review_dato": decision.date, "Review_begrundelse": decision.reason})
        log.append({"Linje": decision.line, "Site": decision.site, "IP": decision.ip, "Evidens_ID": decision.evidence_id, "Beslutning": decision.decision,
                    "Beslutter": decision.by, "Dato": decision.date, "Begrundelse": decision.reason, "Udfald": outcome})
    return log, warnings


def template_rows(asset_rows: list, site: str) -> list:
    """Everything a person could judge, queue first. Logical addresses are not assets."""
    candidates = [row for row in asset_rows if row["Status"] != "LOGISK_ADRESSE"]
    candidates.sort(key=lambda row: (row["Prioritet"] == "", row["Prioritet"] if row["Prioritet"] != "" else 0))
    return [{"Site": site, "IP": row["IP"], "Evidens_ID": row["Evidens_ID"], "Status": row["Status"], "Afvigelser": row["Afvigelser"], "Prioritet": row["Prioritet"]} for row in candidates]
