"""Write CSV, text and HTML reports. Every value originates from untrusted files."""
from __future__ import annotations

import csv
from html import escape
from pathlib import Path

from .ingest import InputError, csv_records
from .reconcile import ASSET_HEADERS, FIELD_HEADERS, FLOW_HEADERS, Validation
from .report_text import csv_safe, csv_unsafe
from .review import LOG_HEADERS, TEMPLATE_HEADERS, template_rows

VALIDATION_FILES = ("01_alle_ip_adresser.csv", "02_til_gennemgang.csv", "03_kommunikationsflows.csv", "04_feltmapping.csv",
                    "05_opsummering.csv", "06_begraensninger_og_advarsler.txt", "07_pdf_udtraek.csv", "08_review_skabelon.csv", "09_review_log.csv")
HTML_FLOW_LIMIT = 1000
STATUS_MEANING = {
    "DOKUMENTERET_KILDE_OBSERVERET": "Dokumenteret og set sende trafik. Ikke fysisk verificeret.",
    "DOKUMENTERET_KUN_DESTINATION": "Dokumenteret, men kun set modtage trafik. Beviser ikke en aktiv enhed.",
    "DOKUMENTERET_KUN_NAEVNT": "Dokumenteret og nævnt i en log, men uden retning.",
    "DOKUMENTERET_IKKE_OBSERVERET": "Dokumenteret, men ikke set. Kan skyldes dækning, periode eller en stille enhed.",
    "DOKUMENTERET_ANDET_SITE": "Dokumenteret på et andet site end det valgte.",
    "DOKUMENTERET_SITE_UAFKLARET": "Dokumenteret, men ingen kilde siger hvilket site.",
    "IKKE_I_REFERENCE_IN_SCOPE": "Set i scope, men ikke dokumenteret. Kræver undersøgelse; ikke automatisk en trussel.",
    "IKKE_I_REFERENCE_SCOPE_UKENDT": "Ikke dokumenteret, og scope mangler, så det kan ikke afgøres.",
    "UDENFOR_SCOPE": "Uden for de angivne net. Ikke automatisk en afvigelse.",
    "LOGISK_ADRESSE": "Multicast, broadcast o.l. Ikke et asset.",
}
SECTIONS = (("datakvalitet", "Datakvalitet"), ("status", "Status"), ("dataflow", "Dataflow"), ("koe", "Til gennemgang"), ("adresser", "Alle adresser"),
            ("review", "Review"), ("flows", "Flows"), ("begraensninger", "Begrænsninger"), ("input", "Inputfiler"))


def export_csv(path: Path, headers, rows) -> None:
    """UTF-8 BOM and semicolons, which Danish Excel opens correctly."""
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(headers)
        for row in rows:
            writer.writerow([csv_safe(value) for value in row])


def read_table(path: Path, required) -> list:
    """Read a CSV written by this tool back into row dictionaries."""
    rows = [{key: csv_unsafe(value or "") for key, value in record.items()} for _, record in csv_records(path)]
    if rows:
        missing = [name for name in required if name not in rows[0]]
        if missing:
            raise InputError(f"{path.name}: mangler kolonnerne {', '.join(missing)}. Er det output fra validatoren?")
    return rows


def write_validation(result: Validation, out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    for name in VALIDATION_FILES:
        (out / name).unlink(missing_ok=True)

    def by_headers(rows, headers):
        return [[row.get(header, "") for header in headers] for row in rows]

    export_csv(out / "01_alle_ip_adresser.csv", ASSET_HEADERS, by_headers(result.asset_rows, ASSET_HEADERS))
    export_csv(out / "02_til_gennemgang.csv", ASSET_HEADERS, by_headers(result.review_rows, ASSET_HEADERS))
    export_csv(out / "03_kommunikationsflows.csv", FLOW_HEADERS, by_headers(result.flow_rows, FLOW_HEADERS))
    export_csv(out / "04_feltmapping.csv", FIELD_HEADERS, by_headers(result.field_rows, FIELD_HEADERS))
    export_csv(out / "05_opsummering.csv", ("Maal", "Vaerdi"), result.summary_rows)
    blocking = "".join(f"- BLOKERENDE: {line}\n" for line in result.blockers)
    (out / "06_begraensninger_og_advarsler.txt").write_text(blocking + "".join(f"- {line}\n" for line in result.warnings), encoding="utf-8")
    if result.pdf_pages:
        export_csv(out / "07_pdf_udtraek.csv", ("Fil", "Side", "Tegn", "IP_fundet", "Billedandel", "Tegneobjekter", "Vurdering", "Detaljer"),
                   [(p.file, p.page, p.chars, p.ips, p.image_share, p.drawings, p.verdict, p.details) for p in result.pdf_pages])
    export_csv(out / "08_review_skabelon.csv", TEMPLATE_HEADERS, by_headers(template_rows(result.asset_rows, result.site), TEMPLATE_HEADERS))
    if result.review_log:
        export_csv(out / "09_review_log.csv", LOG_HEADERS, by_headers(result.review_log, LOG_HEADERS))


def _ip_anchor(ip: str) -> str:
    return "ip-" + "".join(ch if ch.isalnum() else "-" for ch in str(ip))


def _ip_link(ip: str) -> str:
    return f'<a href="#{_ip_anchor(ip)}">{escape(str(ip))}</a>'


class _Raw(str):
    """A table cell that is already safe HTML, built here from escaped parts."""


def _cell(value) -> str:
    return value if isinstance(value, _Raw) else escape(str(value))


def _table(headers, rows) -> str:
    head = "".join(f"<th>{escape(str(h))}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{_cell(v)}</td>" for v in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


HTML_STYLE = """
body{font:14px/1.45 'Segoe UI',Helvetica,Arial,sans-serif;color:#111827;background:#fff;margin:24px auto;max-width:1500px;padding:0 16px}
h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:28px 0 8px;border-bottom:1px solid #d1d5db;padding-bottom:4px}
p{margin:6px 0;max-width:80ch}.muted{color:#6b7280}
.figure{overflow-x:auto;border:1px solid #d1d5db}
table{border-collapse:collapse;font-size:12.5px;width:100%}th,td{border:1px solid #d1d5db;padding:3px 7px;text-align:left;vertical-align:top}
th{background:#f3f4f6;font-weight:600}td.num{text-align:right}
nav{position:sticky;top:0;background:#fff;border-bottom:1px solid #d1d5db;padding:6px 0;font-size:13px;z-index:1}
nav a{margin-right:14px;color:#111827}
tr:target td{background:#fef3c7}
.block{font-weight:600;color:#92400e;background:#fef3c7;border:1px solid #92400e;padding:6px 10px;max-width:none}
ul{padding-left:18px;max-width:100ch}
@media print{body{margin:0;max-width:none}.figure{overflow:visible;border:0}svg{width:100%;height:auto}}
"""


def write_html_report(path: Path, site: str, result: Validation, nodes: list, svg: str, diagram_facts: dict) -> None:
    """One self-contained file with no scripts or external resources."""
    names = {node.ip: node.label for node in nodes}
    statuses = {}
    for row in result.asset_rows:
        statuses[row["Status"]] = statuses.get(row["Status"], 0) + 1

    def endpoint(ip):
        label = names.get(ip, ip)
        return f"{label} ({ip})" if label != ip else ip

    by_ip = {node.ip: node for node in nodes}
    review = [(row["Prioritet"], _Raw(_ip_link(row["IP"])), names.get(row["IP"], ""), row["Status"], row["Afvigelser"], row["Foreslaaet_naeste_skridt"]) for row in result.review_rows]
    inventory_rows = "".join(
        f'<tr id="{_ip_anchor(row["IP"])}">' + "".join(f"<td>{escape(str(value))}</td>" for value in (
            row["IP"], names.get(row["IP"], ""), by_ip[row["IP"]].zone, by_ip[row["IP"]].zone_source, by_ip[row["IP"]].role, row["Status"], row["Antal_som_kilde"], row["Antal_som_destination"],
            row["Seneste_observation"], row["Observeret_MAC"], row["Afvigelser"], row["Verificering"], row["Review_status"])) + "</tr>"
        for row in result.asset_rows if row["IP"] in by_ip)
    inventory_head = "".join(f"<th>{name}</th>" for name in ("IP", "Navn", "Zone", "Zonegrundlag", "Rolle", "Status", "Som kilde", "Som destination", "Seneste", "Observeret MAC", "Afvigelser", "Verificering", "Review"))
    inventory = f"<table><thead><tr>{inventory_head}</tr></thead><tbody>{inventory_rows}</tbody></table>"
    navigation = "<nav>" + "".join(f'<a href="#{anchor}">{title}</a>' for anchor, title in SECTIONS) + "</nav>"
    flows = [(endpoint(f["Kilde_IP"]), endpoint(f["Destination_IP"]), f["Protokol"], f["Destination_port"], f["Antal_observationer"], f["Foerste_observation"], f["Seneste_observation"], f["Log_kilde"])
             for f in result.flow_rows[:HTML_FLOW_LIMIT]]
    truncated = f"<p class='muted'>Viser de {HTML_FLOW_LIMIT} største af {len(result.flow_rows)} flows. Alle står i 03_kommunikationsflows.csv.</p>" if len(result.flow_rows) > HTML_FLOW_LIMIT else ""
    verified = sum(bool(node.verified) for node in nodes)
    logs = {info.name: info for info in result.files}
    inputs = [(role, name, ("sprunget over (identisk)" if logs[name].skipped else logs[name].rows) if role == "Log" and name in logs else "", digest) for role, name, digest in result.inputs]
    quality = (f"<p class='block'>UFULDSTÆNDIGT GRUNDLAG: {len(result.blockers)} blokerende forhold. Resultatet må ikke bruges som fuldstændigt, før de er afklaret.</p><ul>"
               + "".join(f"<li>{escape(line)}</li>" for line in result.blockers) + "</ul>") if result.blockers else "<p>Ingen blokerende forhold fundet. Det betyder ikke, at data er fuldstændige: se begrænsningerne nedenfor.</p>"
    reviewed = _table(("Linje", "IP", "Beslutning", "Beslutter", "Dato", "Begrundelse", "Udfald"), [(r["Linje"], r["IP"], r["Beslutning"], r["Beslutter"], r["Dato"], r["Begrundelse"], r["Udfald"]) for r in result.review_log]) if result.review_log else "<p>Ingen beslutninger indlæst. Brug 08_review_skabelon.csv og --review-file.</p>"
    pdf = _table(("Fil", "Side", "Tegn", "IP'er", "Vurdering", "Detaljer"), [(p.file, p.page, p.chars, p.ips, p.verdict, p.details) for p in result.pdf_pages]) if result.pdf_pages else ""

    html = f"""<!doctype html>
<html lang="da"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape(site)}: OT-validering</title><style>{HTML_STYLE}</style></head><body>
<h1>{escape(site)}: OT-validering og dataflow</h1>
<p class="muted">Arbejdsmateriale fra passive logs. Fortrolighed som kildedata: filen indeholder interne adresser.</p>
<p>Observationsperiode: {escape(result.window_text)}. Scope: {escape(result.scope_text)}. Manuelt verificeret: {verified} af {len(nodes)} adresser.</p>
{navigation}
<h2 id="datakvalitet">Datakvalitet</h2>
{quality}
<h2 id="status">Status</h2>
{_table(("Status", "Antal", "Betydning"), [(name, count, STATUS_MEANING.get(name, "")) for name, count in sorted(statuses.items())])}
<h2 id="dataflow">Dataflow</h2>
<p>Diagrammet viser observeret kommunikation, ikke fysisk topologi. Hold musen over kort og linjer for detaljer.</p>
<div class="figure">{svg}</div>
<h2 id="koe">Til gennemgang ({len(review)})</h2>
<p>Klik på en IP for at se adressen i tabellen over alle adresser. Prioritet 1 er afvigelse fra dokumentationen, 2 er uafklaret observation, 3 er manglende grundlag. Prioriteten siger, hvad der bør afklares først, ikke om noget er farligt.</p>
{_table(("Prioritet", "IP", "Navn", "Status", "Afvigelser", "Næste skridt"), review)}
<h2 id="adresser">Alle adresser ({len(result.asset_rows)})</h2>
<p>Zonegrundlag viser, hvad placeringen bygger på: MANUEL er fra asset-map, HYPOTESE er et gæt ud fra navnet.</p>
{inventory}
<h2 id="review">Reviewbeslutninger ({len(result.review_log)})</h2>
<p>Beslutninger ændrer ikke evidensen. Godkendt betyder, at en person accepterer matchet. Det er ikke fysisk verificering.</p>
{reviewed}
<h2 id="flows">Observerede flows ({len(result.flow_rows)})</h2>
<p>Brug Ctrl+F og søg på en IP for at se, hvad den har kommunikeret med.</p>
{truncated}{_table(("Kilde", "Destination", "Protokol", "Port", "Antal", "Første", "Seneste", "Logkilde"), flows)}
<h2 id="begraensninger">Begrænsninger og advarsler</h2>
<ul>{"".join(f"<li>{escape(line)}</li>" for line in result.warnings)}</ul>
{"<h2>PDF-sider</h2>" + pdf if pdf else ""}
<h2 id="input">Inputfiler</h2>
{_table(("Rolle", "Fil", "Rækker", "SHA-256"), inputs)}
<p class="muted">PNG: {escape(diagram_facts.get("png_message", ""))}</p>
</body></html>
"""
    path.write_text(html, encoding="utf-8")
