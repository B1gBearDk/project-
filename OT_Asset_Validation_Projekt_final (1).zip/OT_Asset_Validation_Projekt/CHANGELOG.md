# Ændringer

## 2.1.0

### Ændret adfærd
- Ny exit-kode 3: rapporter er skrevet, men grundlaget er ufuldstændigt.
- Dokumentation uden site regnes ikke længere til det valgte site, men får status `DOKUMENTERET_SITE_UAFKLARET` i eget bånd.
- Logrækker uden site giver exit 3 under `--site`, medmindre `--log-site-confirmed` er angivet. Flere sites uden `--site` giver også exit 3.
- Asset-map og reviewfil skal have `Site`-kolonne, når referencen dækker flere sites.
- Ugyldige IP-værdier i dokumentation giver exit 3 i stedet for en advarsel.
- PDF: `import pymupdf` kræver PyMuPDF 1.24.3 eller nyere. `192.0.2.6O` læses ikke længere som `192.0.2.6`.
- Site-navne sammenlignes uden hensyn til store og små bogstaver, ekstra mellemrum og Unicode-form.

### Tilføjet
- Review-workflow: `--review-file`, `Evidens_ID`, `08_review_skabelon.csv`, `09_review_log.csv` og `Review_*`-kolonner.
- PDF-vurdering pr. side i `07_pdf_udtraek.csv`, herunder scanninger, OCR-lag, vektortekst og reparerede filer.
- `--reference-site`, `--log-site-confirmed`, afvigelserne `IP_PAA_FLERE_SITES` og `KUN_OBS_UDEN_SITE`, kolonnerne `Log_kilde` og `Antal_uden_site` på flows.
- Provenance i diagrammer: inputfiler med SHA-256 og kilder i hover-tekst. Synlig note i Mermaid.
- Rigtige test-PDF'er, runtime-test af offline-grænsen og to demoscenarier mere.

### Rettet
- Fund fra PDF-test og mutationstest. Sikkerhedsreviewen blev ikke afsluttet; se `docs/PRODUCTION_READINESS.md`.

## 2.0.0

Baggrunden for ændringerne står i `docs/AUDIT.md`.

### Ændret adfærd
- Kørslen stopper med exit 2, hvis et angivet felt ikke findes, eller hvis en struktureret logfil ikke har IP-felter. Før gav det exit 0 og tomme resultater.
- Multicast, broadcast, subnet-broadcast, `0.0.0.0` og loopback får status `LOGISK_ADRESSE` og kommer ikke i gennemgangskøen. Flows til dem bevares.
- `02_til_gennemgang.csv` indeholder nu også assets med afvigelser, og er sorteret efter `Prioritet`.
- Zoner: en dokumenteret adresse havner aldrig i `Eksternt` af sig selv. Uden `--scope` står udokumenterede adresser under `Ukendt`.
- `02_site_dataflow.svg` kommer fra den nye renderer og kræver ikke Graphviz. PNG laves stadig af Graphviz, når det findes, og har sit eget layout.
- Kolonnenavne i `01_diagram_asset_catalog.csv` er ændret og udvidet med grundlaget for rolle og zone.
- Med `--site` springes logrækker over, hvis loggens site-kolonne angiver et andet site. Antallet nævnes i advarslerne.
- Tidsstempler uden for årene 1990-2100 tæller som ulæselige. Tekstlogs afkortes til 8192 tegn pr. linje med en advarsel.

### Tilføjet
- Kolonner: `Observation`, `Dokumentationstype`, `Verificering`, `Afvigelser`, `Prioritet`, `Adressetype`; på flows `Foerste_observation` og `Seneste_observation`.
- Manuel verificering via `Verified_by` og `Verified_date` i asset-map.
- MAC-sammenligning med normaliseret format. MAC'er delt af mindst 3 IP'er udelades og giver en advarsel.
- `--site`, `--all-sites`, `--stale-days`, `--min-count`, `--detail-threshold`.
- `rapport.html`, `07_zone_overview.svg`, `zoner/*.svg`.
- Observationsperiode, datohuller, overlappende filer, SHA-256 af logfiler. Identiske logfiler springes over.
- Tekstlogs: retning fra `src=… dst=…` og `a -> b`. Encoding: UTF-16 og cp1252.
- Testsuite med `unittest`, demo-datasæt og datagenerator.

### Fjernet
- pandas. Eneste valgfrie afhængighed er PyMuPDF til PDF.
- Farver pr. zone og rød linje for "ekstern".
- Underprocesser mellem trinene. CLI'erne har samme argumenter som før.

### Rettet
Alle punkter i `docs/AUDIT.md`.

### Ydelse
1 mio. rækker (76 MB CSV): den gamle validator tog 22,6 s. Den nye hele pipeline med diagrammer tager cirka 12 s. Højeste hukommelsesforbrug er cirka 25 MB (før 17 MB) og afhænger ikke af antal rækker.
