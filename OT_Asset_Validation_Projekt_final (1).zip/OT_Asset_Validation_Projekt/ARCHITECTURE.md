# Arkitektur

```text
reference + logs + asset-map
        │
   ingest.py       læser filer sikkert, normaliserer felter, tæller alt der ikke kunne læses
        │
   reconcile.py    evidens pr. IP: status, afvigelser, prioritet; flows; advarsler; blokerende forhold
   review.py       menneskelige beslutninger som et lag oven på evidensen; rører den aldrig
        │
   report.py       CSV, tekst og HTML
   zones.py        rolle og zone med kilde (MANUEL / SCOPE / STATUS / HYPOTESE / INGEN)
        │
   diagrams.py     kort og flows → site-diagram, zoneoverblik, zonedetaljer, DOT, Mermaid
        │
   render_svg.py   layout og SVG; kender intet til OT
```

`cli.py` binder trinene sammen for de tre kommandoer. Hele pipelinen kører i én proces, så data ikke skal gennem CSV undervejs. Diagramkommandoen alene læser validatorens CSV og fjerner den apostrof, der beskytter mod formler.

## Designvalg

**Kun standardbiblioteket.** pandas blev kun brugt til at læse to CSV-filer. PyMuPDF er valgfri og importeres først, når en PDF skal læses.

**Egen SVG-renderer som primært output.** Graphviz placerer noder efter kanternes retning. Så bestemmer trafikken, hvad der står øverst, og tegningen ligner en topologi. Her bestemmer zonelisten rækkefølgen, og trafik påvirker kun den vandrette placering. Rendereren fylder under 550 linjer og er testet geometrisk (ingen linje gennem et kort, ingen overlappende etiketter). DOT og Mermaid bevares som redigerbare kilder, med usynlige kanter der fastholder zonerækkefølgen i Graphviz.

**Routing.** Rækkerne ligger i et gitter. Mellem rækker er der kanaler, og mellem kolonner er der gutters. En linje går fra kortets port til en kanal, via en gutter hvis rækkerne ikke er naboer, og til destinationens port. Spor tildeles med first-fit på intervaller, og etiketten indgår i intervallet, så etiketter ikke kan overlappe hinanden. Bagefter glider hver etiket langs sin linje hen, hvor færrest andre linjer krydser, men i tætte diagrammer kan en etiket stadig dække en linje. Kanalernes højde og gutternes bredde følger antallet af spor. Øverste og nederste port bruger hver sin halvdel af kortet, så to linjer i samme kolonne aldrig falder sammen.

**Heller fejl end falske negativer.** En stavefejl i et feltnavn eller en logfil uden IP-felter stopper kørslen med exit 2. Ellers ville resultatet være "ikke observeret" for alle assets, hvilket ligner en konklusion. En enkelt ulæselig post tælles og nævnes, men stopper ikke kørslen.

**Blokerende forhold.** Forhold, der gør grundlaget ufuldstændigt (ulæste PDF-sider, uafklaret site), holdes adskilt fra almindelige advarsler. Rapporter skrives stadig, så de kan læses, men de får et banner, og kørslen slutter med exit 3.

**Evidens er adskilte akser.** `Status` er bevaret for bagudkompatibilitet. `Observation`, `Dokumentationstype`, `Verificering` og `Afvigelser` står i egne kolonner. Verificering kan kun komme fra asset-map og kræver person og dato.

**Determinisme.** Ingen tidsstempler for kørslen og ingen absolutte stier i output. Alt er sorteret. Tilfældighed findes kun i testdatageneratoren, med fast seed.

## Sikkerhed

- Input er data: tekst renses for kontrol- og bidi-tegn, længder begrænses, og alt escapes pr. outputformat (`csv_safe`, `html.escape`, `_dot_escape`, `_mermaid_escape`). SVG og HTML indeholder ingen scripts.
- Filer skrives kun under `--out`. Site-navne bliver mappenavne via `safe_name`. Oprydning sletter kun værktøjets egne filnavne.
- Eneste underproces er den lokale Graphviz: fuld sti, ingen shell, timeout, og den afvises hvis `dot` ligger i arbejdsmappen.
- `tests/test_pipeline.py` kontrollerer, at koden ikke importerer netværksmoduler. `tests/test_boundaries.py` kører den rigtige kommando under en audit-hook, som registrerer sockets, processer og skrivninger uden for `--out`, med en kontroltest der viser, at hooken faktisk opdager dem. Hooken ser kun Python-kald, ikke PyMuPDF's native kode.

## Ydelse

`LogAggregator` læser rækker løbende. Hukommelsen følger antallet af unikke IP'er og flows. Gentagne celleværdier (IP, tid, MAC, port) slås op i `lru_cache`, og feltmapping genbruges pr. skema. Rå CSV-parsing og dict-opbygning er nu den største post.

## Test

```powershell
python -m unittest discover -s tests
```

Testene bruger kun `unittest` og fiktive data og dækker parsing, afstemning, zoner, layoutgeometri, escaping, review og hele kæden gennem de rigtige kommandoer. PDF-testene læser rigtige PDF-filer med rigtig PyMuPDF og springes over uden. Sæt `OTV_REQUIRE_PDF=1` for at gøre et overspring til en fejl.
