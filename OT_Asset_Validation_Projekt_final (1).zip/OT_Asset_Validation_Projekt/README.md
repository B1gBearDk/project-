# OT Asset Validation & Dataflow

Sammenholder dokumenterede IP-adresser med passive logeksporter (NAMS o.l.) for ét vandværk ad gangen. Resultatet er en valideringskø, en rapport og et hierarkisk dataflow-diagram.

Værktøjet læser kun lokale filer. Det har ingen netværkskald, ingen scanning, ingen cloud og ingen kontakt til anlæg. Det er beslutningsstøtte, ikke et certificeret OT-værktøj.

**Det vigtigste forbehold:** Et IP-match eller et observeret flow beviser ikke en fysisk enhed, et kabel eller en netværkszone. Værktøjet holder tre slags evidens adskilt:

| Evidens | Kommer fra | Betyder |
|---|---|---|
| Dokumenteret | `--reference` | Adressen står i dokumentationen. PDF/TXT er kun *kandidater*. |
| Observeret | `--logs` | Sensoren så adressen i et tidsrum. |
| Manuelt verificeret | `--asset-map` med person og dato | Et menneske har bekræftet det. Værktøjet sætter det aldrig selv. |

En fjerde ting holdes også adskilt: **reviewbeslutninger** i din egen fil. De er en persons vurdering af et match, ændrer ikke evidensen og er ikke fysisk verificering.

## Kom i gang

Kræver Python 3.10 eller nyere. Der skal ikke installeres noget for CSV, JSON og tekstlogs.

Kør demoen med fiktive data:

```powershell
python .\tools\run_demo.py
```

Demoen kører tre scenarier og fejler, hvis et af dem giver en forkert exit-kode: `demo` (ét site, exit 0), `huller` (scannet PDF uden site, exit 3) og `flere_sites` (to vandværker med fælles log, exit 3). De to PDF-baserede dele kræver PyMuPDF og springes synligt over uden.

Åbn derefter `output\demo\demo\rapport.html` i en browser. Den rummer datakvalitet, status, diagram, gennemgangskø, reviewbeslutninger, flows og begrænsninger i én fil uden scripts og eksterne ressourcer.

Kør på egne eksporter:

```powershell
python .\run_pipeline.py `
  --reference .\input\inventory.csv `
  --logs .\input\nams.csv .\input\nams_syslog.log `
  --scope 192.0.2.0/24 `
  --site "Testvandvaerk" `
  --log-site-confirmed `
  --asset-map .\input\asset_map.csv `
  --review-file .\review\beslutninger.csv `
  --out .\output\testvandvaerk
```

### Exit-koder

| Kode | Betydning |
|---|---|
| 0 | Rapporter skrevet, og ingen blokerende forhold fundet. Det betyder ikke, at data er fuldstændige. |
| 3 | Rapporter skrevet, men grundlaget er **ufuldstændigt**. Forholdene står øverst i rapporten og i `06_begraensninger_og_advarsler.txt`, og diagrammet har et banner. |
| 2 | Input kan ikke bruges. Fejlen forklarer hvorfor. Filer fra denne kørsel er ikke færdige. |

Valgfrit, og kun via en godkendt kanal:

- **PDF som reference:** `python -m pip install -r requirements.txt` (PyMuPDF). Alternativt kan listen eksporteres som CSV.
- **PNG:** Graphviz-programmet `dot` på PATH. SVG laves altid uden Graphviz.

## Arbejdsgang for en medarbejder

1. **Tjek at data er læst rigtigt.** Var exit-koden 3? Løs blokerende forhold først. Læs `validation\04_feltmapping.csv`, `06_begraensninger_og_advarsler.txt` og ved PDF `07_pdf_udtraek.csv`. Passer observationsperioden med det, du eksporterede?
2. **Gennemgå køen.** Åbn `validation\02_til_gennemgang.csv`, som er sorteret efter prioritet.
3. **Se diagrammet.** Åbn `diagram\02_site_dataflow.svg` og hold musen over kort og linjer for kilder og detaljer.
4. **Afklar med drift.** Skriv din vurdering i din egen reviewfil (se nedenfor). Det, der fysisk er tjekket, noteres i asset-map med `Verified_by` og `Verified_date`.
5. **Kør igen.** Godkendte og afviste forsvinder fra køen, men bliver i `01_alle_ip_adresser.csv`. Hypoteser (`?`) forsvinder, når zone og rolle står i asset-map.

## Review: godkend, afvis eller undersøg

En reviewbeslutning står i din egen CSV-fil, som værktøjet kun læser. Inputfiler, evidenskolonner og flows ændres aldrig.

1. Tag rækkerne fra `validation\08_review_skabelon.csv` og gem dem **uden for outputmappen**. Værktøjet nægter at bruge en fil i outputmappen, fordi filer der bliver overskrevet.
2. Udfyld `Beslutning` (`GODKENDT`, `AFVIST` eller `UNDERSOEG`), `Beslutter`, `Dato` og `Begrundelse`. Alle fire kræves, ellers afvises rækken og nævnes i advarslerne.
3. Tilføj nye linjer i stedet for at rette gamle. Seneste dato gælder, og hele historikken står i `validation\09_review_log.csv`.
4. Kør igen med `--review-file`.

```text
Site;IP;Evidens_ID;Beslutning;Beslutter;Dato;Begrundelse
Testvandvaerk;192.0.2.33;a1b2c3d4e5f60718;UNDERSOEG;JL;2026-11-05;MAC afviger; driften spørges
```

`Evidens_ID` er et fingeraftryk af det, du tog stilling til: status, dokumenterede navne, MAC-adresser, observerede navne og afvigelser. Ændrer evidensen sig, passer beslutningen ikke længere. Den får status `FORAELDET` og går forrest i køen, så en gammel godkendelse ikke dækker nye fakta. Flere observationer af det samme genåbner ikke en beslutning.

En godkendelse siger, at en person accepterer matchet. Den gør aldrig et asset `MANUELT_VERIFICERET`.

## Sådan læses diagrammet

- **Bånd** er grupperinger i fast rækkefølge (Eksternt, Andet site, Perimeter, Netværk, Supervision, HMI, Control, Field, egne zoner, Ukendt, Logiske adresser). Kun zoner med indhold vises. Rækkefølgen afhænger aldrig af trafikretning. Et bånd er ikke et netværkssegment.
- **Linjer** er observeret trafik fra kilde til destination med protokol/port og antal. De er ikke kabler. `×N` er antal logposter, ikke pakker eller sessioner. Stiplet linje betyder, at et endepunkt ikke er dokumenteret, eller at trafikken stammer fra logrækker uden site. Det er en dokumentationsstatus, ikke en sikkerhedsvurdering.
- **Kilder:** Øverst står inputfiler med SHA-256. Når du holder musen over et kort eller en linje, vises hvilken dokumentation og hvilke logfiler det bygger på.
- **Kant** viser observation: fuld (kilde), stiplet (kun destination), prikket (kun nævnt), lys prikket (ikke observeret).
- **Skravering** betyder ikke dokumenteret.
- **`PLC?`** betyder, at rollen er gættet ud fra navnet. Båndets note viser, hvor mange placeringer der er manuelle, og hvor mange der er hypoteser.
- **Grøn kant med ✓** betyder manuelt verificeret og kommer kun fra asset-map. **Amber hjørne** betyder afvigelse.

Formerne kan skelnes i gråtoner, og hver tilstand står også som tekst på kortet.

## Output

```text
<out>/
├── rapport.html                         samlet rapport
├── validation/
│   ├── 01_alle_ip_adresser.csv          alle adresser med evidens og afvigelser
│   ├── 02_til_gennemgang.csv            manuel kø, sorteret efter prioritet
│   ├── 03_kommunikationsflows.csv       kilde → destination, protokol, port, antal, første/seneste
│   ├── 04_feltmapping.csv               hvilke logfelter der blev brugt
│   ├── 05_opsummering.csv               datakvalitet, tal, periode og SHA-256 af alle inputfiler
│   ├── 06_begraensninger_og_advarsler.txt  blokerende forhold først
│   ├── 07_pdf_udtraek.csv               vurdering af hver PDF-side (kun med PDF)
│   ├── 08_review_skabelon.csv           rækker til din reviewfil
│   └── 09_review_log.csv                alle beslutninger og deres udfald (kun med --review-file)
└── diagram/
    ├── 02_site_dataflow.svg             primært diagram
    ├── 07_zone_overview.svg             overblik pr. zone
    ├── zoner/*.svg                      zonevise detaljer ved mere end 25 adresser
    ├── 02_site_dataflow.dot, 05_site_dataflow.mmd   redigerbare kilder
    ├── 03_site_dataflow.png             kun med Graphviz (eget layout, ud fra DOT)
    └── 01_diagram_asset_catalog.csv, 04_diagram_summary.txt, 06_diagram_notes.txt
```

CSV-filer er UTF-8 med BOM og semikolon, så de åbner i dansk Excel. Tekst, der kunne tolkes som en formel, får en foranstillet apostrof. Samme input giver byte-identisk output, og en ny kørsel fjerner værktøjets egne gamle filer, så et gammelt diagram ikke kan forveksles med et nyt. Andre filer i mappen røres ikke.

### Status og afvigelser

| Status | Betydning |
|---|---|
| `DOKUMENTERET_KILDE_OBSERVERET` | Dokumenteret og set sende trafik. Ikke fysisk verificeret. |
| `DOKUMENTERET_KUN_DESTINATION` | Kun set modtage. Beviser ikke en aktiv enhed. |
| `DOKUMENTERET_KUN_NAEVNT` | Nævnt i en log uden retning. |
| `DOKUMENTERET_IKKE_OBSERVERET` | Ikke set. Kan skyldes dækning, periode eller en stille enhed. |
| `DOKUMENTERET_ANDET_SITE` | Dokumenteret på et andet site end det valgte. |
| `DOKUMENTERET_SITE_UAFKLARET` | Dokumenteret, men ingen kilde siger hvilket site. Regnes ikke til det valgte site. |
| `IKKE_I_REFERENCE_IN_SCOPE` | Set i scope, men ikke dokumenteret. Kræver undersøgelse; ikke automatisk en trussel. |
| `IKKE_I_REFERENCE_SCOPE_UKENDT` | Uafklaret, fordi `--scope` mangler. |
| `UDENFOR_SCOPE` | Uden for de angivne net. |
| `LOGISK_ADRESSE` | Multicast, broadcast, subnet-broadcast o.l. Viser, hvor pakker er sendt hen. Ikke et asset. |

Kolonnen `Afvigelser` kan indeholde: `MAC_AFVIGER`, `FLERE_MAC`, `NAVN_KONFLIKT`, `NAVN_PAA_FLERE_IP`, `DOK_UDEN_FOR_SCOPE`, `IP_PAA_FLERE_SITES`, `KUN_OBS_UDEN_SITE`, `SIDST_SET_FOER_LOGSLUT` og `MULIG_BROADCAST`.

`Prioritet` siger, hvad der bør afklares først: 1 er afvigelse fra dokumentationen, 2 er uafklaret observation, og 3 er manglende grundlag. I køen vises en genåbnet reviewbeslutning også som 1. Prioritet siger intet om, hvorvidt noget er farligt.

## Inputformater

**Reference:** CSV/TSV med en IP-kolonne (fx `ip`, `device_ip`) og gerne `device_name`, `site`, `mac`. Også PDF og TXT, hvor alle fundne adresser behandles som kandidater. IP-værdier, der ikke kan læses, bruges ikke og giver exit 3.

**PDF:** Hver side får en vurdering i `07_pdf_udtraek.csv`. Teksten gættes aldrig til rette: `192 . 0 . 2 . 40`, `192,0,2,41`, en adresse delt over to linjer og `192.0.2.6O` bliver ikke til adresser, men rapporteres.

| Vurdering | Betydning | Exit 3 |
|---|---|---|
| `OK` | Tekst uden tegn på problemer | nej |
| `TOM` | Hverken tekst, billede eller tegning | nej |
| `LILLE_BILLEDE` | Tekst plus billede under 25 % af siden, fx et logo. Billedet er ikke læst. | nej, kun advarsel |
| `INGEN_TEKST` | Scannet eller tegnet som grafik. Adresser er ikke læst. | ja |
| `BILLEDE_MED_TEKST` | Stort billede ud over teksten | ja |
| `SKJULT_TEKST` | OCR-lag eller usynlig tekst: det læste er ikke nødvendigvis det, der ses | ja |
| `UDEN_SIKKER_AFLAESNING` | Tekst, der ligner adresser, men ikke kan accepteres | ja |

En beskadiget PDF, som PyMuPDF har repareret ved indlæsning, giver også exit 3. Ulæselige, krypterede og tomme PDF'er stopper kørslen med exit 2.

**Logs:** CSV, TSV, JSON, JSONL samt tekstlogs. I tekstlogs tages retning kun fra eksplicit notation (`src=… dst=…` eller `a -> b`). Ellers bliver IP'erne markeret som "nævnt", og retningen gættes ikke. Kolonnenavne genkendes automatisk. Fejler det, bruges `--source-field`, `--dest-field` og `--time-field`. Encoding findes automatisk (UTF-8, UTF-16 med BOM, cp1252).

**Asset-map** (`--asset-map`), det eneste sted manuelle facts kommer fra:

```text
IP;Zone;Role;Label;Verified_by;Verified_date
192.0.2.10;Supervision;SCADA;SCADA-01;JL;2026-10-12
```

Et asset er kun verificeret, hvis både person og en gyldig dato er udfyldt. En zone uden for standardlisten bliver vist som egen zone og giver en advarsel, så stavefejl opdages.

## Site-regler

Data fra to vandværker må aldrig blandes uden at det fremgår. Hvor site ikke kan afgøres, gættes det ikke: det rapporteres og giver exit 3.

- `--site NAVN`: analysér ét site. Navne sammenlignes uden hensyn til store og små bogstaver, ekstra mellemrum og Unicode-form.
- `--all-sites`: kør hvert site i sin egen mappe under `--out`. Scope er fælles, så kør hellere pr. site med eget `--scope`, hvis net overlapper.
- **Dokumentation på et andet site:** `DOKUMENTERET_ANDET_SITE`, og den vises kun, hvis der er trafik til den.
- **Dokumentation uden site:** `DOKUMENTERET_SITE_UAFKLARET`, i sit eget bånd og regnes ikke til sitet.
- **PDF og TXT** har intet site i sig selv. Angiv det med `--reference-site bilag.pdf=Testvandvaerk`.
- **Samme IP på flere sites:** afvigelsen `IP_PAA_FLERE_SITES`.
- **Logrækker fra et andet site** ifølge loggens site-kolonne tælles ikke med.
- **Logrækker uden site** tælles med på IP-match og giver exit 3, medmindre du med `--log-site-confirmed` bekræfter, at loggen kun dækker sitet. Flowet stiples i diagrammet, og `Antal_uden_site` viser antallet.
- **Asset-map og reviewfil:** når referencen dækker flere sites, skal hver række have en `Site`-kolonne. Ellers bruges rækken ikke, så en verificering ikke kan smitte fra ét vandværk til et andet.

Uden `--site` behandles kørslen som ét site. Flere sites, adresser uden site eller logrækker fra andre sites giver da exit 3.

## Store sites

- Over `--detail-threshold` adresser (standard 25) laves zonevise detaljediagrammer. Start med `07_zone_overview.svg`.
- `--min-count N` skjuler sjældne flows i diagrammet. Antallet af skjulte står altid i diagrammet, og alle flows står i CSV-filen.

Måling på en almindelig laptop: 1 mio. CSV-rækker (76 MB) tog cirka 12 sekunder for hele pipelinen og brugte cirka 25 MB hukommelse. Hukommelsen følger antallet af unikke IP'er og flows, ikke antallet af rækker. En `.json`-fil indlæses samlet og afvises over 512 MB; brug JSONL til store eksporter.

De to delkommandoer virker stadig hver for sig:

```powershell
python .\src\ot_asset_validator.py --reference .\input\inventory.csv --logs .\input\nams.csv --scope 192.0.2.0/24 --out .\resultat
```

```powershell
python .\src\ot_dataflow_diagram.py --assets .\resultat\01_alle_ip_adresser.csv --flows .\resultat\03_kommunikationsflows.csv --site-name "Testvandvaerk" --out .\diagram
```

## Fejlfinding

| Symptom | Årsag og løsning |
|---|---|
| `FEJL: ... ingen IP-felter genkendt` | Kolonnenavne ikke genkendt. Beskeden viser kolonnerne. Brug `--source-field` og `--dest-field`. |
| `FEJL: ... det angivne felt findes ikke` | Stavefejl i `--source-field`, `--dest-field` eller `--time-field`. |
| Alle assets står som ikke observeret | Se `04_feltmapping.csv`, og tjek om logfilen dækker sitet. Læs advarslerne. |
| Ingen flows, men IP'er er "nævnt" | Loggen har ingen retning. Eksportér med kilde- og destinationsfelt. |
| Observationsperiode er "ukendt" | Tidsstempler kunne ikke tolkes. Brug `--time-field`. Amerikanske datoer (MM/DD) afvises bevidst, fordi de kan forveksles med danske. |
| `Kun PNG mangler` | Graphviz er ikke installeret. SVG, DOT og Mermaid findes. |
| Exit 3 uden at du kan se hvorfor | Læs `BLOKERENDE`-linjerne øverst i `06_begraensninger_og_advarsler.txt`. |
| `FEJL: ... --reference-site` | Filen skal være en af dem i `--reference`. To filer med samme navn skal omdøbes. |
| `FEJL: Review-filen ... mangler kolonnerne` | Brug kolonnenavnene fra `08_review_skabelon.csv`. |
| `No such file or directory` ved skrivning | Windows' stigrænse på 260 tegn. Brug en kortere sti til `--out`. |

## Begrænsninger

- Kun IPv4. IPv6-værdier tælles og nævnes i advarslerne, men analyseres ikke.
- Resultatet afhænger af sensorens placering og periode. Lokal trafik på en switch kan mangle helt.
- NAT, DHCP og virtuelle enheder kan få IP og enhed til at falde fra hinanden. Ved routet trafik ser sensoren gatewayens MAC. En MAC på mindst 3 IP'er udelades derfor af sammenligningen, og der gives en advarsel.
- Samme trafik set af to sensorer tælles to gange. Værktøjet springer identiske filer over og advarer ved overlappende perioder, men kan ikke afgøre overlap på rækkeniveau.
- Datohuller findes pr. dag i UTC, så huller under et døgn ses ikke.
- Hypoteser om rolle bygger kun på hele ord i navne, aldrig på porte eller trafik. De kan stadig være forkerte.
- Scannede PDF'er kræver OCR uden for værktøjet.
- En uafsluttet `"` i en CSV kan sluge efterfølgende rækker. Værktøjet advarer, men kan ikke genskabe dem. Ret eksporten.
- I tætte diagrammer kan en etiket dække en linje, der krydser den. Hold musen over linjen, eller brug flowtabellen.
- DOT og Mermaid er ikke kørt i Graphviz eller en Mermaid-renderer. Python 3.10 og 3.11 er kun syntakstjekket. PDF er testet med PyMuPDF 1.28.2 på syntetiske filer, ikke på rigtige anlægsdokumenter.
- Tekst tegnet som vektorgrafik på en side, der også har almindelig tekst, kan ikke skelnes fra tabelstreger. Antallet står i `07_pdf_udtraek.csv`, men giver ikke exit 3.

Den samlede vurdering af, hvad der er testet og hvad der mangler, står i `docs/PRODUCTION_READINESS.md`.

## Datasikkerhed

- Kør på en autoriseret analysemaskine, ikke på PLC, HMI eller SCADA.
- Output indeholder interne adresser og skal klassificeres som kildedata.
- Rigtige anlægsdata må ikke deles med AI-tjenester uden skriftlig autorisation. `.gitignore` udelukker datafiler uden for `examples/`.

## Projektstruktur

```text
run_pipeline.py          samlet kommando
src/otvalidate/          kode (se ARCHITECTURE.md)
src/ot_*.py              de to selvstændige kommandoer
tools/run_demo.py        demo med fiktive data
tools/generate_synthetic.py   genererer demo- og stressdata
tools/generate_pdf_fixtures.py   skriver rigtige test-PDF'er
examples/synthetic/      kun fiktive RFC 5737-data
examples/sample_output/  output fra demoen
tests/                   python -m unittest discover -s tests (PDF-tests springes over uden PyMuPDF)
docs/                    audit, produktionsvurdering og validatorguide
```
