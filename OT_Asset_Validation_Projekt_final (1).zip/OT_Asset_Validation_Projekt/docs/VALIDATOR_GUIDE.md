# Validatoren alene

`src/ot_asset_validator.py` laver kun CSV-rapporterne. Brug `run_pipeline.py`, hvis du også vil have diagrammer og `rapport.html`. Status, afvigelser, formater og begrænsninger er beskrevet i `README.md`.

## Eksempler (PowerShell)

Med dokumentation og scope:

```powershell
python .\src\ot_asset_validator.py --reference .\input\ip_liste.pdf --logs .\input\nams_export.csv --scope 192.0.2.0/24 --out .\resultat
```

Flere net og filer:

```powershell
python .\src\ot_asset_validator.py --reference .\input\a.csv .\input\b.csv --logs .\input\log1.csv .\input\log2.jsonl --scope 192.0.2.0/24 --scope 198.51.100.0/24 --out .\resultat
```

Andre kolonnenavne:

```powershell
python .\src\ot_asset_validator.py --reference .\input\ip_liste.csv --logs .\input\export.csv --source-field clientAddress --dest-field remoteAddress --time-field receivedAt --out .\resultat
```

Feltnavne sammenlignes uden hensyn til store bogstaver og tegnsætning, så `Source.IP` og `sourceip` er det samme. Angives et felt, der ikke findes, stopper kørslen med en fejl, som viser filens kolonner.

## Hvis et scope mangler

Scope er det, der adskiller "udokumenteret lokal enhed" fra "ekstern adresse". Uden scope får udokumenterede adresser `IKKE_I_REFERENCE_SCOPE_UKENDT` og kaldes ikke afvigelser. Angiv kun net, som er godkendt for sitet.

## Tidsstempler

Værktøjet forstår ISO 8601 (med `Z` eller offset), Unix-tid i sekunder og millisekunder samt danske formater som `04-11-2026 08:00:00` og `04.11.2026 08:00`. Tider med offset omregnes til UTC. Tider uden tidszone vises som `(uden tidszone)` og antages ikke at være UTC. Amerikansk `MM/DD/YYYY` forstås ikke; `DD/MM/YYYY` antages, så en amerikansk dato med dag ≤ 12 læses forkert. Tjek `05_opsummering.csv`, hvis perioden ser forkert ud.

## PDF

PDF kræver PyMuPDF og kopierbar tekst. Alle IP'er i en PDF er kandidater: dokumentet kan rumme gateways, DNS, eksempler og gamle adresser. Subnet (`192.0.2.0/24`) og netmasker tælles ikke med. Scannede sider nævnes i advarslerne og kræver godkendt OCR uden for værktøjet.

## Fortolkning

Et match er aldrig en fysisk bekræftelse. Brug enheds-ID, MAC, switchport, anlægsdokumentation og driftspersonale til den endelige validering, og notér resultatet i asset-map med person og dato.
