# Teknisk audit af version 1

Fejl markeret **(R)** er reproduceret ved at køre den oprindelige kode på syntetiske data. Øvrige er fundet ved gennemlæsning.

## Kritisk: falske konklusioner uden advarsel

| # | Fejl | Virkning |
|---|---|---|
| 1 | **(R)** En kolonne `source` med sensornavn skygger for `source_ip` | 0 flows, aktivt asset står som `IKKE_OBSERVERET` |
| 2 | **(R)** Felter opdages kun i første logrække | Ændret JSONL-skema mister alle flows, asset står som `IKKE_OBSERVERET` |
| 3 | **(R)** Stavefejl i `--source-field` giver exit 0 | 0 flows og et tilsyneladende gyldigt resultat |
| 4 | **(R)** Rollegæt søger også i statusteksten, og `OBSERVERET` indeholder "server" | Alle unavngivne assets bliver `Server` i zonen Supervision |
| 5 | **(R)** Rollegæt er delstrengsmatch | `Pumpestation` bliver Engineering Workstation, `api-node` bliver Historian |
| 6 | **(R)** Uden `--scope` bliver `I_scope` ≠ `JA` til `Eksternt` | Alle PLC'er tegnes som eksterne |
| 7 | Graphviz rangerer efter kanternes retning | PLC står over HMI, og tegningen ligner en topologi |
| 8 | Manuel mapping og gæt ser ens ud, og verificering findes ikke | Krav om adskilt evidens var ikke opfyldt |

## Høj: forkerte eller manglende data

| # | Fejl | Virkning |
|---|---|---|
| 9 | **(R)** Subnet-broadcast og multicast behandles som værter | `192.0.2.255` kaldes udokumenteret asset |
| 10 | **(R)** `255.255.255.255` og `0.0.0.0` fjernes også fra logs | Flows forsvinder |
| 11 | **(R)** MAC sammenlignes ikke | Afvigelse ses ikke og kommer ikke i køen |
| 12 | **(R)** Retning i `src=… dst=…`-syslog smides væk | Ingen flows, dokumenteret kilde står som "nævnt" |
| 13 | **(R)** `TCP`/`tcp` og `502`/`502.0` er forskellige flows | Oppustet flowtabel |
| 14 | **(R)** Samme fil to gange tælles dobbelt uden advarsel | Forkerte tal |
| 15 | **(R)** Ugyldige IP'er i dokumentation droppes uden besked | Hul i dokumentation skjules |
| 16 | IP sidst i en sætning (`... 192.0.2.10.`) findes ikke | Adresser mangler fra PDF/TXT |
| 17 | Ingen samlet observationsperiode, datohuller eller forældelse | "Ikke observeret" kan ikke tolkes |
| 18 | Ingen site-filtrering | Andre sites' assets kaldes udokumenterede eller blandes ind |

## Robusthed og sikkerhed

| # | Fejl | Virkning |
|---|---|---|
| 19 | **(R)** CSV i cp1252 fra dansk Excel fejler | Standardeksport kan ikke læses |
| 20 | **(R)** Felt over 128 KB giver traceback | `csv.Error` fanges ikke |
| 21 | **(R)** Dybt JSON stopper hele kørslen. Det samme gælder én dårlig JSONL-linje (fra gennemlæsning) | Hele filen tabes |
| 22 | **(R)** DOT: site-navn escapes ikke. Mermaid: etiketter escapes heller ikke (fra gennemlæsning) | Injektion og ødelagte diagrammer |
| 23 | Asset catalog skrives uden formelbeskyttelse | CSV-injektion via navne |
| 24 | **(R)** Zone uden for standardlisten forsvinder fra DOT. Mermaid slår et felt op, der aldrig blev sat, hvilket giver KeyError (fra gennemlæsning) | Assets forsvinder, eller kørslen stopper |
| 25 | Backslash i f-string-udtryk (linje 265) | Er en syntaksfejl før Python 3.12, selvom README lover 3.10+. Ikke kørt på 3.10/3.11, som ikke findes på testmaskinen |
| 26 | Gamle PNG/SVG bliver liggende, hvis en ny kørsel ikke når dertil | Gammelt diagram ligner nyt |
| 27 | `.gitignore` udelukker ikke CSV/PDF uden for faste mapper | Rigtige data kan committes |

## Ineffektivt eller overflødigt

- pandas kun til at læse to CSV-filer, og typeinferens gør `502` til `502.0`.
- Pipelinen skriver CSV, starter en ny proces og læser den igen, så apostroffen fra formelbeskyttelsen følger med ind i diagrammet.
- 22,6 s pr. 1 mio. rækker: feltopslag, regex og `ipaddress` for hver celle.
- Farver pr. zone uden tegnforklaring, rød linje for "ekstern" (en implicit vurdering), og uforkortede enum-værdier på kortene.

## Fund fra uafhængig review af version 2

En separat review-agent kørte fjendtlige input mod den nye kode, og alle disse er rettet med regressionstests i `tests/test_review_findings.py`.

- **Falske konklusioner:** uafsluttet anførselstegn slugte senere rækker; loggens site-kolonne blev ignoreret; PDF/TXT-kandidater gik igen på alle sites uden advarsel; `192.0.2.10/24` blev læst som subnet; MAC-værdien `unknown` gav `MAC_AFVIGER`; `SIDST_SET_FOER_LOGSLUT` blandede UTC og tider uden tidszone; en logfil uden IP'er gav ingen advarsel; `Verified_date=ikke endnu` gav verificeret status; et navn fra loggen kunne danne rolle og zone; første/seneste tid blev sammenlignet som samlet tekst.
- **Sikkerhed:** oprydning kunne slette brugerens egne SVG'er i `zoner/`; Mermaid-direktiver (`%%{init}%%`) overlevede i zonenavne; site-mapper, der kun afveg i store/små bogstaver, overskrev hinanden på Windows.
- **Tracebacks:** ugyldige Unicode-surrogater, JSON-heltal med 5000 cifre, datoer som `0001-01-01`, meget store `--stale-days`, overskrift over 16 MB, korte rækker i diagramkommandoen.
- **Ydelse:** en tekstlinje på 1 MB uden `=` ville tage timer (kvadratisk regex). Tekstlinjer afkortes nu til 8192 tegn med en advarsel.
- **Layout:** lange navne og titler løb ud over kanten; etiketter dækkede andre linjer. Etiketter glider nu væk fra krydsende linjer, men i tætte diagrammer kan de stadig dække en linje.
