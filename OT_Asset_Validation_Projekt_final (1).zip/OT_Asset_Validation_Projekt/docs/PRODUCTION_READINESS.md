# GO/NO-GO assessment, version 2.1.0

**Verdict: NO-GO for production. GO for prototype use on synthetic data.**
This is a prototype, not an approved deployment. All verification used synthetic RFC 5737 data.

## Verified

| Item | Evidence |
|---|---|
| Regression and integration tests | 271 passed on Python 3.12 with PyMuPDF 1.28.2, PDF tests required (final run) |
| End-to-end demo | Three scenarios gave the expected exit codes: 0, 3, 3 |
| PDF handling | Real synthetic PDFs: multi-page tables, scans, OCR layers, vector text, truncated, encrypted, malformed |
| Site attribution | Tests for unresolved, foreign and shared-IP cases; gaps give exit 3 |
| Review workflow | Tests show decisions leave input files and evidence columns unchanged; changed evidence reopens a decision |
| Offline operation | Audit-hook test saw no sockets, processes or writes outside `--out` (Python-level only) |
| Visualization | Inspected by eye in a browser, before the last legend and dashed-flow changes; those are covered by tests only |

## Not finished or not verified

- **Security review not completed.** The Claude Security scan could not run in this session. The manual security review was stopped on request and produced no findings. No conclusion can be drawn from either.
- **Mutation test not rerun.** It killed 103 of 147 sampled mutants (70%) before the later fixes. The current rate is unknown.
- **Python 3.14:** the final code was not run. An earlier version passed.
- **Python 3.10 and 3.11:** syntax check only, and not on the final code.
- **DOT, Mermaid, PNG:** never rendered in Graphviz or a Mermaid renderer.
- **Real documents and logs:** never tested. Real exports may behave differently.
- **MuPDF native code** is outside what the offline test can observe.
- **Audit items not fixed:** see the limitations below.

## Criteria

| Criterion | Status |
|---|---|
| Tests pass with PDF tests required | GO |
| Gaps are reported and give exit 3 | GO, within tested cases |
| Independent security review completed | **NO-GO** |
| Tested with approved real exports by authorised staff | **NO-GO** |
| DOT and Mermaid outputs rendered and checked | **NO-GO** |
| PyMuPDF version and hash approved by IT/OT security | **NO-GO** |
| Approval from the responsible owner | **NO-GO** |

## Known limitations

- IPv4 only. Results depend on sensor placement and observation period.
- A flow is observed traffic, not proof of a physical connection.
- Scanned pages need approved OCR outside the tool.
- Vector-drawn text on a page that also has normal text is not detected.
- In dense diagrams a label can cover a crossing line.
- Very long paths can fail on Windows (260-character limit).
