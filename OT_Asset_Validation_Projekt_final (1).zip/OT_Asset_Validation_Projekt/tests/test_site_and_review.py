"""Site attribution must never mix waterworks silently; human review must never alter evidence."""
import hashlib
import unittest

from helpers import TempDirTest, read_rows
from otvalidate.ingest import InputError, LogAggregator, load_reference
from otvalidate.reconcile import parse_scopes, reconcile
from otvalidate.review import load_decisions
from otvalidate.zones import build_nodes, load_asset_map
from test_pipeline import run_cli

INV = "ip;device_name;site;mac\n192.0.2.1;PLC-N;Nord;00:00:00:00:00:01\n192.0.2.2;HMI-S;Syd;00:00:00:00:00:02\n192.0.2.3;DELT;Nord;\n192.0.2.3;DELT;Syd;\n192.0.2.4;INTET-SITE;;\n"
LOG = "time;src_ip;dst_ip;protocol;dst_port\n2026-11-04T08:00:00Z;192.0.2.1;192.0.2.2;TCP;502\n"
LOG_WITH_SITE = "site;time;src_ip;dst_ip\nNord;2026-11-04T08:00:00Z;192.0.2.1;192.0.2.3\nSyd;2026-11-04T08:00:00Z;192.0.2.2;192.0.2.3\n;2026-11-04T08:00:00Z;192.0.2.4;192.0.2.3\n"


class SiteAttribution(TempDirTest):
    def validate(self, inventory=INV, log=LOG, site="Nord", confirmed=False, **ref_kwargs):
        ref = load_reference([self.write("inv.csv", inventory)], site=site, **ref_kwargs)
        logs = LogAggregator({}, site=site, site_confirmed=confirmed)
        logs.add_file(self.write("log.csv", log))
        return reconcile(ref, logs, parse_scopes(["192.0.2.0/24"]))

    def status(self, result):
        return {row["IP"]: row["Status"] for row in result.asset_rows}

    def row(self, result, ip):
        return next(row for row in result.asset_rows if row["IP"] == ip)

    def test_other_sites_assets_are_never_counted_as_this_sites_documentation(self):
        result = self.validate()
        self.assertEqual(self.status(result)["192.0.2.2"], "DOKUMENTERET_ANDET_SITE")
        self.assertEqual(self.row(result, "192.0.2.2")["I_reference"], "NEJ")

    def test_asset_without_site_is_unresolved_not_this_site(self):
        result = self.validate()
        self.assertEqual(self.status(result)["192.0.2.4"], "DOKUMENTERET_SITE_UAFKLARET")
        self.assertEqual(self.row(result, "192.0.2.4")["I_reference"], "UAFKLARET")
        self.assertEqual(self.row(result, "192.0.2.4")["Prioritet"], 1)
        self.assertTrue(any("192.0.2.4" in b for b in result.blockers), result.blockers)

    def test_same_ip_on_two_sites_is_flagged(self):
        result = self.validate()
        self.assertIn("IP_PAA_FLERE_SITES", self.row(result, "192.0.2.3")["Afvigelser"])
        self.assertEqual(self.row(result, "192.0.2.3")["Prioritet"], 1)
        self.assertEqual(self.row(result, "192.0.2.3")["Dokumenteret_anlaeg"], "Nord")

    def test_log_rows_are_attributed_by_site_column_when_present(self):
        result = self.validate(log=LOG_WITH_SITE)
        self.assertEqual(self.row(result, "192.0.2.1")["Antal_som_kilde"], 1)
        self.assertEqual(self.row(result, "192.0.2.3")["Antal_som_destination"], 2)  # Nord row + the row with no site.
        self.assertNotIn("192.0.2.2", self.status(result))  # Syd's asset, seen only in Syd's row: not part of Nord.
        self.assertTrue(any("1 logrækker" in b for b in result.blockers), result.blockers)

    def test_log_without_site_column_blocks_until_user_confirms(self):
        unconfirmed = self.validate()
        self.assertTrue(any("log.csv" in b and "--log-site-confirmed" in b for b in unconfirmed.blockers), unconfirmed.blockers)
        inventory = "ip;site\n192.0.2.1;Nord\n"
        confirmed = self.validate(inventory=inventory, confirmed=True)
        self.assertEqual(confirmed.blockers, [])
        self.assertTrue(any("bekræftet" in w for w in confirmed.warnings))

    def test_explicit_other_site_rows_stay_out_even_when_confirmed(self):
        result = self.validate(log=LOG_WITH_SITE, confirmed=True)
        self.assertNotIn("192.0.2.2", self.status(result))

    def test_log_losing_every_row_to_site_filter_blocks(self):
        result = self.validate(log="location;src_ip;dst_ip\nHal 3;192.0.2.1;192.0.2.2\n")
        self.assertTrue(any("Hal 3" in b for b in result.blockers), result.blockers)

    def test_no_site_choice_with_several_sites_blocks(self):
        result = self.validate(site="")
        self.assertTrue(any("flere sites" in b for b in result.blockers), result.blockers)

    def test_single_site_without_filter_has_no_blockers(self):
        self.assertEqual(self.validate(inventory="ip;site\n192.0.2.1;Nord\n", site="").blockers, [])

    def test_txt_candidates_are_unresolved_until_assigned_to_a_site(self):
        csv_path, txt = self.write("a.csv", "ip;site\n192.0.2.1;Nord\n"), self.write("b.txt", "gateway 192.0.2.99\n")
        ref = load_reference([csv_path, txt], site="Nord")
        self.assertIn("192.0.2.99", ref.unresolved)
        self.assertNotIn("192.0.2.99", ref.known)
        assigned = load_reference([csv_path, txt], site="Nord", file_sites={"b.txt": "Nord"})
        self.assertIn("192.0.2.99", assigned.known)
        self.assertEqual(assigned.known["192.0.2.99"].sites, {"Nord"})
        other = load_reference([csv_path, txt], site="Nord", file_sites={"b.txt": "Syd"})
        self.assertIn("192.0.2.99", other.other_site)

    def test_reference_site_naming_unknown_file_is_input_error(self):
        with self.assertRaisesRegex(InputError, "findes.pdf"):
            load_reference([self.write("a.csv", "ip;site\n192.0.2.1;Nord\n")], site="Nord", file_sites={"findes.pdf": "Nord"})

    def test_unresolved_gets_its_own_zone_and_is_not_drawn_as_documented(self):
        result = self.validate()
        node = next(n for n in build_nodes(result.asset_rows, result.flow_rows, {}) if n.ip == "192.0.2.4")
        self.assertEqual(node.zone, "Site uafklaret")
        self.assertFalse(node.documented)

    def test_verification_in_map_without_site_is_not_applied_when_reference_has_several_sites(self):
        path = self.write("m.csv", "IP;Zone;Verified_by;Verified_date\n192.0.2.1;Control;JL;2026-10-12\n")
        mapping, warnings = load_asset_map(path, site="Nord", multi_site=True)
        self.assertEqual(mapping, {})
        self.assertTrue(any("192.0.2.1" in w for w in warnings))

    def test_map_rows_follow_their_site_column(self):
        path = self.write("m.csv", "Site;IP;Zone;Verified_by;Verified_date\nSyd;192.0.2.1;Field;JL;2026-10-12\nNord;192.0.2.1;Control;;\n")
        mapping, _ = load_asset_map(path, site="Nord", multi_site=True)
        self.assertEqual((mapping["192.0.2.1"].zone, mapping["192.0.2.1"].verified), ("Control", ""))

    def test_all_sites_reports_unresolved_per_site_and_exits_3(self):
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", self.write("inv.csv", INV), "--logs", self.write("log.csv", LOG_WITH_SITE), "--scope", "192.0.2.0/24", "--all-sites", "--out", out)
        self.assertEqual(result.returncode, 3, result.stderr)
        self.assertEqual(sorted(p.name for p in out.iterdir()), ["Nord", "Syd"])
        nord = {r["IP"]: r for r in read_rows(out / "Nord" / "validation" / "01_alle_ip_adresser.csv")}
        syd = {r["IP"]: r for r in read_rows(out / "Syd" / "validation" / "01_alle_ip_adresser.csv")}
        self.assertEqual(nord["192.0.2.1"]["Status"], "DOKUMENTERET_KILDE_OBSERVERET")
        self.assertNotIn("192.0.2.1", syd)
        self.assertEqual(syd["192.0.2.2"]["Status"], "DOKUMENTERET_KILDE_OBSERVERET")

    def test_log_site_confirmed_is_refused_with_all_sites(self):
        result = run_cli("run_pipeline.py", "--reference", self.write("inv.csv", INV), "--logs", self.write("log.csv", LOG), "--all-sites", "--log-site-confirmed", "--out", self.tmp / "o")
        self.assertEqual(result.returncode, 2)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Review(TempDirTest):
    INVENTORY = "ip;device_name;mac\n192.0.2.1;PLC-1;00:00:00:00:00:01\n192.0.2.2;HMI-1;\n"
    LOGS = "src_ip;dst_ip;src_mac\n192.0.2.1;192.0.2.2;00:00:00:00:00:99\n192.0.2.9;192.0.2.2;\n"

    def setUp(self):
        super().setUp()
        self.inv = self.write("i.csv", self.INVENTORY)
        self.log = self.write("l.csv", self.LOGS)

    def run_pipeline(self, *extra, out="o"):
        output = self.tmp / out
        result = run_cli("run_pipeline.py", "--reference", self.inv, "--logs", self.log, "--scope", "192.0.2.0/24", "--out", output, *extra)
        self.assertIn(result.returncode, (0, 3), result.stderr)
        return output

    def evidence(self, out, ip):
        return next(r for r in read_rows(out / "validation" / "01_alle_ip_adresser.csv") if r["IP"] == ip)["Evidens_ID"]

    def decisions(self, *rows):
        return self.write("beslutninger.csv", "Site;IP;Evidens_ID;Beslutning;Beslutter;Dato;Begrundelse\n" + "\n".join(";".join(r) for r in rows) + "\n")

    def test_template_lists_assets_with_evidence_id_and_blank_decision(self):
        rows = read_rows(self.run_pipeline() / "validation" / "08_review_skabelon.csv")
        row = next(r for r in rows if r["IP"] == "192.0.2.1")
        self.assertEqual(len(row["Evidens_ID"]), 16)
        self.assertEqual(row["Beslutning"], "")

    def test_decisions_leave_every_input_file_untouched(self):
        out = self.run_pipeline()
        path = self.decisions(("", "192.0.2.1", self.evidence(out, "192.0.2.1"), "GODKENDT", "JL", "2026-11-05", "Tjekket på tavlen"))
        before = {p: sha(p) for p in (self.inv, self.log, path)}
        self.run_pipeline("--review-file", path, out="o2")
        self.assertEqual({p: sha(p) for p in before}, before)

    def test_decisions_never_change_evidence_columns(self):
        out = self.run_pipeline()
        path = self.decisions(("", "192.0.2.1", self.evidence(out, "192.0.2.1"), "AFVIST", "JL", "2026-11-05", "Forkert enhed"))
        with_review = self.run_pipeline("--review-file", path, out="o2")
        review_columns = {"Review_status", "Review_af", "Review_dato", "Review_begrundelse"}
        first = read_rows(out / "validation" / "01_alle_ip_adresser.csv")
        second = read_rows(with_review / "validation" / "01_alle_ip_adresser.csv")
        strip = lambda rows: [{k: v for k, v in row.items() if k not in review_columns} for row in rows]
        self.assertEqual(strip(first), strip(second))
        self.assertEqual(read_rows(out / "validation" / "03_kommunikationsflows.csv"), read_rows(with_review / "validation" / "03_kommunikationsflows.csv"))

    def test_approval_is_not_physical_verification(self):
        out = self.run_pipeline()
        path = self.decisions(("", "192.0.2.1", self.evidence(out, "192.0.2.1"), "GODKENDT", "JL", "2026-11-05", "OK"))
        reviewed = self.run_pipeline("--review-file", path, out="o2")
        row = next(r for r in read_rows(reviewed / "validation" / "01_alle_ip_adresser.csv") if r["IP"] == "192.0.2.1")
        self.assertEqual(row["Review_status"], "GODKENDT")
        self.assertEqual(row["Verificering"], "IKKE_VERIFICERET")
        svg = (reviewed / "diagram" / "02_site_dataflow.svg").read_text(encoding="utf-8")
        self.assertNotIn("✓ Verificeret", svg.split("Tegnforklaring")[0])
        self.assertIn("Review: godkendt", svg)

    def test_approved_and_rejected_leave_the_queue_investigate_stays(self):
        out = self.run_pipeline()
        path = self.decisions(("", "192.0.2.1", self.evidence(out, "192.0.2.1"), "GODKENDT", "JL", "2026-11-05", "OK"),
                              ("", "192.0.2.2", self.evidence(out, "192.0.2.2"), "AFVIST", "JL", "2026-11-05", "Forkert"),
                              ("", "192.0.2.9", self.evidence(out, "192.0.2.9"), "UNDERSOEG", "JL", "2026-11-05", "Spørg drift"))
        reviewed = self.run_pipeline("--review-file", path, out="o2")
        queue = {r["IP"]: r for r in read_rows(reviewed / "validation" / "02_til_gennemgang.csv")}
        self.assertEqual(list(queue), ["192.0.2.9"])
        self.assertEqual(queue["192.0.2.9"]["Review_status"], "UNDERSOEGES")
        everything = {r["IP"]: r for r in read_rows(reviewed / "validation" / "01_alle_ip_adresser.csv")}
        self.assertEqual(everything["192.0.2.2"]["Review_status"], "AFVIST")

    def test_changed_evidence_reopens_a_decision(self):
        out = self.run_pipeline()
        path = self.decisions(("", "192.0.2.1", self.evidence(out, "192.0.2.1"), "GODKENDT", "JL", "2026-11-05", "OK"))
        self.log.write_text(self.LOGS.replace("00:00:00:00:00:99", "00:00:00:00:00:77"), encoding="utf-8")
        reviewed = self.run_pipeline("--review-file", path, out="o2")
        row = next(r for r in read_rows(reviewed / "validation" / "02_til_gennemgang.csv") if r["IP"] == "192.0.2.1")
        self.assertEqual(row["Review_status"], "FORAELDET")
        self.assertEqual(row["Prioritet"], "1")
        log = read_rows(reviewed / "validation" / "09_review_log.csv")
        self.assertEqual(log[0]["Udfald"], "FORAELDET")

    def test_latest_decision_wins_and_history_is_kept(self):
        out = self.run_pipeline()
        evidence = self.evidence(out, "192.0.2.1")
        path = self.decisions(("", "192.0.2.1", evidence, "UNDERSOEG", "JL", "2026-11-05", "Spørg"), ("", "192.0.2.1", evidence, "GODKENDT", "AB", "2026-11-06", "Afklaret"))
        reviewed = self.run_pipeline("--review-file", path, out="o2")
        self.assertEqual([r["Udfald"] for r in read_rows(reviewed / "validation" / "09_review_log.csv")], ["ERSTATTET", "AKTUEL"])
        row = next(r for r in read_rows(reviewed / "validation" / "01_alle_ip_adresser.csv") if r["IP"] == "192.0.2.1")
        self.assertEqual((row["Review_status"], row["Review_af"]), ("GODKENDT", "AB"))

    def test_incomplete_or_invalid_decisions_are_refused_and_reported(self):
        path = self.decisions(("", "192.0.2.1", "x", "GODKENDT", "", "2026-11-05", "Ingen person"), ("", "192.0.2.1", "x", "GODKENDT", "JL", "snart", "Dårlig dato"),
                              ("", "192.0.2.1", "x", "MÅSKE", "JL", "2026-11-05", "Ukendt"), ("", "192.0.2.1", "x", "AFVIST", "JL", "2026-11-05", ""), ("", "ikke-ip", "x", "AFVIST", "JL", "2026-11-05", "Y"))
        decisions, warnings = load_decisions(path)
        self.assertEqual(decisions, [])
        self.assertEqual(len(warnings), 5)

    def test_blank_decision_rows_from_the_template_are_ignored_quietly(self):
        decisions, warnings = load_decisions(self.decisions(("", "192.0.2.1", "x", "", "", "", "")))
        self.assertEqual((decisions, warnings), ([], []))

    def test_decision_for_unknown_ip_is_reported(self):
        path = self.decisions(("", "192.0.2.200", "x", "AFVIST", "JL", "2026-11-05", "Y"))
        reviewed = self.run_pipeline("--review-file", path)
        self.assertEqual(read_rows(reviewed / "validation" / "09_review_log.csv")[0]["Udfald"], "UKENDT_IP")

    def test_decisions_follow_site(self):
        path = self.decisions(("Syd", "192.0.2.1", "x", "AFVIST", "JL", "2026-11-05", "Y"), ("Nord", "192.0.2.1", "x", "GODKENDT", "JL", "2026-11-05", "Y"))
        decisions, _ = load_decisions(path, site="Nord", multi_site=True)
        self.assertEqual([d.decision for d in decisions], ["GODKENDT"])
        blank = self.decisions(("", "192.0.2.1", "x", "AFVIST", "JL", "2026-11-05", "Y"))
        decisions, warnings = load_decisions(blank, site="Nord", multi_site=True)
        self.assertEqual(decisions, [])
        self.assertTrue(warnings)

    def test_review_file_inside_output_folder_is_refused(self):
        out = self.tmp / "o"
        path = self.write("o/validation/beslutninger.csv", "Site;IP;Evidens_ID;Beslutning;Beslutter;Dato;Begrundelse\n")
        result = run_cli("run_pipeline.py", "--reference", self.inv, "--logs", self.log, "--review-file", path, "--out", out)
        self.assertEqual(result.returncode, 2)
        self.assertTrue(path.exists())

    def test_excel_style_formula_guard_in_rationale_round_trips(self):
        out = self.run_pipeline()
        path = self.decisions(("", "192.0.2.1", self.evidence(out, "192.0.2.1"), "GODKENDT", "JL", "05-11-2026", "=HYPERLINK(1)"))
        reviewed = self.run_pipeline("--review-file", path, out="o2")
        row = next(r for r in read_rows(reviewed / "validation" / "01_alle_ip_adresser.csv") if r["IP"] == "192.0.2.1")
        self.assertTrue(row["Review_begrundelse"].startswith("'="))


if __name__ == "__main__":
    unittest.main()
