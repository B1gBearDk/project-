"""Offline guarantees checked while the tool runs, and what the diagrams may claim."""
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import textwrap
import unittest
import xml.etree.ElementTree as ET

from helpers import EXAMPLES, ROOT, TempDirTest
from otvalidate import diagrams, render_svg
from otvalidate.zones import aggregate_edges, build_nodes
from test_diagrams import asset, flow
from test_pipeline import run_cli

# Runs the real entry point under a Python audit hook. Every socket, process, or file write is recorded.
AUDIT_RUNNER = textwrap.dedent("""
    import json, os, runpy, sys
    report_path, out_dir, script = sys.argv[1:4]
    sys.argv = sys.argv[3:]
    report = []
    CHECK = ("socket.", "subprocess.", "os.system", "os.exec", "os.spawn", "os.startfile", "os.posix_spawn",
             "urllib.", "http.client.", "ftplib.", "smtplib.", "telnetlib.", "imaplib.", "poplib.", "webbrowser.", "ctypes.dlopen")
    finished = []
    def hook(event, args):
        if finished:
            return
        if event.startswith(CHECK):
            report.append([event, repr(args)[:200]])
        elif event == "open" and len(args) > 2:
            path, mode, flags = args[0], args[1], args[2]
            writes = (mode and any(c in str(mode) for c in "wax+")) or (mode is None and isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR))
            if writes and isinstance(path, (str, bytes, os.PathLike)):
                report.append(["write", os.path.abspath(os.fsdecode(path))])
    sys.addaudithook(hook)
    code = 0
    try:
        runpy.run_path(script, run_name="__main__")
    except SystemExit as exc:
        code = exc.code or 0
    finished.append(True)
    with open(report_path, "w", encoding="utf-8") as stream:
        json.dump({"code": code, "events": report}, stream)
""")


class RuntimeOffline(TempDirTest):
    def audited(self, script_args, runner=AUDIT_RUNNER):
        out = self.tmp / "out"
        runner_path = self.tmp / "runner.py"
        runner_path.write_text(runner, encoding="utf-8")
        report = self.tmp / "report.json"
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1", "PATH": ""}
        done = subprocess.run([sys.executable, str(runner_path), str(report), str(out), str(ROOT / "run_pipeline.py"), *map(str, script_args), "--out", str(out)],
                              capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
        self.assertTrue(report.exists(), done.stderr)
        return out, json.loads(report.read_text(encoding="utf-8"))

    def test_the_audit_harness_can_really_see_forbidden_activity(self):
        """Negative control: without this, an empty report would prove nothing."""
        target = self.write("evil.py", "import socket, subprocess, sys\ns = socket.socket()\ntry:\n    s.connect(('192.0.2.1', 1))\nexcept OSError:\n    pass\nsubprocess.run([sys.executable, '-c', ''])\nopen(r'%s', 'w').close()\n" % (self.tmp / "outside.txt"))
        runner_path = self.tmp / "runner.py"
        runner_path.write_text(AUDIT_RUNNER, encoding="utf-8")
        report = self.tmp / "report.json"
        s = subprocess.run([sys.executable, str(runner_path), str(report), str(self.tmp), str(target)], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
        self.assertTrue(report.exists(), s.stderr)
        events = json.loads(report.read_text(encoding="utf-8"))["events"]
        names = {event[0] for event in events}
        self.assertIn("socket.connect", names)
        self.assertIn("subprocess.Popen", names)
        self.assertIn("write", names)

    def assert_clean(self, out, report):
        forbidden = [event for event in report["events"] if event[0] != "write"]
        self.assertEqual(forbidden, [], "tool must not open sockets or start processes")
        writes = [Path(event[1]) for event in report["events"] if event[0] == "write"]
        self.assertTrue(writes, "harness saw no writes at all")
        for path in writes:
            self.assertTrue(path.resolve().is_relative_to(out.resolve()), f"write outside --out: {path}")

    def test_pipeline_uses_no_network_processes_or_outside_writes(self):
        out, report = self.audited(["--reference", EXAMPLES / "inventory.csv", "--logs", EXAMPLES / "nams.csv", "--scope", "192.0.2.0/24", "--asset-map", EXAMPLES / "asset_map.csv"])
        self.assertEqual(report["code"], 0)
        self.assert_clean(out, report)

    @unittest.skipUnless(importlib.util.find_spec("pymupdf"), "PyMuPDF mangler")
    def test_pdf_path_uses_no_python_level_network_or_processes(self):
        """The audit hook sees Python calls. MuPDF's native code is outside what this test can observe."""
        out, report = self.audited(["--reference", EXAMPLES / "pdf" / "inventory_tabel.pdf", "--logs", EXAMPLES / "nams.csv", "--scope", "192.0.2.0/24"])
        report["events"] = [event for event in report["events"] if event[0] != "ctypes.dlopen" and "dlopen" not in event[0]]
        self.assert_clean(out, report)


class OutputCarriesNoReferences(TempDirTest):
    def test_no_scripts_remote_references_or_absolute_paths_in_any_output(self):
        out = self.tmp / "o"
        self.assertEqual(run_cli("run_pipeline.py", "--reference", EXAMPLES / "inventory.csv", "--logs", EXAMPLES / "nams.csv", "--scope", "192.0.2.0/24", "--detail-threshold", "1", "--out", out).returncode, 0)
        files = [p for p in out.rglob("*") if p.is_file() and p.suffix != ".png"]
        self.assertGreater(len(files), 10)
        for path in files:
            text = path.read_text(encoding="utf-8-sig")
            self.assertNotIn(str(self.tmp), text, f"absolute path in {path.name}")
            self.assertNotIn(os.environ.get("USERNAME", "\0"), text, f"user name in {path.name}")
            if path.suffix in (".svg", ".html"):
                without_namespace = text.replace("http://www.w3.org/2000/svg", "")
                self.assertIsNone(re.search(r"https?://|<script|<iframe|<link|<img|<object|<embed|\bsrc\s*=|\bhref\s*=(?!.#)|url\((?!#)|@import", without_namespace, re.I), path.name)


class SourceBoundaries(unittest.TestCase):
    def test_no_scanner_or_ot_protocol_clients_named_in_source(self):
        pattern = re.compile(r"\b(nmap|masscan|pymodbus|snap7|opcua|asyncua|bacpypes|pysnmp|scapy|telemetry|sentry|analytics)\b", re.I)
        for path in [ROOT / "run_pipeline.py", *ROOT.glob("src/**/*.py"), *ROOT.glob("tools/*.py")]:
            self.assertIsNone(pattern.search(path.read_text(encoding="utf-8")), path.name)

    def test_only_optional_dependency_is_pymupdf(self):
        lines = [line.strip() for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines() if line.strip() and not line.startswith("#")]
        self.assertEqual(len(lines), 1)
        self.assertTrue(lines[0].startswith("PyMuPDF"))


def luminance(color):
    channels = [int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    r, g, b = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in channels]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    high, low = sorted((luminance(a), luminance(b)), reverse=True)
    return (high + 0.05) / (low + 0.05)


class VisualClaims(TempDirTest):
    def sample(self, **kwargs):
        rows = [asset("192.0.2.1", name="PLC-1"), asset("192.0.2.2", name="HMI-1", status="DOKUMENTERET_KUN_DESTINATION", observation="KUN_DESTINATION")]
        nodes = build_nodes(rows, [], {})
        edges, _ = aggregate_edges([flow("192.0.2.1", "192.0.2.2")], nodes)
        return nodes, edges

    def test_every_output_format_states_it_is_not_physical_topology(self):
        nodes, edges = self.sample()
        svg = render_svg.render_svg(diagrams.site_diagram("S", nodes, edges, [], []))
        overview = render_svg.render_svg(diagrams.overview_diagram("S", nodes, edges, [], []))
        detail = render_svg.render_svg(diagrams.zone_detail("S", "Control", nodes, edges, []))
        for name, text in (("svg", svg), ("overview", overview), ("detail", detail), ("dot", diagrams.build_dot("S", nodes, edges))):
            self.assertIn("ikke fysisk topologi", text, name)

    def test_mermaid_states_it_in_visible_text_not_only_a_comment(self):
        nodes, edges = self.sample()
        visible = [line for line in diagrams.build_mermaid("S", nodes, edges).splitlines() if not line.startswith("%%")]
        self.assertTrue(any("ikke fysisk topologi" in line for line in visible))

    def test_diagram_vocabulary_avoids_physical_connection_words(self):
        nodes, edges = self.sample()
        svg = render_svg.render_svg(diagrams.site_diagram("S", nodes, edges, [], []))
        root = ET.fromstring(svg)
        visible = " ".join(el.text or "" for el in root.iter() if el.tag.endswith("text")).lower()
        for word in ("forbundet", "tilsluttet", "connected", "link ok", "kabel til"):
            self.assertNotIn(word, visible)

    def test_legend_says_what_the_count_means(self):
        nodes, edges = self.sample()
        self.assertIn("logposter", render_svg.render_svg(diagrams.site_diagram("S", nodes, edges, [], [])))

    def test_edge_hover_names_the_log_files_it_came_from(self):
        nodes = build_nodes([asset("192.0.2.1"), asset("192.0.2.2")], [], {})
        row = {**flow("192.0.2.1", "192.0.2.2"), "Log_kilde": "nams.csv"}
        edges, _ = aggregate_edges([row], nodes)
        self.assertIn("nams.csv", render_svg.render_svg(diagrams.site_diagram("S", nodes, edges, [], [])))

    def test_card_hover_names_documentation_and_log_sources(self):
        row = asset("192.0.2.1", Reference_kilde="inv.csv:linje 2", Log_kilde="nams.csv")
        tooltip = diagrams.node_card(build_nodes([row], [], {})[0]).tooltip
        self.assertIn("inv.csv:linje 2", tooltip)
        self.assertIn("nams.csv", tooltip)

    def test_diagram_names_input_files_with_hash(self):
        out = self.tmp / "o"
        run_cli("run_pipeline.py", "--reference", EXAMPLES / "inventory.csv", "--logs", EXAMPLES / "nams.csv", "--out", out)
        svg = (out / "diagram" / "02_site_dataflow.svg").read_text(encoding="utf-8")
        import hashlib
        for name in ("inventory.csv", "nams.csv"):
            digest = hashlib.sha256((EXAMPLES / name).read_bytes()).hexdigest()[:12]
            self.assertIn(f"{name} {digest}", svg)
        html = (out / "rapport.html").read_text(encoding="utf-8")
        self.assertIn(hashlib.sha256((EXAMPLES / "inventory.csv").read_bytes()).hexdigest(), html)

    def test_small_text_meets_contrast_on_every_background_it_uses(self):
        for name, color in (("muted", render_svg.MUTED), ("ink", render_svg.INK), ("amber", render_svg.AMBER), ("teal", render_svg.TEAL)):
            for background in ("#ffffff", render_svg.RAIL_FILL, render_svg.BAND_A, render_svg.BAND_B):
                self.assertGreaterEqual(contrast(color, background), 4.5, f"{name} on {background}")

    def test_uncertainty_is_never_conveyed_by_color_alone(self):
        states = {"solid", "dashed", "dotted", "silent"}
        for state in states:
            self.assertIn(f".s-{state}", render_svg.STYLE)
        self.assertEqual(len({re.search(rf"\.s-{s}\{{([^}}]*)\}}", render_svg.STYLE).group(1).split("stroke-dasharray:")[-1] for s in ("dashed", "dotted", "silent")}), 3)


if __name__ == "__main__":
    unittest.main()
