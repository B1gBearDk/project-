import unittest

from helpers import TempDirTest
from otvalidate.ingest import InputError, LogAggregator, load_reference
from otvalidate.reconcile import parse_scopes, reconcile
from otvalidate.zones import load_asset_map

SCOPE = "192.0.2.0/24"
HEADER = "time;src_ip;dst_ip;protocol;dst_port;src_mac\n"
T = "2026-11-04T08:00:00Z"


class Reconcile(TempDirTest):
    def run_case(self, inventory, log, scope=(SCOPE,), asset_map=None, site=None, stale_days=7):
        ref = load_reference([self.write("inv.csv", inventory)], site=site)
        logs = LogAggregator({})
        if log is not None:
            logs.add_file(self.write("log.csv", log))
        mapping = None
        if asset_map:
            mapping, _ = load_asset_map(self.write("map.csv", asset_map))
        return reconcile(ref, logs, parse_scopes(list(scope)), asset_map=mapping, stale_days=stale_days)

    def status(self, result):
        return {row["IP"]: row["Status"] for row in result.asset_rows}

    def row(self, result, ip):
        return next(row for row in result.asset_rows if row["IP"] == ip)

    def test_no_observation_is_not_observed_and_warned_as_coverage_gap(self):
        result = self.run_case("ip\n192.0.2.1\n", None)
        self.assertEqual(self.status(result), {"192.0.2.1": "DOKUMENTERET_IKKE_OBSERVERET"})
        self.assertTrue(any("Ingen" in w and "logposter" in w for w in result.warnings))

    def test_documented_source_and_destination_only(self):
        result = self.run_case("ip\n192.0.2.1\n192.0.2.2\n", HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;\n")
        self.assertEqual(self.status(result), {"192.0.2.1": "DOKUMENTERET_KILDE_OBSERVERET", "192.0.2.2": "DOKUMENTERET_KUN_DESTINATION"})
        self.assertEqual(self.row(result, "192.0.2.2")["Observation"], "KUN_DESTINATION")

    def test_unknown_in_scope_and_outside_scope(self):
        result = self.run_case("ip\n192.0.2.1\n", HEADER + f"{T};192.0.2.9;198.51.100.9;TCP;443;\n")
        statuses = self.status(result)
        self.assertEqual(statuses["192.0.2.9"], "IKKE_I_REFERENCE_IN_SCOPE")
        self.assertEqual(statuses["198.51.100.9"], "UDENFOR_SCOPE")

    def test_without_scope_undocumented_stays_undecided(self):
        result = self.run_case("ip\n192.0.2.1\n", HEADER + f"{T};192.0.2.9;192.0.2.1;TCP;443;\n", scope=())
        self.assertEqual(self.status(result)["192.0.2.9"], "IKKE_I_REFERENCE_SCOPE_UKENDT")

    def test_subnet_network_and_broadcast_are_logical_not_assets(self):
        log = HEADER + f"{T};192.0.2.1;192.0.2.255;UDP;137;\n{T};192.0.2.1;224.0.0.5;OSPF;;\n{T};192.0.2.1;255.255.255.255;UDP;67;\n{T};0.0.0.0;192.0.2.1;UDP;67;\n"
        result = self.run_case("ip\n192.0.2.1\n", log)
        statuses = self.status(result)
        for ip in ("192.0.2.255", "224.0.0.5", "255.255.255.255", "0.0.0.0"):
            self.assertEqual(statuses[ip], "LOGISK_ADRESSE", ip)
        self.assertEqual(len(result.flow_rows), 4)
        self.assertEqual([r["IP"] for r in result.review_rows if r["Status"] == "LOGISK_ADRESSE"], [])

    def test_dot_255_in_wide_scope_is_flagged_possible_broadcast(self):
        result = self.run_case("ip\n198.18.0.1\n", "src_ip;dst_ip\n198.18.0.1;198.18.5.255\n", scope=("198.18.0.0/16",))
        self.assertIn("MULIG_BROADCAST", self.row(result, "198.18.5.255")["Afvigelser"])

    def test_mac_mismatch_goes_to_review_with_top_priority(self):
        result = self.run_case("ip;mac\n192.0.2.1;00:11:22:33:44:55\n", HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;00-11-22-33-44-66\n")
        row = next(r for r in result.review_rows if r["IP"] == "192.0.2.1")
        self.assertIn("MAC_AFVIGER", row["Afvigelser"])
        self.assertEqual(row["Prioritet"], 1)

    def test_equal_mac_in_other_notation_is_no_mismatch(self):
        result = self.run_case("ip;mac\n192.0.2.1;00:11:22:33:44:55\n", HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;0011.2233.4455\n")
        self.assertEqual(self.row(result, "192.0.2.1")["Afvigelser"], "")

    def test_gateway_like_mac_shared_by_many_ips_is_not_a_mac_mismatch(self):
        inventory = "ip;mac\n" + "".join(f"192.0.2.{i};00:11:22:33:44:{i:02x}\n" for i in range(1, 5))
        log = HEADER + "".join(f"{T};192.0.2.{i};192.0.2.9;TCP;502;AA:AA:AA:AA:AA:AA\n" for i in range(1, 5))
        result = self.run_case(inventory, log)
        self.assertNotIn("MAC_AFVIGER", self.row(result, "192.0.2.1")["Afvigelser"])
        self.assertTrue(any("AA:AA:AA:AA:AA:AA" in w for w in result.warnings))

    def test_two_observed_macs_and_two_documented_names_flagged(self):
        log = HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;00:00:00:00:00:01\n{T};192.0.2.1;192.0.2.2;TCP;502;00:00:00:00:00:02\n"
        result = self.run_case("ip;device_name\n192.0.2.1;A\n192.0.2.1;B\n", log)
        flags = self.row(result, "192.0.2.1")["Afvigelser"]
        self.assertIn("FLERE_MAC", flags)
        self.assertIn("NAVN_KONFLIKT", flags)

    def test_documented_outside_scope_flagged(self):
        result = self.run_case("ip\n198.51.100.1\n", None)
        self.assertIn("DOK_UDEN_FOR_SCOPE", self.row(result, "198.51.100.1")["Afvigelser"])

    def test_same_name_on_several_ips_flagged(self):
        result = self.run_case("ip;device_name\n192.0.2.1;A\n192.0.2.2;A\n", None)
        self.assertIn("NAVN_PAA_FLERE_IP", self.row(result, "192.0.2.1")["Afvigelser"])

    def test_stale_asset_flagged_relative_to_log_end(self):
        log = HEADER + "2026-10-01T08:00:00Z;192.0.2.1;192.0.2.2;TCP;502;\n2026-11-04T08:00:00Z;192.0.2.2;192.0.2.3;TCP;502;\n"
        result = self.run_case("ip\n192.0.2.1\n192.0.2.2\n192.0.2.3\n", log)
        self.assertIn("SIDST_SET_FOER_LOGSLUT", self.row(result, "192.0.2.1")["Afvigelser"])
        self.assertNotIn("SIDST_SET_FOER_LOGSLUT", self.row(result, "192.0.2.2")["Afvigelser"])

    def test_day_gap_in_window_is_warned(self):
        log = HEADER + "2026-11-01T08:00:00Z;192.0.2.1;192.0.2.2;TCP;502;\n2026-11-04T08:00:00Z;192.0.2.1;192.0.2.2;TCP;502;\n"
        result = self.run_case("ip\n192.0.2.1\n", log)
        self.assertTrue(any("2026-11-02" in w for w in result.warnings))

    def test_timezone_free_time_is_labelled_and_not_merged_into_utc(self):
        log = HEADER + "04-11-2026 08:00:00;192.0.2.1;192.0.2.2;TCP;502;\n"
        result = self.run_case("ip\n192.0.2.1\n", log)
        self.assertIn("uden tidszone", self.row(result, "192.0.2.1")["Foerste_observation"])
        self.assertTrue(any("tidszone" in w for w in result.warnings))

    def test_verification_only_from_explicit_map_with_person_and_date(self):
        log = HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;\n"
        inventory = "ip\n192.0.2.1\n192.0.2.2\n192.0.2.3\n"
        asset_map = "IP;Zone;Verified_by;Verified_date\n192.0.2.1;Control;JL;2026-10-01\n192.0.2.2;Control;JL;\n"
        result = self.run_case(inventory, log, asset_map=asset_map)
        self.assertEqual(self.row(result, "192.0.2.1")["Verificering"], "MANUELT_VERIFICERET JL 2026-10-01")
        self.assertEqual(self.row(result, "192.0.2.2")["Verificering"], "IKKE_VERIFICERET")
        self.assertEqual(self.row(result, "192.0.2.3")["Verificering"], "IKKE_VERIFICERET")

    def test_no_row_is_verified_without_map(self):
        result = self.run_case("ip\n192.0.2.1\n", HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;\n")
        self.assertTrue(all(r["Verificering"] == "IKKE_VERIFICERET" for r in result.asset_rows))

    def test_other_site_ip_is_not_called_undocumented(self):
        inventory = "ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n"
        result = self.run_case(inventory, HEADER + f"{T};192.0.2.1;192.0.2.2;TCP;502;\n", site="Nord")
        self.assertEqual(self.status(result)["192.0.2.2"], "DOKUMENTERET_ANDET_SITE")

    def test_other_site_ip_without_traffic_is_left_out(self):
        result = self.run_case("ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n", None, site="Nord")
        self.assertEqual(list(self.status(result)), ["192.0.2.1"])

    def test_several_scopes_and_netmask_notation(self):
        scopes = parse_scopes(["192.0.2.0/255.255.255.0,198.51.100.0/24"])
        self.assertEqual([str(s) for s in scopes], ["192.0.2.0/24", "198.51.100.0/24"])

    def test_bad_or_ipv6_scope_is_input_error(self):
        for value in ("ikke-et-net", "2001:db8::/32"):
            with self.assertRaises(InputError):
                parse_scopes([value])

    def test_output_order_is_deterministic_numeric_by_ip(self):
        result = self.run_case("ip\n192.0.2.100\n192.0.2.20\n192.0.2.3\n", None)
        self.assertEqual([r["IP"] for r in result.asset_rows], ["192.0.2.3", "192.0.2.20", "192.0.2.100"])

    def test_flow_rows_carry_first_and_last_seen(self):
        log = HEADER + "2026-11-04T08:00:00Z;192.0.2.1;192.0.2.2;TCP;502;\n2026-11-04T09:00:00Z;192.0.2.1;192.0.2.2;TCP;502;\n"
        flow = self.run_case("ip\n192.0.2.1\n", log).flow_rows[0]
        self.assertEqual(flow["Antal_observationer"], 2)
        self.assertTrue(flow["Foerste_observation"].startswith("2026-11-04T08"))
        self.assertTrue(flow["Seneste_observation"].startswith("2026-11-04T09"))


if __name__ == "__main__":
    unittest.main()
