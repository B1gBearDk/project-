"""Regressions from the mutation audit: surviving mutants, drifting fixtures and confirmed defects."""
import importlib.util
import unicodedata
import unittest
from unittest import mock

from helpers import EXAMPLES, TempDirTest, read_rows
from otvalidate import diagrams
from otvalidate.ingest import InputError, LogAggregator, load_reference
from otvalidate.reconcile import ASSET_HEADERS, FIXED_LIMITS, parse_scopes, reconcile
from otvalidate.review import load_decisions
from otvalidate.zones import aggregate_edges, build_nodes, load_asset_map
from test_diagrams import asset
from test_pipeline import run_cli

PDF = EXAMPLES / "pdf"
HAS_PDF = importlib.util.find_spec("pymupdf") is not None
SCOPE = ("--scope", "192.0.2.0/24")


class Base(TempDirTest):
    def validate(self, inventory, log, site="", confirmed=False, scope=("192.0.2.0/24",)):
        ref = load_reference([self.write("inv.csv", inventory)], site=site)
        logs = LogAggregator({}, site=site, site_confirmed=confirmed)
        logs.add_file(self.write("log.csv", log))
        return reconcile(ref, logs, parse_scopes(list(scope)))

    def row(self, result, ip):
        return next(r for r in result.asset_rows if r["IP"] == ip)


class SurvivingMutants(Base):
    def test_validator_cli_also_exits_3_on_blockers(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n")
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        result = run_cli("src/ot_asset_validator.py", "--reference", inv, "--logs", log, "--out", self.tmp / "o")
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)

    def test_txt_near_miss_blocks(self):
        ref = load_reference([self.write("a.txt", "PLC 192.0.2.1\nHMI 192,0,2,41\n")])
        self.assertTrue(any("192,0,2,41" in b for b in ref.blockers), ref.blockers)

    @unittest.skipUnless(HAS_PDF, "PyMuPDF mangler")
    def test_pdf_contributing_nothing_is_warned(self):
        pdf = self.tmp / "tom_tekst.pdf"
        pdf.write_bytes((PDF / "roteret.pdf").read_bytes().replace(b"192.0.2.74", b"ingen adr.."))
        ref = load_reference([self.write("i.csv", "ip\n192.0.2.1\n"), pdf])
        self.assertTrue(any("Ingen IPv4" in w and "tom_tekst.pdf" in w for w in ref.warnings), ref.warnings)

    def test_real_deviations_reach_cards_and_catalog(self):
        result = self.validate("ip;mac\n192.0.2.1;00:00:00:00:00:01\n", "src_ip;dst_ip;src_mac\n192.0.2.1;192.0.2.2;00:00:00:00:00:02\n")
        node = next(n for n in build_nodes(result.asset_rows, result.flow_rows, {}) if n.ip == "192.0.2.1")
        self.assertEqual(node.deviations, ["MAC_AFVIGER"])
        self.assertIn("MAC afviger", diagrams.node_card(node).deviation)

    def test_unique_name_is_not_flagged_as_name_on_several_ips(self):
        result = self.validate("ip;device_name\n192.0.2.1;A\n192.0.2.2;B\n", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        self.assertEqual(self.row(result, "192.0.2.1")["Afvigelser"], "")

    def test_malformed_reference_site_is_refused_by_cli(self):
        inv = self.write("i.csv", "ip\n192.0.2.1\n")
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        for value in ("i.csv", "=Nord", "i.csv="):
            result = run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--reference-site", value, "--out", self.tmp / "o")
            self.assertEqual(result.returncode, 2, value)

    def test_source_and_destination_observation_is_named_and_shown(self):
        result = self.validate("ip\n192.0.2.1\n192.0.2.2\n", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n192.0.2.2;192.0.2.1\n")
        self.assertEqual(self.row(result, "192.0.2.1")["Observation"], "KILDE_OG_DESTINATION")
        node = next(n for n in build_nodes(result.asset_rows, [], {}) if n.ip == "192.0.2.1")
        self.assertIn("kilde og destination", diagrams.node_card(node).evidence)

    def test_flow_reference_columns_are_not_inverted(self):
        flow = self.validate("ip\n192.0.2.1\n", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n").flow_rows[0]
        self.assertEqual((flow["Kilde_i_reference"], flow["Destination_i_reference"]), ("JA", "NEJ"))

    def test_priorities_have_their_documented_values(self):
        result = self.validate("ip;site\n192.0.2.1;Nord\n192.0.2.2;Nord\n", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n", scope=())
        self.assertEqual(self.row(result, "192.0.2.2")["Prioritet"], 2)
        scope_less = self.validate("ip\n192.0.2.1\n", "src_ip;dst_ip\n192.0.2.9;192.0.2.1\n", scope=())
        self.assertEqual(self.row(scope_less, "192.0.2.9")["Prioritet"], 3)

    def test_fixed_limits_always_reach_the_report(self):
        result = self.validate("ip\n192.0.2.1\n", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        for line in FIXED_LIMITS:
            self.assertIn(line, result.warnings)

    def test_overlap_warning_names_both_files_and_only_real_overlaps(self):
        logs = LogAggregator({})
        logs.add_file(self.write("a.csv", "time;src_ip;dst_ip\n2026-11-04T08:00:00Z;192.0.2.1;192.0.2.2\n"))
        self.assertFalse(any("overlapper" in w for w in logs.warnings), "a file must not overlap itself")
        logs.add_file(self.write("b.csv", "time;src_ip;dst_ip\n2026-11-05T08:00:00Z;192.0.2.3;192.0.2.2\n"))
        self.assertFalse(any("overlapper" in w for w in logs.warnings))
        logs.add_file(self.write("c.csv", "time;src_ip;dst_ip\n2026-11-04T08:00:00Z;192.0.2.4;192.0.2.2\n"))
        self.assertTrue(any("c.csv og a.csv" in w for w in logs.warnings), logs.warnings)

    def test_ipv6_warning_reaches_the_user(self):
        logs = LogAggregator({})
        logs.add_file(self.write("a.csv", "src_ip;dst_ip\n2001:db8::1;192.0.2.2\n"))
        self.assertTrue(any("IPv6" in w for w in logs.warnings))

    def test_windows_reserved_names_are_not_used_as_folders(self):
        for name in ("CON", "prn", "AUX", "NUL", "COM1", "lpt9"):
            self.assertNotEqual(diagrams.safe_name(name).upper(), name.upper())

    def test_failing_graphviz_process_gives_message_and_no_partial_png(self):
        import subprocess
        png = self.write("a.png", "halvfaerdig")
        with mock.patch("otvalidate.diagrams.shutil.which", return_value=str(self.tmp / "tools" / "dot")), \
                mock.patch("otvalidate.diagrams.subprocess.run", side_effect=subprocess.CalledProcessError(1, "dot")):
            ok, message = diagrams.render_png(self.write("a.dot", "digraph{}"), png)
        self.assertFalse(ok)
        self.assertFalse(png.exists())
        self.assertIn("Graphviz", message)


class FixtureDrift(Base):
    """A hand-built row can drift from the real columns, so the same behaviour is also driven by real rows."""

    def test_hand_built_row_only_uses_real_columns(self):
        self.assertLessEqual(set(asset("192.0.2.1")), set(ASSET_HEADERS))

    def test_real_rows_carry_every_field_the_diagram_reads(self):
        inventory = "ip;device_name;mac\n192.0.2.1;PLC-1;00:00:00:00:00:01\n"
        result = self.validate(inventory, "src_ip;dst_ip;hostname;src_mac\n192.0.2.1;224.0.0.5;obs-navn;00:00:00:00:00:01\n192.0.2.9;192.0.2.1;andet;\n")
        nodes = {n.ip: n for n in build_nodes(result.asset_rows, result.flow_rows, {})}
        self.assertEqual(nodes["224.0.0.5"].address_type, "multicast")
        self.assertEqual(nodes["192.0.2.9"].label, "andet")
        self.assertEqual(nodes["192.0.2.1"].doc_kind, "STRUKTURERET")
        self.assertEqual(nodes["192.0.2.1"].in_scope, "JA")
        self.assertEqual(nodes["192.0.2.1"].mac, "00:00:00:00:00:01")
        self.assertIn("inv.csv:linje 2", nodes["192.0.2.1"].doc_source)
        self.assertIn("log.csv", nodes["192.0.2.1"].log_source)

    def test_real_other_site_and_unresolved_rows_are_not_drawn_as_documented(self):
        inventory = "ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n192.0.2.3;\n"
        result = self.validate(inventory, "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n", site="Nord")
        nodes = {n.ip: n for n in build_nodes(result.asset_rows, result.flow_rows, {})}
        self.assertFalse(nodes["192.0.2.2"].documented)
        self.assertFalse(nodes["192.0.2.3"].documented)
        self.assertTrue(nodes["192.0.2.1"].documented)


class SiteMixing(Base):
    def test_log_with_foreign_site_rows_blocks_without_site_choice(self):
        result = self.validate("ip;site\n192.0.2.1;Nord\n", "site;src_ip;dst_ip\nNord;192.0.2.1;192.0.2.2\nSyd;192.0.2.1;192.0.2.2\n")
        self.assertTrue(any("Syd" in b for b in result.blockers), result.blockers)

    def test_asset_map_row_for_foreign_site_is_not_used_without_site_choice(self):
        path = self.write("m.csv", "Site;IP;Zone;Verified_by;Verified_date\nSyd;192.0.2.1;Field;JL;2026-10-12\n")
        mapping, warnings = load_asset_map(path, known_sites={"Nord"})
        self.assertEqual(mapping, {})
        self.assertTrue(any("Syd" in w for w in warnings))

    def test_diagram_cli_applies_the_same_map_rule_from_the_asset_table(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n")
        val = self.tmp / "v"
        run_cli("src/ot_asset_validator.py", "--reference", inv, "--logs", self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n"), "--out", val)
        path = self.write("m.csv", "Site;IP;Zone;Verified_by;Verified_date\nSyd;192.0.2.1;Field;JL;2026-10-12\n")
        result = run_cli("src/ot_dataflow_diagram.py", "--assets", val / "01_alle_ip_adresser.csv", "--flows", val / "03_kommunikationsflows.csv", "--asset-map", path, "--out", self.tmp / "d")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn("Verificeret JL", (self.tmp / "d" / "02_site_dataflow.svg").read_text(encoding="utf-8").split("Tegnforklaring")[0])

    def test_reference_site_cannot_collapse_two_files_with_the_same_name(self):
        a, b = self.write("a/list.txt", "192.0.2.1\n"), self.write("b/list.txt", "192.0.2.2\n")
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        result = run_cli("run_pipeline.py", "--reference", a, b, "--logs", log, "--reference-site", f"{a}=Nord", "--reference-site", f"{b}=Syd", "--site", "Nord", "--out", self.tmp / "o")
        self.assertEqual(result.returncode, 2, result.stdout)
        self.assertIn("list.txt", result.stderr)

    def test_reference_site_with_wrong_folder_is_refused(self):
        a = self.write("a/list.txt", "192.0.2.1\n")
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        result = run_cli("run_pipeline.py", "--reference", a, "--logs", log, "--reference-site", f"{self.tmp / 'b' / 'list.txt'}=Nord", "--out", self.tmp / "o")
        self.assertEqual(result.returncode, 2)

    def test_row_site_conflicting_with_assigned_file_site_blocks(self):
        ref = load_reference([self.write("a.csv", "ip;site\n192.0.2.1;Syd\n")], site="Nord", file_sites={"a.csv": "Nord"})
        self.assertTrue(any("a.csv" in b and "Syd" in b for b in ref.blockers), ref.blockers)

    def test_all_sites_merges_spelling_variants_into_one_folder(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;NORD\n192.0.2.3;nord\n")
        log = self.write("l.csv", "site;src_ip;dst_ip\nNord;192.0.2.1;192.0.2.2\n")
        out = self.tmp / "o"
        self.assertIn(run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--all-sites", "--out", out).returncode, (0, 3))
        self.assertEqual(len(list(out.iterdir())), 1)

    def test_case_variant_of_one_site_is_not_two_sites(self):
        result = self.validate("ip;site\n192.0.2.1;Nord\n192.0.2.1;NORD\n", "site;src_ip;dst_ip\nNord;192.0.2.1;192.0.2.2\n", site="Nord")
        self.assertNotIn("IP_PAA_FLERE_SITES", self.row(result, "192.0.2.1")["Afvigelser"])

    def test_whitespace_nbsp_and_unicode_forms_match_the_same_site(self):
        nfd = unicodedata.normalize("NFD", "Åby")
        for variant, wanted in (("Vand  Nord", "Vand Nord"), ("Vand Nord", "Vand Nord"), (nfd, "Åby")):
            result = self.validate(f"ip;site\n192.0.2.1;{wanted}\n", f"site;src_ip;dst_ip\n{variant};192.0.2.1;192.0.2.2\n", site=wanted)
            self.assertEqual(self.row(result, "192.0.2.1")["Antal_som_kilde"], 1, repr(variant))

    def test_blank_site_rows_block_when_other_rows_have_a_site(self):
        ref = load_reference([self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;\n")])
        self.assertTrue(any("192.0.2.2" in b for b in ref.blockers), ref.blockers)

    def test_unassigned_txt_blocks_when_csv_has_sites(self):
        ref = load_reference([self.write("i.csv", "ip;site\n192.0.2.1;Nord\n"), self.write("b.txt", "192.0.2.9\n")])
        self.assertTrue(any("192.0.2.9" in b for b in ref.blockers), ref.blockers)

    def test_reference_without_any_site_is_still_a_plain_single_run(self):
        self.assertEqual(load_reference([self.write("i.csv", "ip\n192.0.2.1\n")]).blockers, [])

    def test_flow_from_rows_without_site_is_marked_and_drawn_differently(self):
        result = self.validate("ip;site\n192.0.2.1;Nord\n192.0.2.2;Nord\n", "site;src_ip;dst_ip\nNord;192.0.2.1;192.0.2.2\n;192.0.2.2;192.0.2.1\n", site="Nord")
        flows = {(f["Kilde_IP"], f["Destination_IP"]): f for f in result.flow_rows}
        self.assertEqual(flows[("192.0.2.1", "192.0.2.2")]["Antal_uden_site"], 0)
        self.assertEqual(flows[("192.0.2.2", "192.0.2.1")]["Antal_uden_site"], 1)
        nodes = build_nodes(result.asset_rows, result.flow_rows, {})
        edges = {(e.src, e.dst): e for e in aggregate_edges(result.flow_rows, nodes)[0]}
        self.assertFalse(edges[("192.0.2.1", "192.0.2.2")].dashed)
        self.assertTrue(edges[("192.0.2.2", "192.0.2.1")].dashed)
        self.assertIn("uden site", diagrams._edge_title(edges[("192.0.2.2", "192.0.2.1")]))

    def test_asset_seen_only_in_rows_without_site_is_flagged(self):
        result = self.validate("ip;site\n192.0.2.1;Nord\n192.0.2.2;Nord\n", "site;src_ip;dst_ip\n;192.0.2.1;192.0.2.2\n", site="Nord")
        self.assertIn("KUN_OBS_UDEN_SITE", self.row(result, "192.0.2.1")["Afvigelser"])

    def test_confirmed_log_is_not_flagged_as_without_site(self):
        result = self.validate("ip;site\n192.0.2.1;Nord\n", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n", site="Nord", confirmed=True)
        self.assertEqual(self.row(result, "192.0.2.1")["Afvigelser"], "")
        self.assertEqual(result.flow_rows[0]["Antal_uden_site"], 0)


class DiagramCliBlockers(Base):
    def test_blockers_from_the_validation_folder_reach_diagram_and_exit_code(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n")
        val = self.tmp / "v"
        self.assertEqual(run_cli("src/ot_asset_validator.py", "--reference", inv, "--logs", self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n"), "--out", val).returncode, 3)
        result = run_cli("src/ot_dataflow_diagram.py", "--assets", val / "01_alle_ip_adresser.csv", "--flows", val / "03_kommunikationsflows.csv", "--out", self.tmp / "d")
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("ufuldstændigt", (self.tmp / "d" / "02_site_dataflow.svg").read_text(encoding="utf-8"))


class CsvReferenceGaps(Base):
    def test_unreadable_ip_cells_block_with_line_numbers(self):
        ref = load_reference([self.write("i.csv", "ip;device_name\n192 . 0 . 2 . 40;A\n192,0,2,41;B\n192.0.2.6O;C\nukendt;D\n192.0.2.300;E\n192.0.2.1;OK\n")])
        self.assertEqual(list(ref.known), ["192.0.2.1"])
        text = " ".join(ref.blockers)
        for fragment in ("192 . 0 . 2 . 40", "192,0,2,41", "192.0.2.6O", "ukendt", "192.0.2.300", "linje 2"):
            self.assertIn(fragment, text)

    def test_blank_ip_cell_on_a_named_row_is_warned_not_dropped_quietly(self):
        ref = load_reference([self.write("i.csv", "ip;device_name\n;Enhed-uden-IP\n192.0.2.1;OK\n")])
        self.assertTrue(any("Enhed-uden-IP" in w or "linje 2" in w for w in ref.warnings), ref.warnings)


@unittest.skipUnless(HAS_PDF, "PyMuPDF mangler")
class PdfImagesAndDrawings(Base):
    def test_small_image_on_a_text_page_is_reported_not_called_ok(self):
        ref = load_reference([PDF / "blandet_scan.pdf"])
        self.assertEqual(ref.pdf_pages[3].verdict, "LILLE_BILLEDE")
        self.assertTrue(any("side 4" in w for w in ref.warnings), ref.warnings)
        self.assertFalse(any("side 4" in b for b in ref.blockers))

    def test_image_share_threshold_is_at_a_quarter_of_the_page(self):
        with mock.patch("otvalidate.ingest.PDF_IMAGE_SHARE_BLOCKS", 0.9):
            self.assertEqual(load_reference([PDF / "blandet_scan.pdf"]).pdf_pages[2].verdict, "LILLE_BILLEDE")
        self.assertEqual(load_reference([PDF / "billede_30pct.pdf"]).pdf_pages[0].verdict, "BILLEDE_MED_TEKST")

    def test_drawings_on_a_text_page_are_counted(self):
        self.assertGreater(load_reference([PDF / "tekst_og_streger.pdf"]).pdf_pages[0].drawings, 10)


class ReviewIntegrity(Base):
    INVENTORY = "ip;device_name\n192.0.2.1;PLC-1\n192.0.2.2;HMI-1\n"
    LOGS = "src_ip;dst_ip;hostname\n192.0.2.1;192.0.2.2;plc-1\n192.0.2.2;192.0.2.1;hmi-1\n"

    def pipeline(self, inv, log, *extra, out="o"):
        output = self.tmp / out
        result = run_cli("run_pipeline.py", "--reference", inv, "--logs", log, *SCOPE, "--out", output, *extra)
        self.assertIn(result.returncode, (0, 3), result.stderr)
        return output

    def table(self, out):
        return read_rows(out / "validation" / "01_alle_ip_adresser.csv")

    def decide(self, *rows):
        return self.write("beslutninger.csv", "Site;IP;Evidens_ID;Beslutning;Beslutter;Dato;Begrundelse\n" + "\n".join(";".join(r) for r in rows) + "\n")

    def test_stale_decision_leaves_the_full_table_evidence_untouched_and_goes_first_in_queue(self):
        inv, log = self.write("i.csv", self.INVENTORY), self.write("l.csv", self.LOGS)
        first = self.pipeline(inv, log)
        path = self.decide(("", "192.0.2.1", "0000000000000000", "GODKENDT", "JL", "2026-11-05", "Gammel"))
        second = self.pipeline(inv, log, "--review-file", path, out="o2")
        review = {"Review_status", "Review_af", "Review_dato", "Review_begrundelse"}
        strip = lambda rows: [{k: v for k, v in r.items() if k not in review} for r in rows]
        self.assertEqual(strip(self.table(first)), strip(self.table(second)))
        queue = read_rows(second / "validation" / "02_til_gennemgang.csv")
        self.assertEqual(queue[0]["IP"], "192.0.2.1")
        self.assertEqual(queue[0]["Review_status"], "FORAELDET")

    def test_changed_hostname_or_documentation_kind_reopens_a_decision(self):
        inv, log = self.write("i.csv", self.INVENTORY), self.write("l.csv", self.LOGS)
        evidence = next(r for r in self.table(self.pipeline(inv, log)) if r["IP"] == "192.0.2.1")["Evidens_ID"]
        path = self.decide(("", "192.0.2.1", evidence, "GODKENDT", "JL", "2026-11-05", "OK"))
        log.write_text(self.LOGS.replace("plc-1", "RTU-UKENDT"), encoding="utf-8")
        changed = next(r for r in self.table(self.pipeline(inv, log, "--review-file", path, out="o2")) if r["IP"] == "192.0.2.1")
        self.assertEqual(changed["Review_status"], "FORAELDET")

    def test_typo_in_decision_site_is_reported(self):
        _, warnings = load_decisions(self.decide(("Vest", "192.0.2.1", "x", "AFVIST", "JL", "2026-11-05", "Y")), site="Nord", multi_site=True, known_sites={"Nord", "Syd"})
        self.assertTrue(any("Vest" in w for w in warnings), warnings)

    def test_decision_for_a_known_other_site_is_skipped_quietly(self):
        decisions, warnings = load_decisions(self.decide(("Syd", "192.0.2.1", "x", "AFVIST", "JL", "2026-11-05", "Y")), site="Nord", multi_site=True, known_sites={"Nord", "Syd"})
        self.assertEqual((decisions, warnings), ([], []))

    def test_misnamed_column_in_review_file_is_an_error_naming_it(self):
        path = self.write("r.csv", "IP;Evidens_ID;Afgoerelse;Beslutter;Dato;Begrundelse\n192.0.2.1;x;AFVIST;JL;2026-11-05;Y\n")
        with self.assertRaisesRegex(InputError, "Beslutning"):
            load_decisions(path)

    def test_review_file_inside_output_folder_is_refused_before_anything_is_written(self):
        inv, log = self.write("i.csv", self.INVENTORY), self.write("l.csv", self.LOGS)
        out = self.tmp / "o"
        path = self.write("o/beslutninger.csv", "Site;IP;Evidens_ID;Beslutning;Beslutter;Dato;Begrundelse\n")
        result = run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--review-file", path, "--out", out)
        self.assertEqual(result.returncode, 2)
        self.assertIn("outputmappen", result.stderr)
        self.assertEqual([p.name for p in out.iterdir()], ["beslutninger.csv"])


class LegendExplainsReview(unittest.TestCase):
    def test_legend_says_review_is_not_verification(self):
        from otvalidate.render_svg import Diagram, Band, Card, render_svg
        svg = render_svg(Diagram("T", "", [], [], [Band("A", "", [Card("a", "A", "1", "", "")])], []))
        self.assertIn("Review: en persons vurdering, ikke fysisk verificering", svg)


if __name__ == "__main__":
    unittest.main()
