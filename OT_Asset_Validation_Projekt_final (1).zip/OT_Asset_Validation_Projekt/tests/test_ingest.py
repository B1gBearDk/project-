import json
import sys
import unittest
from unittest import mock

from helpers import TempDirTest
from otvalidate.ingest import (InputError, LogAggregator, clean_text, detect_fields, extract_ips,
                               load_reference, normalize_mac, parse_time, read_records)


class ExtractIps(unittest.TestCase):
    def test_finds_ip_with_port_and_at_sentence_end(self):
        self.assertEqual(extract_ips("til 192.0.2.10:502 og 192.0.2.11.").valid, ["192.0.2.10", "192.0.2.11"])

    def test_reports_invalid_octets_and_leading_zeros(self):
        found = extract_ips("192.0.2.300 192.168.001.010")
        self.assertEqual(found.valid, [])
        self.assertEqual(found.invalid, ["192.0.2.300", "192.168.001.010"])

    def test_cidr_declaration_is_not_a_host_when_requested(self):
        self.assertEqual(extract_ips("net 192.0.2.0/24", skip_cidr=True).valid, [])
        self.assertEqual(extract_ips("net 192.0.2.0/24").valid, ["192.0.2.0"])

    def test_netmask_is_not_a_host_when_requested(self):
        self.assertEqual(extract_ips("maske 255.255.255.0", skip_netmasks=True).valid, [])

    def test_four_part_version_inside_longer_dotted_string_ignored(self):
        self.assertEqual(extract_ips("1.2.3.4.5").valid, [])


class ParseTime(unittest.TestCase):
    def test_offset_is_converted_to_utc(self):
        self.assertEqual(parse_time("2026-11-04T08:00:00+01:00"), ("2026-11-04T07:00:00+00:00", "UTC"))

    def test_compact_offset_and_z_and_fraction(self):
        self.assertEqual(parse_time("2026-11-04T08:00:00.123456789+0100")[1], "UTC")
        self.assertEqual(parse_time("2026-11-04T08:00:00Z"), ("2026-11-04T08:00:00+00:00", "UTC"))

    def test_naive_time_is_never_assumed_utc(self):
        self.assertEqual(parse_time("04-11-2026 08:00:00"), ("2026-11-04T08:00:00", "NO_TZ"))

    def test_epoch_seconds_and_millis(self):
        self.assertEqual(parse_time("1793779200")[1], "UTC")
        self.assertEqual(parse_time("1793779200000"), parse_time("1793779200"))

    def test_garbage_returns_none(self):
        self.assertIsNone(parse_time("igår ved middagstid"))
        self.assertIsNone(parse_time("2026-13-45T99:00:00"))


class DetectFields(unittest.TestCase):
    def test_specific_alias_beats_generic_source_column(self):
        fields = detect_fields(("source", "source_ip", "destination", "destination_ip"), {})
        self.assertEqual((fields["src"], fields["dst"]), ("source_ip", "destination_ip"))

    def test_nested_prefix_is_accepted(self):
        self.assertEqual(detect_fields(("event.source.ip",), {})["src"], "event.source.ip")

    def test_explicit_override_wins(self):
        self.assertEqual(detect_fields(("a", "src_ip"), {"src": "A"})["src"], "a")


class Normalization(unittest.TestCase):
    def test_mac_formats_converge(self):
        expected = "00:11:22:AA:BB:CC"
        for value in ("00:11:22:aa:bb:cc", "00-11-22-AA-BB-CC", "0011.22aa.bbcc", "001122AABBCC"):
            self.assertEqual(normalize_mac(value), expected)
        self.assertIsNone(normalize_mac("ikke en mac"))

    def test_clean_text_strips_controls_and_bidi_and_limits_length(self):
        self.assertEqual(clean_text("a\x00b‮c\nd"), "abc d")
        self.assertEqual(len(clean_text("x" * 500, 40)), 40)


class Records(TempDirTest):
    def rows(self, path, bad=None):
        return [record for _, record in read_records(path, (lambda location, reason: bad.append(location)) if bad is not None else (lambda *_: None))]

    def test_semicolon_quoted_csv_keeps_delimiter_inside_quotes(self):
        path = self.write("a.csv", 'src_ip;note\n192.0.2.1;"a;b ""c"""\n')
        self.assertEqual(self.rows(path)[0]["note"], 'a;b "c"')

    def test_comma_tab_and_pipe_delimiters(self):
        for delimiter in ",\t|":
            path = self.write("d.csv", f"src_ip{delimiter}dst_ip\n192.0.2.1{delimiter}192.0.2.2\n")
            self.assertEqual(self.rows(path)[0]["dst_ip"], "192.0.2.2")

    def test_cp1252_danish_excel_csv(self):
        path = self.write("c.csv", "ip;anlæg\n192.0.2.1;Vandværk\n", encoding="cp1252")
        self.assertEqual(self.rows(path)[0]["anlæg"], "Vandværk")

    def test_utf16_powershell_export(self):
        path = self.write("u.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n", encoding="utf-16")
        self.assertEqual(self.rows(path)[0]["src_ip"], "192.0.2.1")

    def test_oversized_field_does_not_crash(self):
        path = self.write("big.csv", "src_ip;msg\n192.0.2.1;" + "x" * 300_000 + "\n")
        self.assertEqual(self.rows(path)[0]["src_ip"], "192.0.2.1")

    def test_row_with_extra_columns_keeps_named_fields(self):
        path = self.write("x.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2;ekstra;mere\n")
        self.assertEqual(self.rows(path)[0]["dst_ip"], "192.0.2.2")

    def test_jsonl_bad_lines_are_counted_not_fatal(self):
        path = self.write("a.jsonl", '{"src_ip":"192.0.2.1"}\n{ikke json\n[1,2]\n{"src_ip":"192.0.2.2"}\n')
        bad = []
        self.assertEqual([r["src_ip"] for r in self.rows(path, bad)], ["192.0.2.1", "192.0.2.2"])
        self.assertEqual(len(bad), 2)

    def test_deeply_nested_json_is_a_bad_record_not_a_crash(self):
        path = self.write("deep.jsonl", '{"a":' * 5000 + "1" + "}" * 5000 + "\n")
        bad = []
        self.assertEqual(self.rows(path, bad), [])
        self.assertEqual(len(bad), 1)

    def test_json_wrapper_object_and_nested_fields(self):
        path = self.write("a.json", json.dumps({"events": [{"source": {"ip": "192.0.2.1"}}]}))
        self.assertEqual(self.rows(path)[0]["source.ip"], "192.0.2.1")

    def test_broken_json_file_is_input_error(self):
        path = self.write("a.json", "{ikke json")
        with self.assertRaises(InputError):
            self.rows(path)

    def test_key_value_syslog_gets_fields(self):
        path = self.write("a.log", 'Nov 4 08:00:00 nams src=192.0.2.1 dst=192.0.2.2 proto=TCP dpt=502 msg="a b"\n')
        record = self.rows(path)[0]
        self.assertEqual((record["src"], record["dpt"], record["msg"]), ("192.0.2.1", "502", "a b"))

    def test_arrow_syslog_gets_direction_and_iso_time(self):
        path = self.write("a.log", "2026-11-04T08:00:00Z fw TCP 192.0.2.1:49152 -> 192.0.2.2:502\n")
        record = self.rows(path)[0]
        self.assertEqual((record["src_ip"], record["dst_ip"], record["dst_port"]), ("192.0.2.1", "192.0.2.2", "502"))
        self.assertEqual(record["timestamp"], "2026-11-04T08:00:00Z")

    def test_unknown_suffix_is_input_error(self):
        with self.assertRaises(InputError):
            self.rows(self.write("a.xlsx", "x"))


class Aggregator(TempDirTest):
    def aggregate(self, *paths, **overrides):
        logs = LogAggregator(overrides)
        for path in paths:
            logs.add_file(path)
        return logs

    def test_duplicate_observations_are_counted_as_events(self):
        logs = self.aggregate(self.write("a.csv", "src_ip;dst_ip;protocol;dst_port\n192.0.2.1;192.0.2.2;TCP;502\n192.0.2.1;192.0.2.2;TCP;502\n"))
        self.assertEqual(logs.flows[("192.0.2.1", "192.0.2.2", "TCP", "502")].count, 2)

    def test_identical_file_given_twice_is_skipped_with_warning(self):
        path = self.write("a.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        logs = self.aggregate(path, self.write("kopi.csv", path.read_text()))
        self.assertEqual(logs.stats["192.0.2.1"].src, 1)
        self.assertTrue(any("kopi.csv" in w and "identisk" in w for w in logs.warnings))

    def test_protocol_case_iana_number_and_excel_port_float_merge(self):
        logs = self.aggregate(self.write("a.csv", "src_ip;dst_ip;protocol;dst_port\n192.0.2.1;192.0.2.2;TCP;502\n192.0.2.1;192.0.2.2;tcp;502.0\n192.0.2.1;192.0.2.2;6;502\n"))
        self.assertEqual(list(logs.flows), [("192.0.2.1", "192.0.2.2", "TCP", "502")])

    def test_invalid_port_is_dropped_and_counted(self):
        logs = self.aggregate(self.write("a.csv", "src_ip;dst_ip;dst_port\n192.0.2.1;192.0.2.2;=cmd\n192.0.2.1;192.0.2.2;70000\n"))
        self.assertEqual(list(logs.flows), [("192.0.2.1", "192.0.2.2", "", "")])
        self.assertEqual(logs.files[0].bad_ports, 2)

    def test_schema_change_after_first_jsonl_row_is_handled(self):
        path = self.write("a.jsonl", '{"event":"start"}\n{"src_ip":"192.0.2.1","dst_ip":"192.0.2.2"}\n')
        self.assertEqual(self.aggregate(path).stats["192.0.2.1"].src, 1)

    def test_missing_explicit_field_is_input_error(self):
        path = self.write("a.csv", "a;b\n192.0.2.1;192.0.2.2\n")
        with self.assertRaisesRegex(InputError, "findes_ikke"):
            self.aggregate(path, src="findes_ikke")

    def test_structured_file_without_ip_fields_is_input_error_listing_columns(self):
        path = self.write("a.csv", "foo;bar\n1;2\n")
        with self.assertRaisesRegex(InputError, "foo"):
            self.aggregate(path)

    def test_empty_log_warns_but_is_not_an_error(self):
        logs = self.aggregate(self.write("tom.csv", ""))
        self.assertEqual(logs.total_rows, 0)
        self.assertTrue(any("tom.csv" in w and "tom" in w for w in logs.warnings))

    def test_source_without_destination_column_warns_about_missing_direction(self):
        logs = self.aggregate(self.write("a.csv", "src_ip;x\n192.0.2.1;1\n"))
        self.assertEqual(logs.stats["192.0.2.1"].src, 1)
        self.assertTrue(any("destination" in w.lower() for w in logs.warnings))

    def test_unparseable_ip_values_ipv6_and_timestamps_are_reported(self):
        logs = self.aggregate(self.write("a.csv", "src_ip;dst_ip;time\n2001:db8::1;192.0.2.2;nonsens\nhost-a;192.0.2.300;2026-11-04T08:00:00Z\n"))
        info = logs.files[0]
        self.assertEqual(info.ipv6_values, 1)
        self.assertEqual(info.invalid_ip_values, 2)
        self.assertEqual((info.ts_bad, info.ts_ok), (1, 1))

    def test_message_column_mentions_without_inventing_direction(self):
        logs = self.aggregate(self.write("a.log", "forbindelse set mellem 192.0.2.1 og 192.0.2.2\n"))
        self.assertEqual(logs.stats["192.0.2.1"].mentioned, 1)
        self.assertEqual(logs.flows, {})

    def test_overlapping_file_windows_warn_about_double_counting(self):
        one = self.write("a.csv", "src_ip;dst_ip;time\n192.0.2.1;192.0.2.2;2026-11-04T08:00:00Z\n192.0.2.1;192.0.2.2;2026-11-04T10:00:00Z\n")
        two = self.write("b.csv", "src_ip;dst_ip;time\n192.0.2.3;192.0.2.2;2026-11-04T09:00:00Z\n")
        self.assertTrue(any("overlapper" in w for w in self.aggregate(one, two).warnings))


class Reference(TempDirTest):
    def test_invalid_ips_are_collected_with_location(self):
        ref = load_reference([self.write("i.csv", "ip;device_name\n192.0.2.300;X\n192.0.2.1;OK\n")])
        self.assertEqual(list(ref.known), ["192.0.2.1"])
        self.assertTrue(any("192.0.2.300" in b and "linje 2" in b for b in ref.blockers))

    def test_cell_with_two_ips_gives_two_documented_addresses(self):
        ref = load_reference([self.write("i.csv", "ip;device_name\n\"192.0.2.1, 192.0.2.2\";DUAL\n")])
        self.assertEqual(sorted(ref.known), ["192.0.2.1", "192.0.2.2"])

    def test_cidr_in_ip_column_is_warned_not_an_asset(self):
        ref = load_reference([self.write("i.csv", "ip\n192.0.2.0/24\n192.0.2.5\n")])
        self.assertEqual(list(ref.known), ["192.0.2.5"])
        self.assertTrue(any("192.0.2.0/24" in w for w in ref.warnings))

    def test_txt_is_candidate_and_csv_is_structured(self):
        ref = load_reference([self.write("a.txt", "PLC 192.0.2.1\n"), self.write("b.csv", "ip\n192.0.2.2\n")])
        self.assertEqual(ref.known["192.0.2.1"].kinds, {"KANDIDAT"})
        self.assertEqual(ref.known["192.0.2.2"].kinds, {"STRUKTURERET"})

    def test_missing_ip_column_is_input_error(self):
        with self.assertRaisesRegex(InputError, "IP-kolonne"):
            load_reference([self.write("i.csv", "navn\nx\n")])

    def test_no_addresses_is_input_error(self):
        with self.assertRaises(InputError):
            load_reference([self.write("i.txt", "ingen adresser\n")])

    def test_site_filter_separates_other_sites(self):
        path = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n192.0.2.3;\n")
        ref = load_reference([path], site="nord")
        self.assertEqual(sorted(ref.known), ["192.0.2.1"])
        self.assertEqual(list(ref.unresolved), ["192.0.2.3"])
        self.assertEqual(ref.other_site, {"192.0.2.2": {"Syd"}})
        self.assertEqual(ref.sites, {"Nord", "Syd"})

    def test_unknown_site_is_input_error_listing_sites(self):
        path = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n")
        with self.assertRaisesRegex(InputError, "Nord"):
            load_reference([path], site="Findes ikke")

    def test_missing_pymupdf_is_clear_input_error(self):
        with mock.patch.dict(sys.modules, {"pymupdf": None}):
            with self.assertRaisesRegex(InputError, "(?i)pymupdf"):
                load_reference([self.write("a.pdf", "x")])


if __name__ == "__main__":
    unittest.main()
