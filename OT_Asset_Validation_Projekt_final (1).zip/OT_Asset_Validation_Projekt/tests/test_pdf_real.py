"""Real PDF files through real PyMuPDF. No fakes: a mocked reader hid several defects earlier.

Without PyMuPDF these tests skip, and a skip means PDF support is unverified. Set OTV_REQUIRE_PDF=1
to turn the skip into a failure, as the release check does.
"""
import importlib.util
import os
import shutil
import subprocess
import unittest

from helpers import EXAMPLES, TempDirTest, read_rows
from otvalidate.ingest import InputError, extract_ips, load_reference, near_miss_ips
from test_pipeline import run_cli

PDF = EXAMPLES / "pdf"
HAS_PDF = importlib.util.find_spec("pymupdf") is not None
if not HAS_PDF and os.environ.get("OTV_REQUIRE_PDF") == "1":
    raise RuntimeError("OTV_REQUIRE_PDF=1, men PyMuPDF kan ikke importeres.")


def load(name, **kwargs):
    return load_reference([PDF / name], **kwargs)


class NearMiss(unittest.TestCase):
    """These run without PyMuPDF: they concern text, not PDF parsing."""

    def test_letter_directly_after_address_is_not_accepted_as_address(self):
        self.assertEqual(extract_ips("192.0.2.6O").valid, [])
        self.assertEqual(extract_ips("192.0.2.10:502").valid, ["192.0.2.10"])
        self.assertEqual(extract_ips("192.0.2.10, 192.0.2.11").valid, ["192.0.2.10", "192.0.2.11"])

    def test_near_misses_are_found(self):
        for text in ("192 . 0 . 2 . 40", "192,0,2,41", "192.0.2.\n42", "192.0.2.6O", "192.0.2.l0"):
            self.assertEqual(len(near_miss_ips(text)), 1, text)

    def test_valid_addresses_and_ordinary_numbers_are_not_near_misses(self):
        for text in ("192.0.2.10", "192.0.2.10:502", "192.0.2.0/24", "version 1.2.3", "1, 2, 3, 4", "04.11.2026 08:00", "pris 1.200,50"):
            self.assertEqual(near_miss_ips(text), [], text)


@unittest.skipUnless(HAS_PDF, "PyMuPDF mangler: PDF-understøttelse er IKKE verificeret")
class RealPdf(TempDirTest):
    def test_multi_page_table_finds_every_row_and_nothing_else(self):
        ref = load("inventory_tabel.pdf")
        self.assertEqual(sorted(ref.known), sorted(f"192.0.2.{100 + i}" for i in range(30)))
        self.assertEqual(ref.blockers, [])
        self.assertEqual([page.verdict for page in ref.pdf_pages], ["OK", "OK", "OK"])
        self.assertEqual([page.ips for page in ref.pdf_pages], [10, 10, 10])
        self.assertIn("inventory_tabel.pdf:side 3", ref.known["192.0.2.129"].where)
        self.assertEqual(ref.known["192.0.2.129"].kinds, {"KANDIDAT"})

    def test_inconsistent_formats_are_accepted_or_reported_never_guessed(self):
        ref = load("format_blandet.pdf")
        self.assertEqual(sorted(ref.known), ["192.0.2.43", "192.0.2.44", "192.0.2.47", "192.0.2.48"])
        text = " ".join(ref.blockers)
        for fragment in ("192 . 0 . 2 . 40", "192,0,2,41", "192.0.2. 42", "192.0.2.6O", "192.0.2.300", "192.000.002.045"):
            self.assertIn(fragment, text)
        self.assertEqual(ref.pdf_pages[0].verdict, "UDEN_SIKKER_AFLAESNING")

    def test_fully_scanned_pdf_alone_stops_with_a_reason(self):
        with self.assertRaisesRegex(InputError, "scannet.pdf.*2"):
            load("scannet.pdf")

    def test_scanned_pdf_next_to_good_reference_blocks_and_names_pages(self):
        csv_ref = self.write("i.csv", "ip\n192.0.2.1\n")
        ref = load_reference([csv_ref, PDF / "scannet.pdf"])
        self.assertEqual(list(ref.known), ["192.0.2.1"])
        self.assertEqual([page.verdict for page in ref.pdf_pages], ["INGEN_TEKST", "INGEN_TEKST"])
        self.assertTrue(any("scannet.pdf" in b and "side 1, 2" in b for b in ref.blockers), ref.blockers)

    def test_mixed_scan_reports_exactly_the_unreadable_pages(self):
        ref = load("blandet_scan.pdf")
        self.assertEqual(sorted(ref.known), ["192.0.2.60", "192.0.2.61", "192.0.2.62", "192.0.2.63"])
        self.assertEqual([page.verdict for page in ref.pdf_pages], ["OK", "INGEN_TEKST", "BILLEDE_MED_TEKST", "LILLE_BILLEDE"])

    def test_ocr_layer_and_hidden_text_are_flagged(self):
        for name, address in (("scan_ocr.pdf", "192.0.2.70"), ("skjult_tekst.pdf", "192.0.2.72")):
            ref = load(name)
            self.assertIn(address, ref.known)
            self.assertEqual(ref.pdf_pages[0].verdict, "SKJULT_TEKST", name)
            self.assertTrue(ref.blockers, name)

    def test_text_drawn_as_vector_paths_is_not_mistaken_for_a_blank_page(self):
        with self.assertRaisesRegex(InputError, "vektortekst.pdf"):
            load("vektortekst.pdf")
        ref = load_reference([self.write("i.csv", "ip\n192.0.2.1\n"), PDF / "vektortekst.pdf"])
        self.assertEqual(ref.pdf_pages[0].verdict, "INGEN_TEKST")

    def test_truly_blank_page_is_listed_but_does_not_block(self):
        ref = load("tom_side.pdf")
        self.assertEqual([page.verdict for page in ref.pdf_pages], ["OK", "TOM"])
        self.assertEqual(ref.blockers, [])

    def test_rotated_page_is_read(self):
        self.assertEqual(list(load("roteret.pdf").known), ["192.0.2.74"])

    def test_truncated_pdf_is_never_accepted_quietly(self):
        ref = load("afkortet.pdf")
        self.assertLess(len(ref.known), 30)
        self.assertTrue(any("afkortet.pdf" in b and "reparer" in b.lower() for b in ref.blockers), ref.blockers)

    def test_unreadable_files_stop_with_file_name(self):
        for name in ("ikke_pdf.pdf", "tom.pdf", "nul_sider.pdf", "krypteret.pdf"):
            with self.assertRaisesRegex(InputError, name.replace(".", r"\.")):
                load(name)

    def test_pdf_page_limit(self):
        from unittest import mock
        with mock.patch("otvalidate.ingest.MAX_PDF_PAGES", 2):
            with self.assertRaisesRegex(InputError, "sider"):
                load("inventory_tabel.pdf")

    def test_pipeline_with_gaps_writes_reports_exit_3_and_banner(self):
        out = self.tmp / "o"
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.60;192.0.2.61\n")
        result = run_cli("run_pipeline.py", "--reference", PDF / "blandet_scan.pdf", "--logs", log, "--scope", "192.0.2.0/24", "--out", out)
        self.assertEqual(result.returncode, 3, result.stderr)
        self.assertIn("UFULDSTÆNDIG", result.stdout)
        self.assertEqual([r["Vurdering"] for r in read_rows(out / "validation" / "07_pdf_udtraek.csv")], ["OK", "INGEN_TEKST", "BILLEDE_MED_TEKST", "LILLE_BILLEDE"])
        self.assertIn("BLOKERENDE", (out / "validation" / "06_begraensninger_og_advarsler.txt").read_text(encoding="utf-8"))
        self.assertIn("UFULDSTÆNDIG", (out / "rapport.html").read_text(encoding="utf-8"))
        self.assertIn("ufuldstændigt", (out / "diagram" / "02_site_dataflow.svg").read_text(encoding="utf-8"))

    def test_clean_pdf_pipeline_exits_0(self):
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.100;192.0.2.101\n")
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", PDF / "inventory_tabel.pdf", "--logs", log, "--scope", "192.0.2.0/24", "--out", out)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotIn("MuPDF", result.stderr)

    def test_unreadable_pdf_gives_exit_2_through_cli(self):
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.100;192.0.2.101\n")
        result = run_cli("run_pipeline.py", "--reference", PDF / "ikke_pdf.pdf", "--logs", log, "--out", self.tmp / "o")
        self.assertEqual(result.returncode, 2)
        self.assertNotIn("Traceback", result.stderr)


@unittest.skipUnless(shutil.which("pdftotext") and shutil.which("pdfinfo"), "Poppler mangler: fixtures er ikke krydstjekket")
class IndependentOracle(unittest.TestCase):
    """A second PDF parser confirms the fixtures are real PDFs with the intended content."""

    def test_poppler_reads_the_same_table_rows(self):
        out = subprocess.run(["pdftotext", str(PDF / "inventory_tabel.pdf"), "-"], capture_output=True, text=True, encoding="utf-8", errors="replace", check=True).stdout
        self.assertEqual(sorted(a for a in extract_ips(out, skip_cidr=True, skip_netmasks=True).valid), sorted(f"192.0.2.{100 + i}" for i in range(30)))

    def test_poppler_agrees_scan_has_two_pages_without_text(self):
        out = subprocess.run(["pdftotext", str(PDF / "scannet.pdf"), "-"], capture_output=True, text=True, encoding="utf-8", errors="replace", check=True).stdout
        self.assertEqual(out.strip("\f\r\n "), "")


if __name__ == "__main__":
    unittest.main()
