"""Regressions found by independent review: false conclusions, crashes, safety and layout."""
import json
import time
import unittest
import xml.etree.ElementTree as ET

from helpers import EXAMPLES, TempDirTest, read_rows
from otvalidate import diagrams
from otvalidate.ingest import LogAggregator, clean_text, extract_ips, load_reference, parse_time
from otvalidate.reconcile import parse_scopes, reconcile
from otvalidate.render_svg import Band, Card, Diagram, Edge, compute_layout, render_svg
from otvalidate.zones import aggregate_edges, build_nodes, load_asset_map
from test_diagrams import asset, flow, sample_diagram
from test_pipeline import run_cli


class FalseConclusions(TempDirTest):
    def validate(self, inventory, log, name="log.csv", scope=("192.0.2.0/24",), site="", stale_days=7):
        ref = load_reference([self.write("inv.csv", inventory)], site=site)
        logs = LogAggregator({}, site=site)
        logs.add_file(self.write(name, log))
        return reconcile(ref, logs, parse_scopes(list(scope)), stale_days=stale_days)

    def row(self, result, ip):
        return next(row for row in result.asset_rows if row["IP"] == ip)

    def test_unclosed_quote_swallowing_rows_is_warned(self):
        log = 'src_ip;dst_ip;note\n192.0.2.1;192.0.2.2;"åben\n192.0.2.3;192.0.2.4;x\n'
        result = self.validate("ip\n192.0.2.3\n", log)
        self.assertTrue(any("anførselstegn" in w for w in result.warnings), result.warnings)

    def test_log_rows_from_other_site_do_not_count_as_observation(self):
        inventory = "ip;site\n192.0.2.1;A\n192.0.2.9;B\n"
        result = self.validate(inventory, "site;src_ip;dst_ip\nB;192.0.2.1;192.0.2.2\n", site="A")
        self.assertEqual(self.row(result, "192.0.2.1")["Status"], "DOKUMENTERET_IKKE_OBSERVERET")
        self.assertTrue(any("andet site" in w for w in result.warnings), result.warnings)

    def test_candidates_without_site_are_warned_under_site_filter(self):
        ref = load_reference([self.write("a.csv", "ip;site\n192.0.2.1;A\n"), self.write("b.txt", "gateway 192.0.2.99\n")], site="A")
        self.assertTrue(any("192.0.2.99" in b for b in ref.blockers), ref.blockers)

    def test_host_with_prefix_length_is_a_host_not_a_subnet(self):
        self.assertEqual(extract_ips("192.0.2.10/24", skip_cidr=True).valid, ["192.0.2.10"])
        self.assertEqual(extract_ips("192.0.2.10/32", skip_cidr=True).valid, ["192.0.2.10"])
        self.assertEqual(extract_ips("192.0.2.0/24", skip_cidr=True).valid, [])
        ref = load_reference([self.write("a.csv", "ip\n192.0.2.10/24\n")])
        self.assertEqual(list(ref.known), ["192.0.2.10"])
        self.assertEqual(ref.warnings, [])

    def test_placeholder_mac_is_not_a_mismatch(self):
        for value in ("unknown", "N/A"):
            result = self.validate("ip;mac\n192.0.2.1;00:11:22:33:44:55\n", f"src_ip;dst_ip;src_mac\n192.0.2.1;192.0.2.2;{value}\n192.0.2.1;192.0.2.2;00:11:22:33:44:55\n")
            self.assertEqual(self.row(result, "192.0.2.1")["Afvigelser"], "", value)

    def test_all_sites_folders_differing_only_by_case_do_not_collide(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;A B\n192.0.2.2;a_b\n")
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", inv, "--logs", self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n"), "--all-sites", "--out", out)
        self.assertEqual(result.returncode, 3, result.stderr)  # The log has no site column: attribution is unresolved.
        self.assertEqual(len(list(out.iterdir())), 2)

    def test_stale_requires_all_shared_time_kinds_to_be_old(self):
        log = "time;src_ip;dst_ip\n2026-10-01T08:00:00Z;192.0.2.1;192.0.2.2\n2026-11-04T08:00:00Z;192.0.2.3;192.0.2.2\n04-11-2026 08:00:00;192.0.2.1;192.0.2.2\n04-11-2026 08:00:00;192.0.2.3;192.0.2.2\n"
        self.assertNotIn("SIDST_SET", self.row(self.validate("ip\n192.0.2.1\n", log), "192.0.2.1")["Afvigelser"])

    def test_log_without_any_ip_next_to_good_log_is_warned(self):
        logs = LogAggregator({})
        logs.add_file(self.write("god.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n"))
        logs.add_file(self.write("skrald.log", "ingen adresser her\nheller ikke her\n"))
        self.assertTrue(any("skrald.log" in w and "ingen" in w.lower() for w in logs.warnings), logs.warnings)

    def test_verification_requires_a_real_date(self):
        mapping, warnings = load_asset_map(self.write("m.csv", "IP;Verified_by;Verified_date\n192.0.2.1;TBD;ikke endnu\n192.0.2.2;JL;2026-10-12\n"))
        self.assertEqual(mapping["192.0.2.1"].verified, "")
        self.assertEqual(mapping["192.0.2.2"].verified, "JL 2026-10-12")
        self.assertTrue(any("192.0.2.1" in w for w in warnings))

    def test_edge_times_are_aggregated_per_time_kind(self):
        rows = [asset("192.0.2.1"), asset("192.0.2.2")]
        nodes = build_nodes(rows, [], {})
        first = {**flow("192.0.2.1", "192.0.2.2"), "Foerste_observation": "2024-01-01T00:00:00+00:00 | 2024-03-01T00:00:00 (uden tidszone)"}
        second = {**flow("192.0.2.1", "192.0.2.2", port="443"), "Foerste_observation": "2024-02-01T00:00:00+00:00"}
        edges, _ = aggregate_edges([second, first], nodes)
        self.assertIn("2024-01-01T00:00:00+00:00", edges[0].first)
        self.assertNotIn("2024-02-01", edges[0].first)
        self.assertIn("uden tidszone", edges[0].first)

    def test_diagram_cli_does_not_claim_no_traffic_for_source_only_logs(self):
        inv = self.write("i.csv", "ip\n192.0.2.1\n")
        val, dia = self.tmp / "v", self.tmp / "d"
        run_cli("src/ot_asset_validator.py", "--reference", inv, "--logs", self.write("l.csv", "src_ip;x\n192.0.2.1;1\n"), "--out", val)
        result = run_cli("src/ot_dataflow_diagram.py", "--assets", val / "01_alle_ip_adresser.csv", "--flows", val / "03_kommunikationsflows.csv", "--out", dia)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn("Ingen trafik", (dia / "02_site_dataflow.svg").read_text(encoding="utf-8"))

    def test_observed_name_never_creates_role_or_zone(self):
        row = asset("192.0.2.1", Observeret_hostname="PLC write alarm")
        node = build_nodes([row], [], {})[0]
        self.assertEqual((node.role, node.zone), ("Unknown", "Ukendt"))

    def test_destination_only_node_from_flow_table_is_not_called_source(self):
        nodes = {n.ip: n for n in build_nodes([], [flow("192.0.2.1", "192.0.2.2")], {})}
        self.assertEqual(nodes["192.0.2.1"].observation, "KILDE")
        self.assertEqual(nodes["192.0.2.2"].observation, "KUN_DESTINATION")


class Safety(TempDirTest):
    def pipeline(self, out):
        result = run_cli("run_pipeline.py", "--reference", EXAMPLES / "inventory.csv", "--logs", EXAMPLES / "nams.csv", "--scope", "192.0.2.0/24", "--detail-threshold", "1", "--out", out)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_users_own_svg_in_zone_folder_survives_rerun(self):
        out = self.tmp / "o"
        self.pipeline(out)
        mine = out / "diagram" / "zoner" / "min_tegning.svg"
        mine.write_text("<svg/>")
        generated = [p for p in mine.parent.glob("*.svg") if p != mine]
        self.assertTrue(generated)
        generated[0].write_text("gammel")
        self.pipeline(out)
        self.assertTrue(mine.exists())
        self.assertNotEqual(generated[0].read_text(), "gammel")

    def test_mermaid_directive_cannot_survive_in_labels(self):
        rows = [asset("192.0.2.1", name='%%{init: {"theme":"x"}}%% <script>x</script>')]
        text = diagrams.build_mermaid('%%{init}%%', build_nodes(rows, [], {}), [])
        self.assertNotIn("%%{", text)
        self.assertNotIn("<script", text)

    def test_hostile_name_cannot_inject_dot_attributes_through_the_pipeline(self):
        evil = 'x"];evil=[a="'
        inv = self.write("i.csv", 'ip;device_name\n192.0.2.1;"' + evil.replace('"', '""') + '"\n')
        out = self.tmp / "o"
        self.assertEqual(run_cli("run_pipeline.py", "--reference", inv, "--logs", self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n"), "--out", out).returncode, 0)
        dot = (out / "diagram" / "02_site_dataflow.dot").read_text(encoding="utf-8")
        self.assertIn('x\\"];evil=[a=\\"', dot)


class NoTracebacks(TempDirTest):
    def run_log(self, name, content, *extra):
        out = self.tmp / "o"
        path = self.tmp / name
        if isinstance(content, bytes):
            path.write_bytes(content)
        else:
            path.write_text(content, encoding="utf-8")
        result = run_cli("run_pipeline.py", "--reference", EXAMPLES / "inventory.csv", "--logs", path, "--out", out, *extra)
        self.assertNotIn("Traceback", result.stderr)
        return result

    def test_lone_surrogate_in_json_text(self):
        record = {"src_ip": "192.0.2.10", "dst_ip": "192.0.2.11", "hostname": "\ud800x", "protocol": "\ud800", "\ud800felt": 1}
        self.assertEqual(self.run_log("a.jsonl", json.dumps(record) + "\n").returncode, 0)
        self.assertEqual(clean_text("a\ud800b"), "ab")

    def test_enormous_json_integer_is_a_bad_record(self):
        self.assertEqual(self.run_log("a.jsonl", '{"src_ip":' + "9" * 5000 + '}\n{"src_ip":"192.0.2.10","dst_ip":"192.0.2.11"}\n').returncode, 0)

    def test_enormous_integer_in_json_array_is_clean_error(self):
        self.assertEqual(self.run_log("a.json", '[{"src_ip":' + "9" * 5000 + "}]").returncode, 2)

    def test_absurd_dates_count_as_unparseable(self):
        for value in ("0001-01-01", "0001-01-01T00:00:00Z", "9999-12-31T23:59:59-14:00"):
            self.assertIsNone(parse_time(value), value)
        log = "time;src_ip;dst_ip\n0001-01-01;192.0.2.10;192.0.2.11\n9999-12-31T23:59:59-14:00;192.0.2.10;192.0.2.11\n"
        self.assertEqual(self.run_log("a.csv", log).returncode, 0)

    def test_absurd_stale_days_is_rejected_cleanly(self):
        log = "time;src_ip;dst_ip\n2026-01-01T00:00:00Z;192.0.2.10;192.0.2.11\n"
        self.assertEqual(self.run_log("a.csv", log, "--stale-days", "10000000").returncode, 2)

    def test_oversized_header_is_clean_error(self):
        self.assertEqual(self.run_log("a.csv", "x" * (17 * 1024 * 1024) + ";src_ip\n1;192.0.2.10\n").returncode, 2)

    def test_diagram_cli_with_short_row_where_ip_is_not_first(self):
        assets = self.write("a.csv", "Status;I_reference;IP\nDOKUMENTERET_KILDE_OBSERVERET;JA;192.0.2.1\nx\n")
        flows = self.write("f.csv", "Kilde_IP;Destination_IP\n")
        result = run_cli("src/ot_dataflow_diagram.py", "--assets", assets, "--flows", flows, "--out", self.tmp / "d")
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_long_text_line_does_not_take_quadratic_time(self):
        logs = LogAggregator({})
        start = time.perf_counter()
        logs.add_file(self.write("a.log", "a" * 1_000_000 + "\n192.0.2.1 og 192.0.2.2\n"))
        self.assertLess(time.perf_counter() - start, 5)
        self.assertEqual(logs.stats["192.0.2.1"].mentioned, 1)
        self.assertTrue(any("afkortet" in w for w in logs.warnings), logs.warnings)


def hidden_verticals(layout):
    """Count labels with another route's vertical segment passing behind them."""
    hidden = 0
    for route in layout.routes:
        x0, y0, x1, y1 = route.label_box
        for other in layout.routes:
            if other is route:
                continue
            if any(a[0] == b[0] and x0 < a[0] < x1 and min(a[1], b[1]) < y1 and max(a[1], b[1]) > y0 for a, b in zip(other.points, other.points[1:])):
                hidden += 1
                break
    return hidden


class LayoutQuality(unittest.TestCase):
    def test_label_slides_away_from_a_vertical_passing_through_its_center(self):
        cards = [Card(id=c, title=c, mono="1", role="", evidence="") for c in "abc"]
        lower = [Card(id=c, title=c, mono="1", role="", evidence="") for c in "de"]
        diagram = Diagram("T", "", [], [], [Band("A", "", cards), Band("B", "", lower)],
                          [Edge("a", "e", "TCP/1 ×1"), Edge("b", "d", "TCP/2 ×1"), Edge("c", "d", "TCP/3 ×1"), Edge("b", "e", "TCP/4 ×1")])
        self.assertEqual(hidden_verticals(compute_layout(diagram)), 0)

    def test_most_labels_keep_clear_of_other_routes(self):
        layout = compute_layout(sample_diagram(n_per_band=6, bands=4))
        self.assertLessEqual(hidden_verticals(layout), len(layout.routes) // 3)

    def test_label_stays_on_its_own_horizontal_segment_track(self):
        for route in compute_layout(sample_diagram(n_per_band=6, bands=4)).routes:
            xs = [p[0] for p in route.points[-3:-1]]
            self.assertEqual(route.points[-2][1], route.label_center[1])
            box = route.label_box
            self.assertTrue(box[0] <= max(xs) and box[2] >= min(xs), "label must touch its own segment")

    def test_uppercase_title_fits_the_card(self):
        svg = render_svg(Diagram("T", "", [], [], [Band("A", "", [Card("a", "W" * 40, "192.168.100.100", "R" * 30, "")])], []))
        root = ET.fromstring(svg)
        texts = [el.text or "" for el in root.iter() if el.tag.endswith("text")]
        title = next(t for t in texts if t.startswith("WW"))
        role = next(t for t in texts if t.startswith("RR"))
        self.assertLessEqual(len(title), 22)
        self.assertLessEqual(len(role), 12)

    def test_long_site_title_is_cut_to_the_canvas(self):
        svg = render_svg(Diagram("X" * 300, "", ["m" * 400], ["n" * 400], [], []))
        root = ET.fromstring(svg)
        lengths = [len(el.text or "") for el in root.iter() if el.tag.endswith("text")]
        self.assertLessEqual(max(lengths), 170)
        self.assertIn("X" * 300, svg)  # Full text stays in the hover title.


class SelfEdge(unittest.TestCase):
    def test_self_edge_leaves_and_returns_to_the_same_card_below_it(self):
        bands = [Band("A", "", [Card("a", "A", "1", "", "")])]
        layout = compute_layout(Diagram("T", "", [], [], bands, [Edge("a", "a", "x")]))
        route, box = layout.routes[0], layout.cards["a"]
        self.assertEqual((route.points[0][1], route.points[-1][1]), (box[3], box[3]))
        self.assertNotEqual(route.points[0][0], route.points[-1][0])
        self.assertGreater(route.points[1][1], box[3])


if __name__ == "__main__":
    unittest.main()
