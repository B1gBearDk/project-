"""The 36-asset demo waterworks: the tool must match results that were written down in advance."""
from helpers import EXAMPLES, TempDirTest, read_rows
from test_pipeline import run_cli

DATA = EXAMPLES / "fiktivby"


class Fiktivby(TempDirTest):
    def run_demo(self, *extra):
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", DATA / "inventory.csv", "--logs", DATA / "nams.csv", "--scope", "192.0.2.0/24",
                         "--site", "Fiktivby Vandvaerk", "--log-site-confirmed", "--asset-map", DATA / "asset_map.csv", "--out", out, *extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return out

    def test_every_address_gets_the_expected_status_and_deviation(self):
        actual = {r["IP"]: (r["Status"], r["Afvigelser"]) for r in read_rows(self.run_demo() / "validation" / "01_alle_ip_adresser.csv")}
        expected = {r["IP"]: (r["Forventet_status"], r["Forventet_afvigelse"]) for r in read_rows(DATA / "forventet.csv")}
        self.assertEqual(actual, expected)

    def test_scenario_has_30_to_40_assets(self):
        rows = read_rows(DATA / "forventet.csv")
        assets = [r for r in rows if r["Forventet_status"].startswith(("DOKUMENTERET", "IKKE_I_REFERENCE"))]
        self.assertTrue(30 <= len(assets) <= 40, len(assets))

    def test_only_two_assets_are_verified_and_they_come_from_the_map(self):
        rows = read_rows(self.run_demo() / "validation" / "01_alle_ip_adresser.csv")
        self.assertEqual([r["IP"] for r in rows if r["Verificering"].startswith("MANUELT")], ["192.0.2.10", "192.0.2.31"])

    def test_report_has_navigation_and_a_complete_asset_inventory(self):
        html = (self.run_demo() / "rapport.html").read_text(encoding="utf-8")
        for anchor in ("datakvalitet", "status", "dataflow", "koe", "adresser", "review", "flows", "begraensninger", "input"):
            self.assertIn(f'href="#{anchor}"', html)
            self.assertIn(f'id="{anchor}"', html)
        inventory = html.split('id="adresser"')[1].split('id="review"')[0]
        for row in read_rows(DATA / "forventet.csv"):
            self.assertIn(row["IP"], inventory)
        self.assertIn("PLC-UV-01", inventory)

    def test_status_table_explains_each_status_in_plain_language(self):
        html = (self.run_demo() / "rapport.html").read_text(encoding="utf-8")
        status = html.split('id="status"')[1].split('id="dataflow"')[0]
        self.assertIn("Set i scope, men ikke dokumenteret", status)
        self.assertIn("Betydning", status)

    def test_queue_ip_links_to_its_row_in_the_inventory(self):
        html = (self.run_demo() / "rapport.html").read_text(encoding="utf-8")
        self.assertIn('href="#ip-192-0-2-88"', html)
        self.assertIn('id="ip-192-0-2-88"', html)
