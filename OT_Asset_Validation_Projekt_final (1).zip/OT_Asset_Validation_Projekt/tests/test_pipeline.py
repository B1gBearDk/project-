"""End-to-end tests through the real CLIs, using only examples/synthetic."""
import ast
import ipaddress
import re
import subprocess
import sys
import unittest
import xml.etree.ElementTree as ET

from helpers import EXAMPLES, ROOT, TempDirTest, read_rows
from otvalidate.report import csv_safe, csv_unsafe

DEMO = EXAMPLES / "demo"
TEST_NETS = [ipaddress.ip_network(n) for n in ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24", "224.0.0.0/4", "255.255.255.255/32", "0.0.0.0/32")]


def run_cli(script, *args):
    return subprocess.run([sys.executable, str(ROOT / script), *map(str, args)], capture_output=True,
                          text=True, encoding="utf-8", errors="replace", env={"PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1", "SYSTEMROOT": __import__("os").environ.get("SYSTEMROOT", ""), "PYTHONPATH": __import__("os").environ.get("PYTHONPATH", "")})


class Pipeline(TempDirTest):
    def small(self, *extra):
        out = self.tmp / "out"
        result = run_cli("run_pipeline.py", "--reference", EXAMPLES / "inventory.csv", "--logs", EXAMPLES / "nams.csv",
                         "--scope", "192.0.2.0/24", "--asset-map", EXAMPLES / "asset_map.csv",
                         "--site-name", "Testvandværk", "--out", out, *extra)
        self.assertEqual(result.returncode, 0, result.stderr)
        return out

    def test_small_example_statuses_match_evidence(self):
        out = self.small()
        statuses = {r["IP"]: r["Status"] for r in read_rows(out / "validation" / "01_alle_ip_adresser.csv")}
        self.assertEqual(statuses, {
            "192.0.2.10": "DOKUMENTERET_KILDE_OBSERVERET", "192.0.2.11": "DOKUMENTERET_KUN_DESTINATION",
            "192.0.2.12": "DOKUMENTERET_IKKE_OBSERVERET", "192.0.2.25": "IKKE_I_REFERENCE_IN_SCOPE",
            "198.51.100.9": "UDENFOR_SCOPE"})

    def test_all_expected_files_exist_and_svg_is_valid_xml(self):
        out = self.small()
        for name in ("01_alle_ip_adresser.csv", "02_til_gennemgang.csv", "03_kommunikationsflows.csv", "04_feltmapping.csv",
                     "05_opsummering.csv", "06_begraensninger_og_advarsler.txt"):
            self.assertTrue((out / "validation" / name).is_file(), name)
        for name in ("01_diagram_asset_catalog.csv", "02_site_dataflow.dot", "02_site_dataflow.svg", "04_diagram_summary.txt",
                     "05_site_dataflow.mmd", "06_diagram_notes.txt", "07_zone_overview.svg"):
            self.assertTrue((out / "diagram" / name).is_file(), name)
        ET.parse(out / "diagram" / "02_site_dataflow.svg")
        ET.parse(out / "diagram" / "07_zone_overview.svg")
        self.assertIn("Testvandværk", (out / "rapport.html").read_text(encoding="utf-8"))

    def test_csv_is_excel_friendly_bom_and_semicolon(self):
        raw = (self.small() / "validation" / "01_alle_ip_adresser.csv").read_bytes()
        self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"IP;Status;", raw)

    def test_output_is_byte_deterministic(self):
        out = self.small()
        first = {p.relative_to(out): p.read_bytes() for p in out.rglob("*") if p.is_file()}
        out2 = self.small()
        second = {p.relative_to(out2): p.read_bytes() for p in out2.rglob("*") if p.is_file()}
        self.assertEqual(first, second)

    def test_rerun_removes_stale_outputs_but_keeps_foreign_files(self):
        out = self.small()
        stale = out / "diagram" / "03_site_dataflow.png"
        stale.write_bytes(b"old")
        foreign = out / "diagram" / "mine_noter.txt"
        foreign.write_text("behold")
        self.small()
        self.assertTrue(foreign.exists())
        if stale.exists():  # Graphviz present: file must then be freshly rendered
            self.assertNotEqual(stale.read_bytes(), b"old")

    def test_nothing_is_written_outside_output_dir(self):
        before = sorted(p for p in EXAMPLES.rglob("*") if p.is_file())
        self.small()
        self.assertEqual(sorted(p for p in EXAMPLES.rglob("*") if p.is_file()), before)
        self.assertEqual([p.name for p in self.tmp.iterdir()], ["out"])

    def test_outputs_contain_only_test_net_addresses(self):
        out = self.small()
        for path in out.rglob("*"):
            if path.is_file() and path.suffix != ".png":
                for match in re.findall(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])", path.read_text(encoding="utf-8-sig")):
                    self.assertTrue(any(ipaddress.ip_address(match) in net for net in TEST_NETS), f"{match} in {path}")

    def test_diagram_states_it_is_not_physical_topology(self):
        svg = (self.small() / "diagram" / "02_site_dataflow.svg").read_text(encoding="utf-8")
        self.assertIn("ikke fysisk topologi", svg)

    def test_no_asset_is_shown_verified_without_explicit_input(self):
        out = self.small()
        self.assertNotIn("✓", (out / "diagram" / "02_site_dataflow.svg").read_text(encoding="utf-8").split("Tegnforklaring")[0])

    def test_formula_injection_is_neutralised_in_every_csv(self):
        inv = self.write("i.csv", 'ip;device_name\n192.0.2.1;"=HYPERLINK(""x"")"\n')
        log = self.write("l.csv", "src_ip;dst_ip;hostname\n192.0.2.1;192.0.2.2;@SUM(1)\n")
        out = self.tmp / "o"
        self.assertEqual(run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--out", out).returncode, 0)
        for path in out.rglob("*.csv"):
            for row in read_rows(path):
                for value in row.values():
                    self.assertFalse((value or "").lstrip().startswith(("=", "@", "+", "-")), f"{value} in {path.name}")

    def test_hostile_input_cannot_break_svg_html_or_dot(self):
        evil = '<script>x</script>"];evil=[a="'
        inv = self.write("i.csv", f'ip;device_name\n192.0.2.1;"{evil.replace(chr(34), chr(34) * 2)}"\n')
        log = self.write("l.csv", "src_ip;dst_ip;protocol\n192.0.2.1;192.0.2.2;TCP\n")
        out = self.tmp / "o"
        self.assertEqual(run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--site-name", evil, "--out", out).returncode, 0)
        ET.parse(out / "diagram" / "02_site_dataflow.svg")
        self.assertNotIn("<script", (out / "rapport.html").read_text(encoding="utf-8"))

    def test_clean_error_and_exit_2_for_bad_inputs(self):
        inv = EXAMPLES / "inventory.csv"
        cases = [
            ("--reference", self.tmp / "findes-ikke.csv", "--logs", EXAMPLES / "nams.csv"),
            ("--reference", inv, "--logs", self.write("skema.csv", "foo;bar\n1;2\n")),
            ("--reference", inv, "--logs", EXAMPLES / "nams.csv", "--scope", "ikke-et-net"),
            ("--reference", inv, "--logs", EXAMPLES / "nams.csv", "--source-field", "stavefejl"),
        ]
        for case in cases:
            result = run_cli("run_pipeline.py", *case, "--out", self.tmp / "e")
            self.assertEqual(result.returncode, 2, case)
            self.assertNotIn("Traceback", result.stderr)

    def test_empty_log_still_reports_and_shows_warning_banner(self):
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", EXAMPLES / "inventory.csv", "--logs", self.write("tom.csv", ""), "--scope", "192.0.2.0/24", "--out", out)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Ingen trafik", (out / "diagram" / "02_site_dataflow.svg").read_text(encoding="utf-8"))

    def test_separate_clis_still_work_and_round_trip_formula_text(self):
        inv = self.write("i.csv", "ip;device_name\n192.0.2.1;=PLC\n")
        log = self.write("l.csv", "src_ip;dst_ip;protocol;dst_port\n192.0.2.1;192.0.2.2;TCP;502\n")
        val = self.tmp / "val"
        self.assertEqual(run_cli("src/ot_asset_validator.py", "--reference", inv, "--logs", log, "--out", val).returncode, 0)
        dia = self.tmp / "dia"
        result = run_cli("src/ot_dataflow_diagram.py", "--assets", val / "01_alle_ip_adresser.csv", "--flows", val / "03_kommunikationsflows.csv", "--out", dia)
        self.assertEqual(result.returncode, 0, result.stderr)
        svg = (dia / "02_site_dataflow.svg").read_text(encoding="utf-8")
        self.assertIn("=PLC", svg)
        self.assertNotIn("'=PLC", svg)

    def test_all_sites_writes_one_folder_per_site_with_safe_names(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;..\\..\\ude/Syd\n")
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--scope", "192.0.2.0/24", "--all-sites", "--out", out)
        self.assertEqual(result.returncode, 3, result.stderr)  # The log has no site column: attribution is unresolved.
        self.assertEqual(sorted(p.name for p in out.iterdir()), ["Nord", "ude_Syd"])
        self.assertEqual({p.name for p in self.tmp.iterdir()}, {"i.csv", "l.csv", "o"})
        rows = {r["IP"]: r["Status"] for r in read_rows(out / "Nord" / "validation" / "01_alle_ip_adresser.csv")}
        self.assertEqual(rows["192.0.2.2"], "DOKUMENTERET_ANDET_SITE")

    def test_multiple_sites_without_site_choice_warns(self):
        inv = self.write("i.csv", "ip;site\n192.0.2.1;Nord\n192.0.2.2;Syd\n")
        log = self.write("l.csv", "src_ip;dst_ip\n192.0.2.1;192.0.2.2\n")
        out = self.tmp / "o"
        run_cli("run_pipeline.py", "--reference", inv, "--logs", log, "--out", out)
        self.assertIn("flere sites", (out / "validation" / "06_begraensninger_og_advarsler.txt").read_text(encoding="utf-8"))


class DemoSite(TempDirTest):
    def test_rich_demo_covers_all_evidence_states(self):
        out = self.tmp / "demo"
        result = run_cli("tools/run_demo.py", "--out", out)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        rows = read_rows(out / "demo" / "validation" / "01_alle_ip_adresser.csv")
        statuses = {r["Status"] for r in rows}
        for status in ("DOKUMENTERET_KILDE_OBSERVERET", "DOKUMENTERET_KUN_DESTINATION", "DOKUMENTERET_IKKE_OBSERVERET",
                       "IKKE_I_REFERENCE_IN_SCOPE", "UDENFOR_SCOPE", "LOGISK_ADRESSE"):
            self.assertIn(status, statuses)
        self.assertTrue(any("MAC_AFVIGER" in r["Afvigelser"] for r in rows))
        self.assertTrue(any(r["Verificering"].startswith("MANUELT") for r in rows))
        ET.parse(out / "demo" / "diagram" / "02_site_dataflow.svg")

    def test_large_site_gets_zone_detail_diagrams(self):
        out = self.tmp / "o"
        result = run_cli("run_pipeline.py", "--reference", DEMO / "inventory.csv", "--logs", DEMO / "nams.csv", DEMO / "nams_syslog.log", DEMO / "nams_events.jsonl",
                         "--scope", "192.0.2.0/24", "--asset-map", DEMO / "asset_map.csv", "--detail-threshold", "1", "--log-site-confirmed", "--site", "Testvandvaerk", "--out", out)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        details = list((out / "diagram" / "zoner").glob("*.svg"))
        self.assertGreater(len(details), 2)
        for path in details:
            ET.parse(path)


class CsvSafety(unittest.TestCase):
    def test_csv_safe_prefixes_formula_starters(self):
        for value in ("=1", "+1", "-1", "@x", "\t=1", "＝1", " =1"):
            self.assertTrue(csv_safe(value).startswith("'"), value)
        self.assertEqual(csv_safe("192.0.2.1"), "192.0.2.1")

    def test_csv_unsafe_is_inverse_for_neutralised_values_only(self):
        self.assertEqual(csv_unsafe(csv_safe("=1")), "=1")
        self.assertEqual(csv_unsafe("'normal"), "'normal")


class OfflineGuarantee(unittest.TestCase):
    FORBIDDEN = {"socket", "ssl", "http", "urllib", "requests", "ftplib", "telnetlib", "smtplib", "asyncio", "pandas", "scapy", "paramiko", "snmp", "pymodbus"}

    def test_source_imports_no_network_modules(self):
        files = [ROOT / "run_pipeline.py", *ROOT.glob("src/**/*.py"), *ROOT.glob("tools/*.py")]
        self.assertGreater(len(files), 5)
        for path in files:
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 10))):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names = [node.module]
                for name in names:
                    self.assertNotIn(name.split(".")[0], self.FORBIDDEN, f"{path.name}: {name}")

    def test_only_subprocess_call_is_local_graphviz_in_diagrams(self):
        users = [p.name for p in [*ROOT.glob("src/**/*.py"), ROOT / "run_pipeline.py"] if "subprocess" in p.read_text(encoding="utf-8")]
        self.assertEqual(users, ["diagrams.py"])  # Graphviz only.

    def test_no_real_looking_data_in_examples(self):
        for path in EXAMPLES.rglob("*"):
            if path.is_file() and path.suffix != ".pdf":
                for match in re.findall(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])", path.read_text(encoding="utf-8-sig")):
                    self.assertTrue(any(ipaddress.ip_address(match) in net for net in TEST_NETS), f"{match} in {path.name}")


if __name__ == "__main__":
    unittest.main()
