import re
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

from helpers import TempDirTest
from otvalidate import diagrams
from otvalidate.render_svg import Band, Card, Diagram, Edge, compute_layout, render_svg
from otvalidate.zones import aggregate_edges, build_nodes, infer_role, load_asset_map


def asset(ip, status="DOKUMENTERET_KILDE_OBSERVERET", name="", scope="JA", observation="KILDE", **extra):
    return {"IP": ip, "Status": status, "I_scope": scope, "I_reference": "UAFKLARET" if status == "DOKUMENTERET_SITE_UAFKLARET" else "JA" if status.startswith("DOK") and status != "DOKUMENTERET_ANDET_SITE" else "NEJ",
            "Observation": observation, "Dokumenteret_enhed": name, "Observeret_hostname": "", "Verificering": "IKKE_VERIFICERET",
            "Afvigelser": "", "Dokumentationstype": "STRUKTURERET", "Foreslaaet_naeste_skridt": "", **extra}


def flow(src, dst, proto="TCP", port="502", count=1):
    return {"Kilde_IP": src, "Destination_IP": dst, "Protokol": proto, "Destination_port": port, "Antal_observationer": count,
            "Foerste_observation": "", "Seneste_observation": ""}


class Roles(unittest.TestCase):
    def test_status_text_can_no_longer_create_a_role(self):
        self.assertEqual(infer_role("192.0.2.40"), "Unknown")

    def test_token_match_not_substring(self):
        for name in ("Pumpestation-3", "api-node", "news-feed", "Parameter-log", "Springfield"):
            self.assertEqual(infer_role(name), "Unknown", name)

    def test_common_names(self):
        self.assertEqual(infer_role("PLC-01"), "PLC")
        self.assertEqual(infer_role("PLC01"), "PLC")
        self.assertEqual(infer_role("hmi_kontrolrum"), "HMI")
        self.assertEqual(infer_role("FW-edge"), "Firewall")
        self.assertEqual(infer_role("Flowmåler 3"), "Unknown")
        self.assertEqual(infer_role("Måler 3"), "Field Device")


class Zones(TempDirTest):
    def node(self, row, mapping=None):
        return build_nodes([row], [], mapping or {})[0]

    def test_manual_map_beats_heuristic_and_is_marked_manual(self):
        mapping, _ = load_asset_map(self.write("m.csv", "IP;Zone;Role;Label\n192.0.2.1;Control;RTU;Pumpe A\n"))
        node = self.node(asset("192.0.2.1", name="HMI-01"), mapping)
        self.assertEqual((node.zone, node.zone_source, node.role, node.role_source, node.label), ("Control", "MANUEL", "RTU", "MANUEL", "Pumpe A"))

    def test_heuristic_is_marked_hypothesis(self):
        node = self.node(asset("192.0.2.1", name="PLC-01"))
        self.assertEqual((node.zone, node.zone_source, node.role_source), ("Control", "HYPOTESE", "HYPOTESE"))

    def test_documented_plc_without_scope_is_not_external(self):
        self.assertEqual(self.node(asset("192.0.2.1", name="PLC-01", scope="IKKE_OPLYST")).zone, "Control")

    def test_undocumented_without_scope_is_unknown_not_external(self):
        row = asset("192.0.2.1", status="IKKE_I_REFERENCE_SCOPE_UKENDT", scope="IKKE_OPLYST")
        self.assertEqual(self.node(row).zone, "Ukendt")

    def test_documented_outside_scope_is_not_external(self):
        self.assertEqual(self.node(asset("198.51.100.1", scope="NEJ")).zone, "Ukendt")

    def test_outside_scope_is_external_from_scope_evidence(self):
        node = self.node(asset("198.51.100.1", status="UDENFOR_SCOPE", scope="NEJ", name="PLC"))
        self.assertEqual((node.zone, node.zone_source), ("Eksternt", "SCOPE"))

    def test_logical_address_has_own_zone(self):
        self.assertEqual(self.node(asset("224.0.0.5", status="LOGISK_ADRESSE", scope="NEJ")).zone, "Logiske adresser")

    def test_zone_aliases_are_canonical_and_custom_zone_is_kept_with_warning(self):
        mapping, warnings = load_asset_map(self.write("m.csv", "IP;Zone\n192.0.2.1;netvaerk\n192.0.2.2;CONTROL\n192.0.2.3;DMZ\n"))
        self.assertEqual([mapping[ip].zone for ip in ("192.0.2.1", "192.0.2.2", "192.0.2.3")], ["Netværk", "Control", "DMZ"])
        self.assertTrue(any("DMZ" in w for w in warnings))

    def test_map_rejects_invalid_ip_and_requires_ip_column(self):
        mapping, warnings = load_asset_map(self.write("m.csv", "IP;Zone\nikke-ip;Control\n"))
        self.assertEqual(mapping, {})
        self.assertTrue(any("ikke-ip" in w for w in warnings))
        with self.assertRaises(ValueError):
            load_asset_map(self.write("n.csv", "Zone\nControl\n"))

    def test_edges_group_by_pair_and_respect_min_count(self):
        nodes = build_nodes([asset("192.0.2.1"), asset("192.0.2.2")], [], {})
        edges, hidden = aggregate_edges([flow("192.0.2.1", "192.0.2.2", "TCP", "502", 5), flow("192.0.2.1", "192.0.2.2", "TCP", "443", 1)], nodes, min_count=2)
        self.assertEqual(len(edges), 1)
        self.assertEqual(edges[0].services, [("TCP", "502", 5)])
        self.assertEqual(hidden, 1)


def sample_diagram(n_per_band=3, bands=3, undocumented=False):
    result_bands, edges = [], []
    for b in range(bands):
        cards = [Card(id=f"b{b}c{c}", title=f"Asset {b}-{c}", mono=f"192.0.2.{b * 10 + c + 1}", role="PLC", evidence="Dokumenteret") for c in range(n_per_band)]
        result_bands.append(Band(name=f"Zone {b}", note="", cards=cards))
    for b in range(bands):
        for c in range(n_per_band):
            for b2 in range(bands):
                target = f"b{b2}c{(c + b2) % n_per_band}"
                if target != f"b{b}c{c}" and (b + c + b2) % 2 == 0:
                    edges.append(Edge(src=f"b{b}c{c}", dst=target, label=f"TCP/{500 + c} ×{b2 + 1}", dashed=undocumented))
    return Diagram(title="Test", subtitle="Observerede flows", meta=[], notices=[], bands=result_bands, edges=edges)


def overlaps(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


class Layout(unittest.TestCase):
    def test_zone_order_is_fixed_regardless_of_flow_direction(self):
        diagram = sample_diagram()
        layout = compute_layout(diagram)
        tops = [layout.bands[band.name][1] for band in diagram.bands]
        self.assertEqual(tops, sorted(tops))

    def test_cards_never_overlap(self):
        layout = compute_layout(sample_diagram(n_per_band=9, bands=4))
        boxes = list(layout.cards.values())
        for i, a in enumerate(boxes):
            for b in boxes[i + 1:]:
                self.assertFalse(overlaps(a, b))

    def test_edges_never_pass_through_unrelated_cards(self):
        diagram = sample_diagram(n_per_band=7, bands=5)
        layout = compute_layout(diagram)
        for route in layout.routes:
            for (x1, y1), (x2, y2) in zip(route.points, route.points[1:]):
                self.assertTrue(x1 == x2 or y1 == y2, "routes must be orthogonal")
                seg = (min(x1, x2) - 0.5, min(y1, y2) - 0.5, max(x1, x2) + 0.5, max(y1, y2) + 0.5)
                for card_id, box in layout.cards.items():
                    if card_id in (route.edge.src, route.edge.dst):
                        continue
                    self.assertFalse(overlaps(seg, box), f"{route.edge.src}->{route.edge.dst} crosses {card_id}")

    def test_edges_touch_own_cards_only_at_the_border(self):
        layout = compute_layout(sample_diagram())
        for route in layout.routes:
            src, dst = layout.cards[route.edge.src], layout.cards[route.edge.dst]
            self.assertIn(route.points[0][1], (src[1], src[3]))
            self.assertIn(route.points[-1][1], (dst[1], dst[3]))

    def test_labels_do_not_overlap_each_other(self):
        layout = compute_layout(sample_diagram(n_per_band=7, bands=4))
        boxes = [r.label_box for r in layout.routes if r.label_box]
        self.assertTrue(boxes)
        for i, a in enumerate(boxes):
            for b in boxes[i + 1:]:
                self.assertFalse(overlaps(a, b), (a, b))

    def test_labels_do_not_cover_cards(self):
        layout = compute_layout(sample_diagram(n_per_band=7, bands=4))
        for route in layout.routes:
            for box in layout.cards.values():
                self.assertFalse(overlaps(route.label_box, box))

    def test_layout_is_deterministic(self):
        self.assertEqual(render_svg(sample_diagram()), render_svg(sample_diagram()))

    def test_bidirectional_pair_gets_two_distinct_routes(self):
        bands = [Band("A", "", [Card("a", "A", "1", "", "")]), Band("B", "", [Card("b", "B", "2", "", "")])]
        layout = compute_layout(Diagram("T", "", [], [], bands, [Edge("a", "b", "x"), Edge("b", "a", "y")]))
        self.assertNotEqual(layout.routes[0].points[1:-1], list(reversed(layout.routes[1].points[1:-1])))

    def test_self_edge_is_rendered(self):
        bands = [Band("A", "", [Card("a", "A", "1", "", "")])]
        self.assertEqual(len(compute_layout(Diagram("T", "", [], [], bands, [Edge("a", "a", "x")])).routes), 1)


class SvgOutput(unittest.TestCase):
    def test_hostile_text_is_escaped_and_parseable(self):
        evil = '<script>alert(1)</script>&"\'</text><image href="x"/>'
        card = Card(id=evil, title=evil, mono=evil, role=evil, evidence=evil, deviation=evil, tooltip=evil)
        svg = render_svg(Diagram(evil, evil, [evil], [evil], [Band(evil, evil, [card])], [Edge(evil, evil, evil, title=evil)]))
        root = ET.fromstring(svg)
        tags = {el.tag.rsplit("}", 1)[-1] for el in root.iter()}
        self.assertNotIn("script", tags)
        self.assertNotIn("image", tags)

    def test_empty_diagram_says_so(self):
        svg = render_svg(Diagram("T", "", [], [], [], []))
        ET.fromstring(svg)
        self.assertIn("Ingen assets", svg)


class Sources(TempDirTest):
    def nodes_and_edges(self):
        rows = [asset("192.0.2.1", name='PL"C\\x\n];evil[label="1'), asset("192.0.2.9", status="IKKE_I_REFERENCE_IN_SCOPE", name="", observation="KILDE")]
        nodes = build_nodes(rows, [], {})
        edges, _ = aggregate_edges([flow("192.0.2.9", "192.0.2.1", 'T"CP', "502")], nodes)
        return nodes, edges

    def test_dot_escaping_keeps_strings_balanced(self):
        nodes, edges = self.nodes_and_edges()
        dot = diagrams.build_dot('Site "A"\\\nnext', nodes, edges)
        # Removing well-formed quoted strings must leave no stray quotes or hostile attributes.
        stripped = re.sub(r'"(?:[^"\\]|\\.)*"', '""', dot)
        self.assertNotIn('"""', stripped)
        self.assertEqual(stripped.count('"') % 2, 0)
        self.assertNotIn("evil", stripped)
        self.assertEqual(stripped.count("{"), stripped.count("}"))

    def test_dot_keeps_custom_zone_nodes(self):
        mapping, _ = load_asset_map(self.write("m.csv", "IP;Zone\n192.0.2.1;DMZ\n"))
        nodes = build_nodes([asset("192.0.2.1")], [], mapping)
        self.assertIn("n_192_0_2_1", diagrams.build_dot("S", nodes, []))
        self.assertIn("DMZ", diagrams.build_dot("S", nodes, []))

    def test_dot_chains_zones_so_order_does_not_follow_traffic(self):
        rows = [asset("192.0.2.1", name="PLC-1"), asset("192.0.2.2", name="HMI-1")]
        nodes = build_nodes(rows, [], {})
        edges, _ = aggregate_edges([flow("192.0.2.1", "192.0.2.2")], nodes)
        dot = diagrams.build_dot("S", nodes, edges)
        self.assertIn("constraint=false", dot)
        self.assertIn("style=invis", dot)

    def test_mermaid_escaping(self):
        nodes, edges = self.nodes_and_edges()
        text = diagrams.build_mermaid('Site "A"\n%%x', nodes, edges)
        for line in text.splitlines():
            if line.startswith("subgraph") or "[" in line or "|" in line:
                self.assertEqual(line.count('"') % 2, 0, line)
        self.assertNotIn("<script", text)
        self.assertFalse(any(line.startswith("%%x") for line in text.splitlines()))

    def test_mermaid_custom_zone_does_not_crash(self):
        mapping, _ = load_asset_map(self.write("m.csv", "IP;Zone\n192.0.2.1;DMZ\n"))
        nodes = build_nodes([asset("192.0.2.1")], [], mapping)
        edges, _ = aggregate_edges([flow("192.0.2.1", "192.0.2.1")], nodes)
        self.assertIn("DMZ", diagrams.build_mermaid("S", nodes, edges))


class CardsFromNodes(unittest.TestCase):
    def card(self, row, mapping=None):
        return diagrams.node_card(build_nodes([row], [], mapping or {})[0])

    def test_hypothesis_role_carries_question_mark(self):
        self.assertEqual(self.card(asset("192.0.2.1", name="PLC-01")).role, "PLC?")

    def test_evidence_kinds_differ_visually_and_in_text(self):
        observed = self.card(asset("192.0.2.1"))
        dest_only = self.card(asset("192.0.2.2", status="DOKUMENTERET_KUN_DESTINATION", observation="KUN_DESTINATION"))
        silent = self.card(asset("192.0.2.3", status="DOKUMENTERET_IKKE_OBSERVERET", observation="IKKE_OBSERVERET"))
        unknown = self.card(asset("192.0.2.4", status="IKKE_I_REFERENCE_IN_SCOPE"))
        self.assertEqual(len({observed.stroke, dest_only.stroke, silent.stroke}), 3)
        self.assertEqual(len({observed.evidence, dest_only.evidence, silent.evidence, unknown.evidence}), 4)
        self.assertEqual(observed.fill, "documented")
        self.assertEqual(unknown.fill, "undocumented")

    def test_unnamed_asset_does_not_repeat_ip_as_title(self):
        card = self.card(asset("192.0.2.1"))
        self.assertEqual((card.title, card.mono), ("Uden navn", "192.0.2.1"))

    def test_logical_address_is_titled_by_its_kind(self):
        row = asset("239.1.1.1", status="LOGISK_ADRESSE", scope="NEJ", Adressetype="multicast")
        self.assertEqual(self.card(row).title, "Multicast")

    def test_overview_uses_singular_for_one_asset(self):
        nodes = build_nodes([asset("192.0.2.1")], [], {})
        self.assertEqual(diagrams.overview_diagram("S", nodes, [], [], []).bands[0].cards[0].title, "1 asset")

    def test_verified_badge_only_with_explicit_value(self):
        self.assertFalse(self.card(asset("192.0.2.1")).verified)
        row = asset("192.0.2.1", Verificering="MANUELT_VERIFICERET JL 2026-10-01")
        self.assertIn("JL", self.card(row).verified)


class Graphviz(TempDirTest):
    def test_missing_graphviz_gives_message_and_no_exception(self):
        with mock.patch("otvalidate.diagrams.shutil.which", return_value=None):
            ok, message = diagrams.render_png(self.write("a.dot", "digraph{}"), self.tmp / "a.png")
        self.assertFalse(ok)
        self.assertIn("Graphviz", message)

    def test_failing_dot_gives_message_and_no_exception(self):
        with mock.patch("otvalidate.diagrams.shutil.which", return_value=str(self.tmp / "tools" / "dot")), \
                mock.patch("otvalidate.diagrams.subprocess.run", side_effect=OSError("boom")):
            ok, message = diagrams.render_png(self.write("a.dot", "digraph{}"), self.tmp / "a.png")
        self.assertFalse(ok)
        self.assertIn("boom", message)


if __name__ == "__main__":
    unittest.main()
