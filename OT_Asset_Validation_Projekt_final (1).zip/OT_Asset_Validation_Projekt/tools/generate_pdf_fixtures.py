#!/usr/bin/env python3
"""Write real PDF files with known content to examples/synthetic/pdf. Only RFC 5737 addresses.

The writer uses the standard library, so a fixture cannot inherit behaviour from the PDF library
under test. Only krypteret.pdf needs PyMuPDF, which is the one encryption writer available here.
"""
from pathlib import Path
import random
import zlib

OUT = Path(__file__).resolve().parents[1] / "examples" / "synthetic" / "pdf"
W, H = 595, 842


def text_op(x, y, text, size=10, render=0):
    escaped = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    return f"BT /F1 {size} Tf {render} Tr {x} {y} Td ({escaped}) Tj ET\n"


def lines_op(lines, x=50, top=780, step=16):
    return "".join(text_op(x, top - i * step, line) for i, line in enumerate(lines))


def gray_image(width=200, height=280, seed=7):
    """A noisy grey bitmap with dark bands, shaped like a scanned text page."""
    rng = random.Random(seed)
    rows = []
    for y in range(height):
        band = y % 14 < 5
        rows.append(bytes(rng.randrange(20, 90) if band and rng.random() < 0.6 else rng.randrange(225, 255) for _ in range(width)))
    return width, height, zlib.compress(b"".join(rows))


def build_pdf(pages):
    """pages: list of dicts with `ops` (content text), optional `image` and `rotate`."""
    objects = {1: None, 2: None, 3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"}
    next_id = 4
    kids = []
    for page in pages:
        page_id, content_id = next_id, next_id + 1
        next_id += 2
        xobject = ""
        if page.get("image"):
            width, height, data = page["image"]
            image_id = next_id
            next_id += 1
            objects[image_id] = (f"<< /Type /XObject /Subtype /Image /Width {width} /Height {height} /ColorSpace /DeviceGray "
                                 f"/BitsPerComponent 8 /Filter /FlateDecode /Length {len(data)} >>\nstream\n").encode() + data + b"\nendstream"
            xobject = f"/XObject << /Im0 {image_id} 0 R >>"
        stream = page.get("ops", "").encode("cp1252")
        objects[content_id] = f"<< /Length {len(stream)} >>\nstream\n".encode() + stream + b"\nendstream"
        rotate = f"/Rotate {page['rotate']}" if page.get("rotate") else ""
        objects[page_id] = (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {W} {H}] {rotate} /Contents {content_id} 0 R "
                            f"/Resources << /Font << /F1 3 0 R >> {xobject} >> >>").encode()
        kids.append(f"{page_id} 0 R")
    objects[1] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objects[2] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>".encode()
    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = {}
    for number in sorted(objects):
        offsets[number] = len(out)
        out += f"{number} 0 obj\n".encode() + objects[number] + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    for number in sorted(objects):
        out += f"{offsets[number]:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)


def draw_image_op(x, y, w, h):
    return f"q {w} 0 0 {h} {x} {y} cm /Im0 Do Q\n"


def table_pages():
    """30 rows over three pages, with repeated header, a subnet and a netmask in the footer."""
    rows = [(f"192.0.2.{100 + i}", f"PLC-{i:02d}", "Control") for i in range(30)]
    pages = []
    for number, start in enumerate(range(0, 30, 10), 1):
        ops = text_op(50, 800, "Testvandvaerk Nord - IP-liste", 14) + text_op(50, 780, "IP-adresse") + text_op(180, 780, "Navn") + text_op(320, 780, "Zone")
        for index, (ip, name, zone) in enumerate(rows[start:start + 10]):
            y = 760 - index * 18
            ops += text_op(50, y, ip) + text_op(180, y, name) + text_op(320, y, zone)
        ops += text_op(50, 60, "Net 192.0.2.0/24 maske 255.255.255.0") + text_op(480, 60, f"Side {number} af 3")
        pages.append({"ops": ops})
    return pages


def write_all():
    OUT.mkdir(parents=True, exist_ok=True)
    table = build_pdf(table_pages())
    full_image = {"image": gray_image(), "ops": draw_image_op(0, 0, W, H)}
    files = {
        "inventory_tabel.pdf": table,
        "format_blandet.pdf": build_pdf([{"ops": lines_op([
            "Korrekt: 192.0.2.43", "Med port: 192.0.2.48:502", "Vaert med praefiks: 192.0.2.44/24", "Sidst i saetning 192.0.2.47.",
            "Mellemrum: 192 . 0 . 2 . 40", "Komma: 192,0,2,41", "Ombrudt: 192.0.2.", "42", "OCR-fejl: 192.0.2.6O", "Ugyldig: 192.0.2.300", "Foranstillede nuller: 192.000.002.045",
            "Subnet: 198.51.100.0/24", "Maske: 255.255.255.0"])}]),
        "scannet.pdf": build_pdf([full_image, {"image": gray_image(seed=8), "ops": draw_image_op(0, 0, W, H)}]),
        "blandet_scan.pdf": build_pdf([
            {"ops": lines_op(["Side med tekst", "192.0.2.60", "192.0.2.61"])},
            {"image": gray_image(seed=9), "ops": draw_image_op(0, 0, W, H)},
            {"image": gray_image(seed=10), "ops": text_op(50, 800, "Tabel fortsaetter som billede: 192.0.2.62") + draw_image_op(50, 100, 495, 650)},
            {"image": gray_image(40, 40, seed=11), "ops": text_op(50, 800, "Side med lille logo: 192.0.2.63") + draw_image_op(500, 780, 40, 40)}]),
        "scan_ocr.pdf": build_pdf([{"image": gray_image(seed=12), "ops": draw_image_op(0, 0, W, H) + text_op(50, 700, "OCR-lag 192.0.2.70", render=3)}]),
        "skjult_tekst.pdf": build_pdf([{"ops": text_op(50, 800, "Synlig 192.0.2.71") + text_op(50, 700, "Skjult 192.0.2.72", render=3)}]),
        "vektortekst.pdf": build_pdf([{"ops": "".join(f"{50 + i * 8} 700 m {54 + i * 8} 716 l S\n" for i in range(40))}]),
        "tom_side.pdf": build_pdf([{"ops": text_op(50, 800, "192.0.2.73")}, {"ops": ""}]),
        "billede_30pct.pdf": build_pdf([{"image": gray_image(seed=13), "ops": text_op(50, 800, "Tekst 192.0.2.76") + draw_image_op(50, 300, 300, 500)}]),
        "tekst_og_streger.pdf": build_pdf([{"ops": text_op(50, 800, "Tekst 192.0.2.77") + "".join(f"{50 + i * 8} 700 m {54 + i * 8} 716 l S\n" for i in range(40))}]),
        "roteret.pdf": build_pdf([{"ops": text_op(50, 800, "Roteret side 192.0.2.74"), "rotate": 90}]),
        "afkortet.pdf": table[:int(len(table) * 0.55)],
        "ikke_pdf.pdf": b"Dette er ikke en PDF, kun tekst med 192.0.2.75\n",
        "tom.pdf": b"",
        "nul_sider.pdf": build_pdf([]),
    }
    for name, data in files.items():
        (OUT / name).write_bytes(data)
    appendix = build_pdf([{"ops": lines_op(["Bilag A - Reservemateriel, Testvandvaerk", "", "Reserve-PLC  192.0.2.60", "Reserve-HMI  192.0.2.61", "Net 192.0.2.0/24"])}])
    (OUT.parent / "demo" / "bilag.pdf").write_bytes(appendix)
    try:
        import pymupdf
    except ImportError:
        print("PyMuPDF mangler: krypteret.pdf er ikke genskabt.")
        return
    with pymupdf.open(stream=table, filetype="pdf") as doc:
        doc.save(str(OUT / "krypteret.pdf"), encryption=pymupdf.PDF_ENCRYPT_AES_256, user_pw="test", owner_pw="ejer")


if __name__ == "__main__":
    write_all()
