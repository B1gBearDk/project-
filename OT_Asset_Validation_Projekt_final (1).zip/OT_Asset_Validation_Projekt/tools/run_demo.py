#!/usr/bin/env python3
"""End-to-end demonstration on fictional waterworks. Only RFC 5737 TEST-NET data.

Three scenarios, each with the exit code it must give. A wrong exit code fails the demo:
  demo         One site: inventory + PDF appendix + three log formats + asset map + human decisions. Exit 0.
  huller       The same, plus a scanned PDF with no site. The gaps are reported. Exit 3.
  flere_sites  Two waterworks with one shared log, including an IP used on both sites. Exit 3.
"""
import argparse
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from otvalidate.cli import run_pipeline  # noqa: E402

SYNTHETIC = ROOT / "examples" / "synthetic"
DEMO = SYNTHETIC / "demo"
MULTI = SYNTHETIC / "flere_sites"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", type=Path, default=ROOT / "output" / "demo", help="Rodmappe; hvert scenarie får sin egen undermappe")
    args = parser.parse_args()
    has_pdf = importlib.util.find_spec("pymupdf") is not None

    one_site = ["--logs", str(DEMO / "nams.csv"), str(DEMO / "nams_syslog.log"), str(DEMO / "nams_events.jsonl"), "--scope", "192.0.2.0/24",
                "--asset-map", str(DEMO / "asset_map.csv"), "--review-file", str(DEMO / "review_beslutninger.csv"), "--site", "Testvandvaerk",
                "--log-site-confirmed", "--site-name", "Testvandværk (syntetisk)"]
    appendix = ["--reference", str(DEMO / "inventory.csv"), str(DEMO / "bilag.pdf"), "--reference-site", "bilag.pdf=Testvandvaerk"] if has_pdf else ["--reference", str(DEMO / "inventory.csv")]
    scenarios = [("demo", 0, [*appendix, *one_site, "--out", str(args.out / "demo")])]
    if has_pdf:
        gaps = ["--reference", str(DEMO / "inventory.csv"), str(DEMO / "bilag.pdf"), str(SYNTHETIC / "pdf" / "blandet_scan.pdf"), "--reference-site", "bilag.pdf=Testvandvaerk"]
        scenarios.append(("huller", 3, [*gaps, *one_site, "--out", str(args.out / "huller")]))
    else:
        print("PyMuPDF mangler: PDF-delene af demoen er IKKE kørt, og PDF-understøttelse er ikke vist.")
    scenarios.append(("flere_sites", 3, ["--reference", str(MULTI / "inventory.csv"), "--logs", str(MULTI / "nams.csv"), "--scope", "192.0.2.0/24",
                                         "--all-sites", "--out", str(args.out / "flere_sites")]))

    failed = False
    summary = []
    for name, expected, arguments in scenarios:
        print(f"\n########## Scenarie: {name} (forventet exit {expected})")
        code = run_pipeline(arguments)
        failed = failed or code != expected
        summary.append(f"  {name}: exit {code}, forventet {expected}, {'som forventet' if code == expected else 'AFVIGER'}")
    print("\nOpsummering:\n" + "\n".join(summary))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
