#!/usr/bin/env python3
"""Generate fictional test data. Deterministic; only RFC 5737 TEST-NET addresses.

Without arguments it rewrites examples/synthetic/demo and examples/synthetic/flere_sites.
With --stress N it writes a large CSV for performance measurements.
"""
import argparse
import csv
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / "examples" / "synthetic" / "demo"
TZ = timezone(timedelta(hours=1))
START = datetime(2026, 10, 25, 0, 0, tzinfo=TZ)
DAYS = 10
GAP_DAYS = {5, 6}  # No log data here, to demonstrate the coverage warning (two days: logs are in UTC+1).

N = "192.0.2."
# ip suffix, name, documented MAC suffix
INVENTORY = [(1, "FW-01", "01"), (2, "SW-CORE-01", "02"), (3, "SW-PROC-01", "03"), (10, "SCADA-01", "10"), (11, "HIST-01", "11"), (12, "EWS-01", "12"),
             (20, "HMI-HAL", "20"), (21, "HMI-KONTROL", "21"), (30, "PLC-RAAVAND", "30"), (31, "PLC-FILTER", "31"), (32, "PLC-RENVAND", "32"), (33, "PLC-UV", "33"),
             (40, "RTU-BORING-A", "40"), (41, "RTU-BORING-B", "41"), (50, "Flowmaaler-1", "50"), (51, "VFD-pumpe-2", "51"), (52, "Niveauanalyse", "52")]
ASSET_MAP = [("192.0.2.1", "Perimeter", "Firewall", "FW-01", "", ""), ("192.0.2.2", "Netværk", "Switch", "SW-CORE-01", "", ""), ("192.0.2.3", "Netværk", "Switch", "SW-PROC-01", "", ""),
             ("192.0.2.10", "Supervision", "SCADA", "SCADA-01", "TEST-JL", "2026-10-12"), ("192.0.2.11", "Supervision", "Historian", "HIST-01", "", ""),
             ("192.0.2.31", "Control", "PLC", "PLC-FILTER", "TEST-JL", "2026-10-12"), ("192.0.2.32", "Control", "PLC", "PLC-RENVAND", "", ""),
             ("192.0.2.77", "Ukendt", "", "Uidentificeret enhed", "", ""), ("203.0.113.50", "Eksternt", "", "NTP-kilde (test)", "", "")]
# src, dst, protocol, port, events per day
TRAFFIC = [(10, 30, "TCP", 502, 12), (10, 31, "TCP", 502, 12), (10, 32, "TCP", 502, 12), (10, 33, "TCP", 502, 8), (10, 11, "TCP", 1433, 10), (21, 10, "TCP", 4840, 9), (20, 10, "TCP", 4840, 6),
           (20, 31, "TCP", 102, 4), (12, 30, "TCP", 102, 1), (12, 31, "TCP", 102, 1), (30, 40, "TCP", 502, 7), (32, 41, "TCP", 502, 5), (31, 50, "TCP", 44818, 7), (32, 51, "TCP", 44818, 6),
           (33, 10, "TCP", 4840, 3), (77, 31, "TCP", 102, 2), (77, 10, "TCP", 443, 1), (1, 2, "UDP", 161, 2)]
EXTERNAL = [(N + "1", "203.0.113.50", "UDP", 123, 2), (N + "10", "198.51.100.20", "TCP", 443, 1), (N + "12", N + "255", "UDP", 137, 1), (N + "31", "239.1.1.1", "UDP", 2222, 3)]
OBSERVED_MAC_OVERRIDE = {33: "00:1B:1B:AA:AA:33"}  # PLC-UV: differs from the documentation.
RTU_A_LAST_DAY = 1  # RTU-BORING-A stops being seen early in the period.


def mac(suffix: str) -> str:
    return f"00:1B:1B:00:00:{suffix}"


def write_inventory() -> None:
    with (DEMO / "inventory.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["ip", "device_name", "site", "mac"])
        for suffix, name, mac_suffix in INVENTORY:
            writer.writerow([f"{N}{suffix}", name, "Testvandvaerk", mac(mac_suffix)])
    with (DEMO / "asset_map.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["IP", "Zone", "Role", "Label", "Verified_by", "Verified_date"])
        writer.writerows(ASSET_MAP)


def events(rng: random.Random):
    rows = []
    for day in range(DAYS):
        if day in GAP_DAYS:
            continue
        for src, dst, proto, port, per_day in TRAFFIC:
            if 40 in (src, dst) and day > RTU_A_LAST_DAY:
                continue
            for _ in range(per_day):
                rows.append((_stamp(rng, day), f"{N}{src}", f"{N}{dst}", proto, port, src))
        for src, dst, proto, port, per_day in EXTERNAL:
            for _ in range(per_day):
                rows.append((_stamp(rng, day), src, dst, proto, port, int(src.rsplit(".", 1)[1])))
    rows.sort(key=lambda row: row[:3])
    return rows


def _stamp(rng: random.Random, day: int) -> datetime:
    return START + timedelta(days=day, seconds=rng.randrange(86400))


def source_mac(suffix: int) -> str:
    known = {item[0]: item[2] for item in INVENTORY}
    if suffix in OBSERVED_MAC_OVERRIDE:
        return OBSERVED_MAC_OVERRIDE[suffix]
    return mac(known[suffix]) if suffix in known else "00:1B:1B:FF:FF:77"


def write_logs() -> None:
    rows = events(random.Random(4242))
    with (DEMO / "nams.csv").open("w", encoding="utf-8-sig", newline="") as csv_stream, \
            (DEMO / "nams_syslog.log").open("w", encoding="utf-8") as log_stream, \
            (DEMO / "nams_events.jsonl").open("w", encoding="utf-8") as json_stream:
        writer = csv.writer(csv_stream, delimiter=";")
        writer.writerow(["timestamp", "sensor", "src_ip", "dst_ip", "protocol", "dst_port", "src_mac"])
        for index, (stamp, src, dst, proto, port, suffix) in enumerate(rows):
            if index % 5 == 3:
                log_stream.write(f"{stamp.isoformat()} nams-a flow src={src} dst={dst} proto={proto} dpt={port}\n")
            elif index % 5 == 4:
                json_stream.write(json.dumps({"@timestamp": stamp.isoformat(), "event": {"kind": "flow"}, "source": {"ip": src}, "destination": {"ip": dst, "port": port},
                                              "network": {"protocol": proto}}) + "\n")
            else:
                writer.writerow([stamp.isoformat(), "nams-a", src, dst, proto, port, source_mac(suffix)])
        log_stream.write("2026-11-03T12:00:00+01:00 nams-a note: firmware check mod 192.0.2.52 uden flowdata\n")


def write_multi_site() -> None:
    """Two waterworks, one shared log. 192.0.2.5 is used on both sites, and some log rows name no site."""
    folder = ROOT / "examples" / "synthetic" / "flere_sites"
    folder.mkdir(parents=True, exist_ok=True)
    inventory = [("192.0.2.5", "PLC-DELT-N", "Vandvaerk Nord", "00:1B:1B:00:01:05"), ("192.0.2.10", "PLC-N1", "Vandvaerk Nord", "00:1B:1B:00:01:10"), ("192.0.2.11", "HMI-N1", "Vandvaerk Nord", "00:1B:1B:00:01:11"),
                 ("192.0.2.5", "PLC-DELT-S", "Vandvaerk Syd", "00:1B:1B:00:02:05"), ("192.0.2.20", "PLC-S1", "Vandvaerk Syd", "00:1B:1B:00:02:20"), ("192.0.2.21", "HMI-S1", "Vandvaerk Syd", "00:1B:1B:00:02:21"),
                 ("192.0.2.30", "Gammel-enhed", "", "")]
    log = [("Vandvaerk Nord", "2026-11-03T08:00:00+01:00", "192.0.2.10", "192.0.2.11", "TCP", 502), ("Vandvaerk Nord", "2026-11-03T08:05:00+01:00", "192.0.2.5", "192.0.2.11", "TCP", 502),
           ("Vandvaerk Syd", "2026-11-03T08:10:00+01:00", "192.0.2.20", "192.0.2.21", "TCP", 102), ("Vandvaerk Syd", "2026-11-03T08:15:00+01:00", "192.0.2.5", "192.0.2.21", "TCP", 102),
           ("", "2026-11-03T08:20:00+01:00", "192.0.2.5", "192.0.2.30", "UDP", 161)]
    with (folder / "inventory.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["ip", "device_name", "site", "mac"])
        writer.writerows(inventory)
    with (folder / "nams.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["site", "timestamp", "src_ip", "dst_ip", "protocol", "dst_port"])
        writer.writerows(log)


def write_review_decisions() -> None:
    """A reviewer's own file. Evidence IDs come from a real run; one is deliberately out of date."""
    import sys
    sys.path.insert(0, str(ROOT / "src"))
    from otvalidate.ingest import LogAggregator, load_reference
    from otvalidate.reconcile import parse_scopes, reconcile
    ref = load_reference([DEMO / "inventory.csv"], site="Testvandvaerk")
    logs = LogAggregator({}, site="Testvandvaerk", site_confirmed=True)
    for name in ("nams.csv", "nams_syslog.log", "nams_events.jsonl"):
        logs.add_file(DEMO / name)
    ids = {row["IP"]: row["Evidens_ID"] for row in reconcile(ref, logs, parse_scopes(["192.0.2.0/24"])).asset_rows}
    decisions = [("192.0.2.3", ids["192.0.2.3"], "GODKENDT", "TEST-JL", "2026-11-05", "Switch uden IP-trafik set af sensoren; passer med tavletegning"),
                 ("192.0.2.33", ids["192.0.2.33"], "UNDERSOEG", "TEST-JL", "2026-11-05", "MAC afviger; driften spoerges om udskiftning"),
                 ("192.0.2.77", ids["192.0.2.77"], "UNDERSOEG", "TEST-AB", "2026-11-05", "Ukendt enhed; afventer gennemgang paa stedet"),
                 ("192.0.2.40", ids["192.0.2.40"], "AFVIST", "TEST-AB", "2026-11-06", "RTU er nedlagt; dokumentationen skal rettes"),
                 ("192.0.2.41", "0000000000000000", "GODKENDT", "TEST-JL", "2026-09-01", "Gammel beslutning paa tidligere evidens")]
    with (DEMO / "review_beslutninger.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["Site", "IP", "Evidens_ID", "Beslutning", "Beslutter", "Dato", "Begrundelse"])
        for ip, evidence, decision, by, date, reason in decisions:
            writer.writerow(["Testvandvaerk", ip, evidence, decision, by, date, reason])


def write_stress(path: Path, rows: int) -> None:
    rng = random.Random(1)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["timestamp", "src_ip", "dst_ip", "protocol", "dst_port", "src_mac"])
        for index in range(rows):
            writer.writerow([f"2026-11-04T{index % 24:02d}:{index % 60:02d}:{index % 60:02d}+01:00", f"{N}{index % 200 + 1}", f"{N}{(index * 7) % 200 + 1}",
                             "TCP", rng.choice((502, 443, 102)), f"00:11:22:33:44:{index % 200:02x}"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--stress", type=int, help="Antal rækker i stress-CSV")
    parser.add_argument("--out", type=Path, default=Path("stress.csv"), help="Sti til stress-CSV")
    args = parser.parse_args()
    if args.stress:
        write_stress(args.out, args.stress)
        return
    DEMO.mkdir(parents=True, exist_ok=True)
    write_inventory()
    write_logs()
    write_review_decisions()
    write_multi_site()


if __name__ == "__main__":
    main()
