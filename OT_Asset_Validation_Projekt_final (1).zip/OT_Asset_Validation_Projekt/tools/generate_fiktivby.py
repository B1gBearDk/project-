#!/usr/bin/env python3
"""Write the fictional waterworks "Fiktivby Vandvaerk": 34 documented and 2 undocumented assets.

Every anomaly is deliberate. The expected result of each address is written to forventet.csv here,
from the scenario alone and without using the validator, so a test can compare the tool against it.
Only RFC 5737 addresses. Deterministic.
"""
import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
import random

OUT = Path(__file__).resolve().parents[1] / "examples" / "synthetic" / "fiktivby"
SITE = "Fiktivby Vandvaerk"
N = "192.0.2."
TZ = timezone(timedelta(hours=1))
START = datetime(2026, 10, 21, tzinfo=TZ)
DAYS = 14

# suffix: (name, zone in the asset map or "" when left to the name-based hypothesis, role in the map)
ASSETS = {
    1: ("FW-EDGE-01", "Perimeter", "Firewall"), 2: ("FW-OT-01", "Perimeter", "Firewall"),
    3: ("SW-CORE-01", "Netværk", "Switch"), 4: ("SW-PROC-01", "Netværk", "Switch"), 5: ("SW-FELT-01", "Netværk", "Switch"), 6: ("SW-FELT-02", "Netværk", "Switch"),
    10: ("SCADA-01", "Supervision", "SCADA"), 11: ("SCADA-02", "Supervision", "SCADA"), 12: ("HIST-01", "Supervision", "Historian"), 13: ("HIST-02", "Supervision", "Historian"),
    14: ("EWS-01", "Supervision", "Engineering Workstation"), 15: ("EWS-02", "Supervision", "Engineering Workstation"), 16: ("SRV-PATCH-01", "Supervision", "Server"),
    20: ("HMI-KONTROL-01", "", ""), 21: ("HMI-KONTROL-02", "", ""), 22: ("HMI-FILTER-01", "", ""), 23: ("HMI-PUMPE-01", "", ""),
    30: ("PLC-RAAVAND-01", "Control", "PLC"), 31: ("PLC-FILTER-01", "Control", "PLC"), 32: ("PLC-FILTER-02", "Control", "PLC"), 33: ("PLC-RENVAND-01", "Control", "PLC"), 34: ("PLC-UV-01", "", ""), 35: ("PLC-DOSERING-01", "", ""),
    40: ("RTU-BORING-01", "", ""), 41: ("RTU-BORING-02", "", ""), 42: ("RTU-BORING-03", "", ""), 43: ("RTU-HOEJDE-01", "", ""),
    50: ("Maaler-FT-101", "", ""), 51: ("Maaler-FT-102", "", ""), 52: ("Sensor-LT-201", "", ""), 53: ("Sensor-AT-301", "", ""), 54: ("Pumpe-P-401", "", ""), 55: ("Pumpe-P-402", "", ""), 56: ("Ventil-V-501", "", ""),
}
VERIFIED = {10: ("TEST-JL", "2026-10-12"), 31: ("TEST-JL", "2026-10-12")}

# src, dst, protocol, port, events per day
TRAFFIC = [
    (10, 30, "TCP", 502, 8), (10, 31, "TCP", 502, 8), (10, 32, "TCP", 502, 8), (10, 33, "TCP", 502, 8), (10, 34, "TCP", 502, 6), (10, 35, "TCP", 502, 6),
    (11, 30, "TCP", 502, 2), (11, 33, "TCP", 502, 2), (10, 12, "TCP", 1433, 6), (11, 12, "TCP", 1433, 2), (10, 11, "TCP", 4840, 3),
    (20, 10, "TCP", 4840, 6), (21, 10, "TCP", 4840, 6), (22, 31, "TCP", 102, 4), (22, 32, "TCP", 102, 4), (23, 30, "TCP", 102, 3), (23, 35, "TCP", 102, 3),
    (14, 31, "TCP", 102, 1), (15, 33, "TCP", 102, 1), (15, 34, "TCP", 102, 1),
    (30, 40, "TCP", 502, 5), (30, 41, "TCP", 502, 5), (30, 43, "TCP", 502, 4),
    (31, 50, "TCP", 44818, 5), (32, 51, "TCP", 44818, 5), (33, 52, "TCP", 44818, 4), (34, 53, "TCP", 44818, 4), (30, 54, "TCP", 44818, 4), (30, 55, "TCP", 44818, 4), (35, 56, "TCP", 44818, 3),
    (2, 3, "UDP", 161, 2), (2, 4, "UDP", 161, 2), (2, 5, "UDP", 161, 2), (16, 14, "TCP", 445, 1), (16, 1, "TCP", 443, 1),
]
LATE_ONLY_STOP = {41: 3}  # RTU-BORING-02 stops being seen after day 3 of 14.
MAC_OVERRIDES = {34: ["00:1B:1B:AA:AA:34"]}  # PLC-UV-01: observed MAC differs from the documentation.
TWO_MACS = {23}  # HMI-PUMPE-01: seen with its documented MAC and with a second one.
UNDOCUMENTED_SOURCE = (88, [(31, "TCP", 102, 2), (32, "TCP", 102, 1), (10, "TCP", 4840, 1)])  # An unknown device talks to PLCs.
EXTRA = [(N + "15", N + "131", "TCP", 22, 1), (N + "16", "198.51.100.20", "TCP", 443, 1), (N + "1", "203.0.113.50", "UDP", 123, 2),
         (N + "31", "239.2.2.2", "UDP", 2222, 3), (N + "14", N + "255", "UDP", 137, 1)]

SILENT = {6, 13, 42}


def mac(suffix) -> str:
    return f"00:1B:1B:00:00:{suffix:02X}"


def events():
    rng = random.Random(2026)
    rows = []

    def add(day, src, dst, proto, port, src_mac):
        rows.append((START + timedelta(days=day, seconds=rng.randrange(86400)), src, dst, proto, port, src_mac))

    for day in range(DAYS):
        for src, dst, proto, port, per_day in TRAFFIC:
            if day > LATE_ONLY_STOP.get(dst, DAYS) or day > LATE_ONLY_STOP.get(src, DAYS):
                continue
            for index in range(per_day):
                source_mac = MAC_OVERRIDES.get(src, [mac(src)])[0]
                if src in TWO_MACS and index % 2 == 0 and day % 3 == 0:
                    source_mac = "00:1B:1B:BB:BB:23"
                add(day, N + str(src), N + str(dst), proto, port, source_mac)
        suffix, targets = UNDOCUMENTED_SOURCE
        for dst, proto, port, per_day in targets:
            if day >= 10:  # The unknown device appears late in the period.
                for _ in range(per_day):
                    add(day, N + str(suffix), N + str(dst), proto, port, "02:00:5E:12:34:56")
        for src, dst, proto, port, per_day in EXTRA:
            for _ in range(per_day):
                add(day, src, dst, proto, port, mac(int(src.rsplit(".", 1)[1])))
    rows.sort(key=lambda row: (row[0], row[1], row[2]))
    return rows


def expected_rows():
    """Expected status per address, reasoned from the scenario tables above."""
    sources = {src for src, *_ in TRAFFIC} | {int(src.rsplit(".", 1)[1]) for src, *_ in EXTRA if src.startswith(N)}
    destinations = {dst for _, dst, *_ in TRAFFIC}
    rows = []
    for suffix, (name, *_) in ASSETS.items():
        if suffix in SILENT:
            status = "DOKUMENTERET_IKKE_OBSERVERET"
        elif suffix in sources:
            status = "DOKUMENTERET_KILDE_OBSERVERET"
        else:
            status = "DOKUMENTERET_KUN_DESTINATION"
        deviations = {34: "MAC_AFVIGER", 23: "MAC_AFVIGER, FLERE_MAC", 41: "SIDST_SET_FOER_LOGSLUT"}.get(suffix, "")
        assert suffix in SILENT or suffix in sources or suffix in destinations, name
        rows.append((N + str(suffix), status, deviations, name))
    rows += [(N + "88", "IKKE_I_REFERENCE_IN_SCOPE", "", "Ukendt kilde mod PLC'er, ses først fra dag 11"), (N + "131", "IKKE_I_REFERENCE_IN_SCOPE", "", "Ukendt destination for SSH fra EWS-02"),
             (N + "255", "LOGISK_ADRESSE", "", "Subnet-broadcast, ikke et asset"), ("239.2.2.2", "LOGISK_ADRESSE", "", "Multicast, ikke et asset"),
             ("198.51.100.20", "UDENFOR_SCOPE", "", "Ekstern destination fra SRV-PATCH-01"), ("203.0.113.50", "UDENFOR_SCOPE", "", "Ekstern NTP fra FW-EDGE-01")]
    return rows


def write_all() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "inventory.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["ip", "device_name", "site", "mac"])
        for suffix, (name, *_) in ASSETS.items():
            writer.writerow([N + str(suffix), name, SITE, mac(suffix)])
    with (OUT / "asset_map.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["Site", "IP", "Zone", "Role", "Label", "Verified_by", "Verified_date"])
        for suffix, (name, zone, role) in ASSETS.items():
            if zone:
                writer.writerow([SITE, N + str(suffix), zone, role, name, *VERIFIED.get(suffix, ("", ""))])
    with (OUT / "nams.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["timestamp", "sensor", "src_ip", "dst_ip", "protocol", "dst_port", "src_mac"])
        for stamp, src, dst, proto, port, source_mac in events():
            writer.writerow([stamp.isoformat(), "nams-fiktivby", src, dst, proto, port, source_mac])
    with (OUT / "forventet.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["IP", "Forventet_status", "Forventet_afvigelse", "Note"])
        writer.writerows(expected_rows())


if __name__ == "__main__":
    write_all()
