#!/usr/bin/env python3
"""Run validation, diagrams and report in one step. Reads local export files only."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from otvalidate.cli import run_pipeline  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run_pipeline())
