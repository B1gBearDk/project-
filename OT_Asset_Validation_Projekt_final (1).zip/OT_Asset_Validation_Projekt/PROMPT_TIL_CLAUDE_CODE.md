# Opgave til Claude Code — OT Asset Validation & Dataflow

Du arbejder i roden af projektet **OT_Asset_Validation_Projekt**. Du skal **gennemgå, forbedre og teste den eksisterende kode**, ikke bare skrive en plan. Projektet er et offline værktøj til at sammenholde dokumenterede OT-assets (PDF/CSV/TXT) med passive NAMS-lignende logeksporter og derefter fremstille et hierarkisk, professionelt site-dataflow-diagram. Alle medfølgende data i `examples/synthetic/` er **fiktive TEST-NET-eksempler**. Projektet er tiltænkt vandforsynings-OT, hvor falske konklusioner kan være alvorlige.

## Brug dine skills og din værktøjskasse

1. Begynd med at læse `README.md`, `CLAUDE.md`, `run_pipeline.py` og begge filer i `src/` samt eksempelfilerne.
2. Undersøg hvilke skills, subagents og relevante kode-/test-/designværktøjer du **faktisk har adgang til**. Anvend de relevante — især til Python code review, security, tests og visual design — hvis de findes. Opfind ikke skills, som ikke er installeret. Du må gerne opdele arbejdet mellem specialiserede agents, hvis værktøjerne tillader det.
3. Lav først en kort teknisk audit med prioriterede fejl/risici. **Implementér derefter forbedringerne direkte**, kør test med syntetiske data, og lever en slutrapport med ændringer, testresultater og resterende begrænsninger. Spørg kun om et valg, hvis det er reelt blokerende.

## Hovedmål

Byg et **robust, brugbart og vedligeholdeligt** lokalt pipeline-flow:

`Dokumenteret inventory/PDF + passive NAMS-logs → normalisering → reconciliation/valideringskø → asset catalog → observerede forbindelser → tydeligt hierarkisk diagram + rapporter`.

Målet er et værktøj, som en junior IT/OT Security-medarbejder kan bruge på **et site ad gangen** uden at læse tusindvis af loglinjer. Designet skal være gennemtænkt, minimalistisk, professionelt og forklarende. **Ingen AI-slop**: ingen dekorative dashboards, tilfældige farver, oppustet arkitektur, generiske marketingtekster eller visuelt støjende pile/boxes. Gør faglig formidling til førsteprioritet.

## Ufravigelige sikkerheds- og fagkrav

- **Kun offline, passiv behandling af allerede eksporterede lokale filer.** Ingen netværksscanning, PLC/HMI-forespørgsler, shell-kommandoer mod anlægsudstyr, internetkald, cloud-API'er, telemetry, data-upload eller eksterne LLM-tjenester. Arbejd udelukkende med det syntetiske datasæt i projektet, indtil en autoriseret administrator udtrykkeligt godkender andet.
- **Hverken Claude, værktøjer eller subagents må få rigtige IP-/MAC-lister, rå logs, netværkstegninger eller OT-assetdata.** Bed ikke om produktionsfiler, og forsøg ikke at tilgå tilsluttede datakilder.
- Ingen auto-installation af dependencies eller ændringer i systemmiljø uden godkendelse. Brug forinstallerede værktøjer, eller dokumentér præcis, hvad der mangler.
- **Datavalidering må aldrig blive til 'fysisk verificeret' automatisk.** Skeln klart mellem: dokumenteret, observeret som source, kun destination, ukendt IP, ikke observeret og **manuelt/fysisk verificeret** (sidstnævnte kun hvis verificeringsfelt er indlæst eksplicit).
- Sensorens placering, observationsperiode, coverage gaps, DHCP, NAT, flere IP'er pr. asset, virtuelt udstyr, gamle PDF'er, multicast/broadcast, tidszoner og stale data skal håndteres eller fremhæves som begrænsninger.
- **Et observeret source→destination-flow er ikke en dokumenteret fysisk netværksforbindelse**. Der må ikke opfindes switches, kabler, zonegrænser, Purdue-niveauer eller 'normal/malicious'-klassificering ud fra porte alene. Vis observerede dataflows og bekræftede facts separat. Manglende log-observation er ikke bevis for manglende enhed.
- Pas på input/data-injection: CSV/Excel-formula injection, Graphviz DOT-/Mermaid-escaping, specialtegn og lange strings, ugyldige IP'er, samt uventede logfelter. Gør outputs deterministiske og tydeligt mærket som arbejdsmateriale.

## Det du skal forbedre

**Kode og parsing**
- Review parser for PDF, CSV/TSV, JSON/JSONL og tekstlogs; robuste feltaliases; strømning af store datamængder hvor muligt; klare fejlsignaler for manglende felter og uparsebare tidsstempler. Brug kun nødvendige dependencies.
- Skab rene moduler/funktioner til ingestion, normalisering, reconciliation, site filtering, diagram, rapport og CLI. Undgå overengineering og unødvendig omskrivning af ting, der allerede virker.
- Sørg for at `run_pipeline.py` kører end-to-end og at de to separate CLI'er stadig virker.
- Tilføj dokumenteret mapping af zone/assetrolle, hvor **manuelt verificeret mapping prioriteres**. Auto-inference må kun være en tydeligt markeret foreløbig hypotese, aldrig ground truth.

**Diagrammet**
- Lav et **smukt, teknisk seriøst og læsbart OT-site-overblik** i SVG samt evt. PNG. Hierarkisk struktur med zoner fx Eksternt/Perimeter, Netværk, Supervision, HMI, Control, Field og Ukendt, men vis kun zoner der faktisk er understøttet af data eller en manuel mapping.
- Diagrammet skal have klare assetnavne, IP, rolle, status og forbindelser. Pile skal være **rettede observerede flows** med protokol/port og evt. aggregerede counts, men uden implicitte normative sikkerhedsvurderinger.
- Vis usikkerhed eksplicit: observation, dokumentation, valideringsafvigelse og ukendt rolle må ikke se ens ud som verificerede assets. Farver og kanter skal have en konsistent tegnforklaring; læsbar i gråtoner og på A4 / præsentationsslide.
- Undgå spaghetti-visualiseringer: grouping/subgraphs, intelligent rank/layout, filtrering, maksimal-label-længde og evt. overview + zonevis detalje ved store sites. Tilbyd en overskuelig forbindelse-/flowtabel som companion til grafen. Diagrammer må ikke mislede om fysisk topologi.
- Eksportér både redigerbar kilde (DOT eller Mermaid), SVG, evt. PNG og en kort samlet rapport. Giv brugbare meddelelser, hvis Graphviz ikke er installeret.

**Tests og kvalitet**
- Tilføj automatiserede tests med Python `unittest` eller `pytest` (hvis installeret). Minimum: ingen observation, ukendt IP i scope, dest-only, duplicate observations, subnet/CIDR og netmask, forkert schema, tom log, ugyldige IP'er, tidszoner, quoted CSV, DOT/Mermaid escape, flere sites, ukendt rolle, og missing Graphviz.
- Brug **kun** `examples/synthetic/` til test. Tjek at outputs ikke indeholder hemmeligheder eller rigtige IP'er og ikke skrives uden for valgt outputdir.
- Prøv realistisk størrelse med syntetisk genererede data og dokumentér performance og memorybegrænsninger.
- Kør demo i `README.md` og test hele kæden. Ret observerede fejl; efterlad ikke kun TODOs.

**Dokumentation og udvikleroplevelse**
- README med prerequisites, Windows PowerShell-eksempel, første kørsel, forventet output, fejlfindingsguide, og hvad der kræver manuel verificering.
- `requirements.txt` og `.gitignore` skal være sikre og præcise; ingen følsomme input/output i git. Separer synthetic testdata fra rigtige eksportfiler.
- Bevar CSV-format, der åbner i dansk Excel (UTF-8 BOM + `;`). Prøv at holde CLI bagudkompatibel; forklar eventuelle ændringer.
- Skriv en kort `ARCHITECTURE.md` og en `CHANGELOG.md` med reelle ændringer, ikke generiske påstande.

## Definition of done

1. End-to-end demonstration fra syntetisk inventory og NAMS-CSV til rapporter og diagram virker lokalt.
2. Enhedsliste og flowkort er korrekte inden for evidensgrænserne. Ingen 'verificeret'-påstand uden eksplicit input.
3. Tests kører og dokumenterer vigtige fejlscenarier.
4. Outputdiagrammet er klart, professionelt og praktisk til vandværksdokumentation.
5. Ingen cloud- eller anlægsinteraktion; ingen følsomme data ud af lokalmiljøet.
6. Slutrapport: **audit → implementerede ændringer → kommandoer/testresultater → kendte begrænsninger**. Vær konkret, ingen AI-slop.

**Start nu med en kort audit, og gå derefter direkte til implementering og test i projektmappen.**
